import 'package:background_fetch/background_fetch.dart';
import 'package:clinick/repository/helpers.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';

import 'app.dart';
import 'database/shared_pref.dart';
import 'models/message_info_model.dart';
import 'repository/notifications.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();

  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  Helpers.changeStatusBarTheme(ThemeMode.light);

  FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);
  await FirebaseMessaging.instance.setForegroundNotificationPresentationOptions(
    badge: true,
  );

  final SharedPrefs _prefs = SharedPrefs.instance;
  UserType _userType = await _prefs.getUserType();

  runApp(MyApp(initialUserType: _userType));

  BackgroundFetch.registerHeadlessTask(backgroundFetchHeadlessTask);
}

Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  await Firebase.initializeApp();
}

void backgroundFetchHeadlessTask(HeadlessTask task) async {
  String taskId = task.taskId;
  bool isTimeout = task.timeout;
  if (isTimeout) {
    // This task has exceeded its allowed running-time.
    // You must stop what you're doing and immediately .finish(taskId)
    // PRINT: print("[BackgroundFetch] Headless task timed-out: $taskId");
    BackgroundFetch.finish(taskId);
    return;
  }
  // PRINT: print('[BackgroundFetch] Headless event received.');
  await Firebase.initializeApp();
  await LocalNotifs.registerTodayMedicationTracker();
  BackgroundFetch.finish(taskId);
}
