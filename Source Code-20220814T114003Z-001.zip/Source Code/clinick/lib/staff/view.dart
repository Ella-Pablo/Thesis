import 'package:clinick/blocs/messaging/list/bloc.dart';
import 'package:clinick/blocs/news_bloc/bloc.dart';
import 'package:clinick/config/color.dart';
import 'package:clinick/database/app_firebase.dart';
import 'package:clinick/staff/pages/auth/new_user_config.dart';
import 'package:clinick/staff/tabs/appointments/blocs/appointment_bloc/bloc.dart';
import 'package:clinick/staff/tabs/appointments/view.dart';
import 'package:clinick/views/splash_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'tabs/home/view.dart';
import 'tabs/messages/view.dart';

class StaffView extends StatefulWidget {
  @override
  _StaffViewState createState() => _StaffViewState();
}

class _StaffViewState extends State<StaffView> {
  final Map<String, MapEntry<IconData, IconData>> navigationBarItems = {
    "Home": MapEntry(Icons.home_outlined, Icons.home),
    "Appointments": MapEntry(Icons.event_note_outlined, Icons.event_note),
    "Messages": MapEntry(Icons.sms_outlined, Icons.sms),
  };
  final ValueNotifier<int> selectedIndex = ValueNotifier(0);
  final StaffAppointmentBloc staffAppointmentsBloc = StaffAppointmentBloc();
  bool forceSource = true;

  @override
  void initState() {
    forceSource = true;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<bool?>(
      initialData: null,
      future: AppFirebase.getStaffData(forceSource),
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return PageSplashScreen();
        } else if (snapshot.data == false) {
          return StaffPageNewUser();
        }

        forceSource = false;
        return ValueListenableBuilder<int>(
          valueListenable: selectedIndex,
          builder: (_, value, __) {
            return Scaffold(
              bottomNavigationBar: _navigationBar(value),
              body: IndexedStack(
                index: selectedIndex.value,
                children: [
                  MultiBlocProvider(
                    providers: [
                      BlocProvider(create: (_) => NewsBloc()),
                      BlocProvider(create: (_) => staffAppointmentsBloc),
                    ],
                    child: StaffTabHome(),
                  ),
                  BlocProvider(
                    create: (_) => staffAppointmentsBloc,
                    child: StaffTabAppointments(),
                  ),
                  BlocProvider(
                    create: (_) => MessageInfoBloc(),
                    child: StaffTabMessages(),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  Widget _navigationBar(int index) {
    return Container(
      decoration: BoxDecoration(
        border: Border(
          top: BorderSide(
            width: 0.5,
            color: ThemeColor.inputBorder,
          ),
        ),
      ),
      child: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        elevation: 0.0,
        unselectedFontSize: 10.0,
        selectedFontSize: 10.0,
        currentIndex: index,
        onTap: (index) => selectedIndex.value = index,
        items: navigationBarItems.entries.map((item) {
          return BottomNavigationBarItem(
            icon: Padding(
              padding: const EdgeInsets.all(5.0),
              child: Icon(item.value.key),
            ),
            activeIcon: Padding(
              padding: const EdgeInsets.all(5.0),
              child: Icon(item.value.value),
            ),
            label: item.key,
            tooltip: item.key,
          );
        }).toList(),
      ),
    );
  }
}
