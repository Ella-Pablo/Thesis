import 'package:clinick/blocs/base/view_event.dart';
import 'package:clinick/blocs/base/view_state.dart';
import 'package:clinick/blocs/news_bloc/bloc.dart';
import 'package:clinick/config/app_config.dart';
import 'package:clinick/config/color.dart';
import 'package:clinick/database/app_firebase.dart';
import 'package:clinick/models/appointment_model.dart';
import 'package:clinick/models/covid_tracker_model.dart';
import 'package:clinick/patient/views/pages/search/blocs/bloc.dart';
import 'package:clinick/staff/pages/covid_tracker/blocs/bloc.dart';
import 'package:clinick/staff/pages/covid_tracker/view.dart';
import 'package:clinick/staff/pages/doctor_search/view.dart';
import 'package:clinick/staff/pages/history/blocs/bloc.dart';
import 'package:clinick/staff/pages/history/view.dart';
import 'package:clinick/staff/pages/schedule/blocs/bloc.dart';
import 'package:clinick/staff/pages/schedule/view.dart';
import 'package:clinick/staff/pages/search/blocs/bloc.dart';
import 'package:clinick/staff/pages/search/view.dart';
import 'package:clinick/staff/tabs/appointments/blocs/appointment_bloc/bloc.dart';
import 'package:clinick/staff/tabs/appointments/blocs/appointment_bloc/states.dart';
import 'package:clinick/staff/tabs/appointments/event_item_template.dart';
import 'package:clinick/staff/pages/profile/editing_state_cubit.dart';
import 'package:clinick/staff/pages/profile/profile_state_cubit.dart';
import 'package:clinick/staff/pages/profile/view.dart';
import 'package:clinick/views/qr_code.dart';
import 'package:clinick/widgets/dialog_templates.dart';
import 'package:clinick/widgets/news_templates.dart';
import 'package:clinick/widgets/shortcuts_templates.dart';
import 'package:clinick/widgets/state_view_template.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:intl/intl.dart';
import 'package:line_icons/line_icons.dart';

class StaffTabHome extends StatefulWidget {
  const StaffTabHome();

  @override
  _StaffTabHomeState createState() => _StaffTabHomeState();
}

class _StaffTabHomeState extends State<StaffTabHome> {
  @override
  void initState() {
    BlocProvider.of<NewsBloc>(context).add(NewsEventRequest());
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 15.0),
              Row(
                children: [
                  const SizedBox(width: 15.0),
                  Container(
                    height: 40.0,
                    width: 40.0,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                          spreadRadius: 1.0,
                          blurRadius: 4.0,
                          color: ThemeColor.shadow.withOpacity(0.25),
                          offset: Offset(0, 0),
                        )
                      ],
                    ),
                    clipBehavior: Clip.antiAlias,
                    child: Material(
                      color: ThemeColor.background,
                      clipBehavior: Clip.antiAlias,
                      child: IconButton(
                        onPressed: () {
                          Navigator.push(
                            context,
                            CupertinoPageRoute(
                              builder: (context) {
                                return MultiBlocProvider(
                                  providers: [
                                    BlocProvider(create: (_) => ProfileStateCubit()),
                                    BlocProvider(create: (_) => EditingStateCubit()),
                                  ],
                                  child: StaffPageProfile(),
                                );
                              },
                            ),
                          );
                        },
                        tooltip: 'Edit Information or Logout',
                        icon: const Icon(
                          LineIcons.user,
                          color: ThemeColor.secondary2,
                        ),
                      ),
                    ),
                  ),
                  const Spacer(),
                  const Text(
                    'CLinicK',
                    style: const TextStyle(
                      color: ThemeColor.accent,
                      fontWeight: FontWeight.w900,
                      fontSize: 23.0,
                    ),
                  ),
                  const Spacer(),
                  Container(
                    height: 40.0,
                    width: 40.0,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                          spreadRadius: 1.0,
                          blurRadius: 4.0,
                          color: ThemeColor.shadow.withOpacity(0.25),
                          offset: Offset(0, 0),
                        )
                      ],
                    ),
                    clipBehavior: Clip.antiAlias,
                    child: Material(
                      color: ThemeColor.background,
                      clipBehavior: Clip.antiAlias,
                      child: IconButton(
                        onPressed: searchPicker,
                        tooltip: "Search a Patient or Doctor",
                        icon: const Icon(
                          LineIcons.search,
                          size: 20.0,
                          color: ThemeColor.secondary2,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 15.0),
                ],
              ),
              const SizedBox(height: 20.0),
              StreamBuilder<QuerySnapshot>(
                stream: AppFirebase.firestore
                    .collection('covidpui')
                    .where('userid', isEqualTo: AppFirebase.uid())
                    .limit(1)
                    .snapshots(),
                builder: (_, snapshot) {
                  if (snapshot.hasData) {
                    if (snapshot.data!.size > 0) {
                      final CovidTrackerModel _model = CovidTrackerModel.fromSnapshot(
                        snapshot.data!.docs.first.id,
                        snapshot.data!.docs.first.data(),
                      );

                      return Padding(
                        padding: const EdgeInsets.fromLTRB(20.0, 5.0, 20.0, 15.0),
                        child: Material(
                          elevation: 5.0,
                          borderRadius: BorderRadius.circular(15.0),
                          color: ThemeColor.background,
                          shadowColor: ThemeColor.shadow.withOpacity(0.85),
                          child: Container(
                            width: double.maxFinite,
                            decoration: BoxDecoration(
                              color: ThemeColor.accent,
                              borderRadius: BorderRadius.circular(15.0),
                              gradient: const LinearGradient(
                                colors: [
                                  Color.fromARGB(255, 186, 48, 48),
                                  ThemeColor.accent,
                                ],
                                begin: Alignment.bottomRight,
                                end: Alignment.topLeft,
                              ),
                            ),
                            padding: const EdgeInsets.all(15.0),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Icon(
                                  LineIcons.exclamationTriangle,
                                  size: 40.0,
                                  color: ThemeColor.background,
                                ),
                                const SizedBox(width: 10.0),
                                Expanded(
                                  child: Text(
                                    "Oh no! Someone tested positive during your stay in our clinic last ${DateFormat('MMMM dd, yyyy').format(_model.start)} (${DateFormat('hh:mm a').format(_model.start)} - ${DateFormat('hh:mm a').format(_model.end)}).",
                                    textAlign: TextAlign.justify,
                                    style: const TextStyle(
                                      color: ThemeColor.background,
                                      fontSize: 15.0,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    }
                  }
                  return const SizedBox();
                },
              ),
              shortcutGrid(),
              const Padding(
                padding: const EdgeInsets.symmetric(horizontal: 15.0),
                child: const Text(
                  'Upcoming Appointments',
                  style: const TextStyle(
                    fontSize: 19.0,
                    fontWeight: FontWeight.w600,
                    color: ThemeColor.primary,
                  ),
                ),
              ),
              const SizedBox(height: 15.0),
              BlocBuilder<StaffAppointmentBloc, StaffAppointmentState>(
                builder: (context, state) {
                  final double w = MediaQuery.of(context).size.width;

                  if (state is StaffAppointmentStateInProgress) {
                    return SizedBox(
                      height: 200.0,
                      child: const Center(
                        child: const CircularProgressIndicator(
                          valueColor: AlwaysStoppedAnimation(ThemeColor.accent),
                        ),
                      ),
                    );
                  } else if (state is StaffAppointmentStateFailed) {
                    return SizedBox(
                      height: 250.0,
                      child: StateView(
                        title: "Sorry for the trouble!",
                        message:
                            "We encountered an error while trying to fetch your appointments. Try to restart the app.",
                        assetPath: AppConfig.asset_failedImage,
                        imageSize: Size(w * 0.55, w * 0.45),
                      ),
                    );
                  } else if (state is StaffAppointmentStateSuccess) {
                    final List<AppointmentModel> _filteredList =
                        state.appointments.where((e) => e.status == AppointmentStatus.paid).toList();
                    if (_filteredList.isNotEmpty) {
                      double _height = 345.0;
                      if (_filteredList.length < 4) {
                        _height = 90.0 * _filteredList.length;
                      }
                      return SizedBox(
                        height: _height,
                        child: ListView.builder(
                          physics: const NeverScrollableScrollPhysics(),
                          itemCount: _filteredList.length > 4 ? 4 : _filteredList.length,
                          itemBuilder: (context, index) {
                            final AppointmentModel _model = _filteredList[index];
                            return StaffEventItemTemplate(
                              model: _model,
                              margin: const EdgeInsets.symmetric(vertical: 5.0, horizontal: 15.0),
                            );
                          },
                        ),
                      );
                    }
                  }

                  return SizedBox(
                    height: 250.0,
                    child: StateView(
                      title: "Nothing to see here!",
                      message: "Your upcoming appointments that are marked as paid will appear here.",
                      assetPath: AppConfig.asset_emptyImage,
                      imageSize: Size(w * 0.55, w * 0.45),
                    ),
                  );
                },
              ),
              const SizedBox(height: 30.0),
              SizedBox(
                height: 24.0,
                child: Row(
                  children: [
                    const SizedBox(width: 15.0),
                    Text(
                      'Latest Medical News',
                      style: const TextStyle(
                        fontSize: 19.0,
                        fontWeight: FontWeight.w600,
                        color: ThemeColor.primary,
                      ),
                    ),
                    IconButton(
                      icon: const Icon(LineIcons.syncIcon),
                      padding: EdgeInsets.zero,
                      iconSize: 16.0,
                      splashRadius: 16.0,
                      color: ThemeColor.accent,
                      onPressed: () => BlocProvider.of<NewsBloc>(context).add(NewsEventRefresh()),
                    )
                  ],
                ),
              ),
              newsList(),
              newsListFooter(),
              const SizedBox(height: 20.0),
            ],
          ),
        ),
      ),
    );
  }

  void searchPicker() async {
    int? _pick = await showDialog(
      context: context,
      builder: (_) {
        return SearchPickerDialogTemplate();
      },
    );
    if (_pick != null) {
      if (_pick == 0) {
        Navigator.push(
          context,
          CupertinoPageRoute(
            builder: (context) {
              return BlocProvider(
                create: (_) => SearchPatientBloc(),
                child: StaffPageSearch(),
              );
            },
          ),
        );
      } else if (_pick == 1) {
        Navigator.push(
          context,
          CupertinoPageRoute(
            builder: (context) {
              return BlocProvider(
                create: (_) => SearchDoctorBloc(),
                child: StaffPageSearchDoctor(),
              );
            },
          ),
        );
      }
    }
  }

  Widget shortcutGrid() {
    return SizedBox(
      height: 380.0,
      width: double.maxFinite,
      child: GridView(
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          mainAxisSpacing: 15.0,
          crossAxisSpacing: 15.0,
        ),
        physics: const NeverScrollableScrollPhysics(),
        padding: const EdgeInsets.symmetric(vertical: 15.0, horizontal: 25.0),
        children: [
          ShortcutItemBig(
            title: "My Schedule",
            icon: LineIcons.calendarCheck,
            tooltip: "Manage your Weekly Schedule",
            builder: BlocProvider(
              create: (_) => StaffScheduleBloc(),
              child: StaffPageSchedule(),
            ),
          ),
          ShortcutItemBig(
            title: "My QR-Code",
            icon: LineIcons.qrcode,
            tooltip: "Show Auto-generated QR-Code",
            builder: PageQRCode(
              qrData: {
                "id": AppFirebase.uid(),
                "name": AppFirebase.staffData?.fullName ?? "No Name",
              },
            ),
            isCupertino: false,
          ),
          ShortcutItemBig(
            title: "Contact Tracing",
            icon: LineIcons.mapMarker,
            tooltip: "Contact Tracing",
            builder: BlocProvider(
              create: (_) => CovidGroupBloc(),
              child: StaffPageCovidTracker(),
            ),
          ),
          ShortcutItemBig(
            title: "History",
            icon: LineIcons.history,
            tooltip: "View your Past Appointments",
            builder: BlocProvider(
              create: (_) => AppointmentHistoryBloc(),
              child: StaffPageHistory(),
            ),
          ),
        ],
      ),
    );
  }

  Widget newsList() {
    return BlocBuilder<NewsBloc, ViewState>(
      builder: (context, state) {
        if (state is NewsStateSuccess) {
          if (state.isFailure) {
            return NewsListFailure(
              tryAgain: () {
                BlocProvider.of<NewsBloc>(context).add(NewsEventRequest());
              },
            );
          }
        }

        return SizedBox(
          height: 460,
          child: ListView.builder(
            itemCount: 4,
            physics: const NeverScrollableScrollPhysics(),
            padding: const EdgeInsets.symmetric(horizontal: 15.0, vertical: 10.0),
            itemBuilder: (context, index) {
              if (state is NewsStateSuccess) {
                return NewsListItem(model: state.list![index]);
              }
              return const NewsListItemShimmer();
            },
          ),
        );
      },
    );
  }

  Widget newsListFooter() {
    return SizedBox(
      height: 20.0,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Text(
            'Powered by ',
            style: const TextStyle(
              fontSize: 12.5,
              color: ThemeColor.secondary2,
            ),
          ),
          const SizedBox(width: 10.0),
          Image.asset(
            'assets/images/logo_mnt.png',
            fit: BoxFit.fill,
            cacheWidth: 100,
            width: 50.0,
          ),
        ],
      ),
    );
  }
}
