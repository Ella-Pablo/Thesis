import 'package:clinick/models/appointment_model.dart';
import 'package:equatable/equatable.dart';

abstract class StaffAppointmentState extends Equatable {
  const StaffAppointmentState();

  @override
  List<Object> get props => [];
}

class StaffAppointmentStateEmpty extends StaffAppointmentState {}

class StaffAppointmentStateInProgress extends StaffAppointmentState {}

class StaffAppointmentStateSuccess extends StaffAppointmentState {
  final List<AppointmentModel> appointments;
  final bool refresher;
  const StaffAppointmentStateSuccess({required this.appointments, required this.refresher});

  @override
  List<Object> get props => [appointments, refresher];
}

class StaffAppointmentStateFailed extends StaffAppointmentState {}
