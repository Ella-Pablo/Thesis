import 'package:equatable/equatable.dart';

abstract class StaffAppointmentEvent extends Equatable {
  const StaffAppointmentEvent();

  @override
  List<Object> get props => [];
}

class StaffAppointmentEventRequest extends StaffAppointmentEvent {}
