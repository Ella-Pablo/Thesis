import 'dart:async';

import 'package:clinick/database/app_firebase.dart';
import 'package:clinick/models/appointment_model.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../appointment_bloc/events.dart';
import '../appointment_bloc/states.dart';

class StaffAppointmentBloc extends Bloc<StaffAppointmentEvent, StaffAppointmentState> {
  StaffAppointmentBloc() : super(StaffAppointmentStateInProgress());

  StreamSubscription? subscription;
  List<AppointmentModel> appointments = [];
  bool refresher = true;

  @override
  Stream<StaffAppointmentState> mapEventToState(StaffAppointmentEvent event) async* {
    if (event is StaffAppointmentEventRequest) {
      yield StaffAppointmentStateInProgress();
      await Future.delayed(Duration(seconds: 1));

      subscription?.cancel();
      subscription = AppFirebase.firestore
          .collection('appointments')
          .where("staffid", isEqualTo: AppFirebase.uid())
          .snapshots()
          .listen(
        (event) {
          try {
            appointments.clear();

            for (var item in event.docs) {
              appointments.add(AppointmentModel.fromSnapshot(item.id, item.data()));
            }

            if (appointments.isEmpty) {
              emit(
                StaffAppointmentStateEmpty(),
              );
              return;
            }

            appointments.sort((a, b) => a.date!.millisecondsSinceEpoch.compareTo(b.date!.millisecondsSinceEpoch));

            refresher = !refresher;

            emit(StaffAppointmentStateSuccess(
              appointments: appointments,
              refresher: refresher,
            ));
          } catch (ex) {
            emit(
              StaffAppointmentStateFailed(),
            );
          }
        },
      );
    }
  }

  @override
  Future<void> close() {
    subscription?.cancel();
    return super.close();
  }
}
