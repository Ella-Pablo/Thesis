import 'package:clinick/blocs/messaging/list/bloc.dart';
import 'package:clinick/blocs/messaging/list/events.dart';
import 'package:clinick/blocs/messaging/list/states.dart';
import 'package:clinick/config/app_config.dart';
import 'package:clinick/config/color.dart';
import 'package:clinick/widgets/message_info_templates.dart';
import 'package:clinick/widgets/state_view_template.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:line_icons/line_icons.dart';

class StaffTabMessages extends StatefulWidget {
  @override
  _StaffTabMessagesState createState() => _StaffTabMessagesState();
}

class _StaffTabMessagesState extends State<StaffTabMessages> {
  @override
  void initState() {
    BlocProvider.of<MessageInfoBloc>(context).add(MessageInfoEventRequest());
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leadingWidth: 0.0,
        leading: const SizedBox(),
        titleSpacing: 0.0,
        toolbarHeight: 110.0,
        elevation: 0.0,
        flexibleSpace: Material(
          elevation: 5.0,
          borderRadius: BorderRadius.circular(15.0),
          color: ThemeColor.background,
          shadowColor: ThemeColor.shadow.withOpacity(0.35),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20.0, 35.0, 15.0, 0.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Messages",
                  style: const TextStyle(
                    fontSize: 35.0,
                    color: ThemeColor.accent,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                const SizedBox(height: 5.0),
                Center(
                  child: TextField(
                    decoration: const InputDecoration(
                      contentPadding: const EdgeInsets.fromLTRB(15.0, 13.0, 15.0, 10.0),
                      hintText: 'Search',
                      hintStyle: const TextStyle(
                        color: ThemeColor.inputHint,
                        fontSize: 16.0,
                      ),
                      enabledBorder: InputBorder.none,
                      focusedBorder: InputBorder.none,
                      prefixIcon: const Icon(
                        LineIcons.search,
                        color: ThemeColor.secondary2,
                      ),
                    ),
                    style: const TextStyle(
                      fontSize: 17.0,
                      color: ThemeColor.secondary,
                    ),
                    onChanged: (text) {
                      if (text.length > 0 && text.length < 4) return;
                      BlocProvider.of<MessageInfoBloc>(context).add(
                        MessageInfoEventSearch(keywords: text),
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
      body: SafeArea(
        child: Column(
          children: [
            const SizedBox(height: 15.0),
            Expanded(
              child: BlocBuilder<MessageInfoBloc, MessageInfoState>(
                builder: (context, state) {
                  if (state is MessageInfoStateSuccess) {
                    return ListView.builder(
                      itemCount: state.conversations.length,
                      itemBuilder: (context, index) {
                        return MessageInfoItem(
                          model: state.conversations[index],
                          showToolbar: true,
                          checkIfStaffToStaff: true,
                        );
                      },
                    );
                  } else if (state is MessageInfoStateInProgress) {
                    return const Center(
                      child: const CircularProgressIndicator(
                        valueColor: AlwaysStoppedAnimation(ThemeColor.accent),
                      ),
                    );
                  } else if (state is MessageInfoStateFailed) {
                    return const Center(
                      child: const StateView(
                        title: "Sorry for the trouble!",
                        message: "We encountered an error while trying to fetch your conversations. Please try again.",
                        assetPath: AppConfig.asset_emptyImage,
                      ),
                    );
                  }

                  return const Center(
                    child: const StateView(
                      title: "Nothing to see here!",
                      message: "Start messaging by clicking the message icon on your search result items.",
                      assetPath: AppConfig.asset_emptyImage,
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
