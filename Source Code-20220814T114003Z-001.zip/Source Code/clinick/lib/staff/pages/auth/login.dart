import 'package:clinick/blocs/cubits/busy_state.dart';
import 'package:clinick/blocs/cubits/reset_password_state.dart';
import 'package:clinick/blocs/cubits/sign_up_state.dart';
import 'package:clinick/blocs/user_type_cubit.dart';
import 'package:clinick/config/app_config.dart';
import 'package:clinick/config/color.dart';
import 'package:clinick/config/labels.dart';
import 'package:clinick/database/app_firebase.dart';
import 'package:clinick/database/shared_pref.dart';
import 'package:clinick/models/message_info_model.dart';
import 'package:clinick/repository/helpers.dart';
import 'package:clinick/views/info_reader.dart';
import 'package:clinick/widgets/overlay_loader.dart';
import 'package:clinick/widgets/toast.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:email_validator/email_validator.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:line_icons/line_icons.dart';

import 'reset_password.dart';
import 'sign_up.dart';

class StaffPageLogin extends StatefulWidget {
  const StaffPageLogin();

  @override
  _StaffPageLoginState createState() => _StaffPageLoginState();
}

class _StaffPageLoginState extends State<StaffPageLogin> {
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();
  String email = "";
  String password = "";
  List<String> savedAccounts = [];
  TextEditingController emailTxtController = TextEditingController();

  @override
  void initState() {
    populateSaveAccounts();
    super.initState();
  }

  void populateSaveAccounts() async {
    savedAccounts = await SharedPrefs.instance.getRememberStaff();
  }

  void saveAccount() async {
    if (savedAccounts.contains("$email")) {
      savedAccounts.remove("$email");
    } else if (savedAccounts.length == 5) {
      savedAccounts.removeLast();
    }

    savedAccounts.insert(0, "$email");
    SharedPrefs.instance.saveRememberStaff(savedAccounts);
  }

  void showSuggestions() {
    FocusScope.of(context).requestFocus(FocusNode());
    if (savedAccounts.isEmpty) {
      toastGeneral("There is no saved accounts in this device.");
      return;
    }

    showDialog(
      context: context,
      builder: (_) {
        return Dialog(
          child: SizedBox(
            height: 320.0,
            child: Column(
              children: [
                Row(
                  children: [
                    const SizedBox(width: 20.0),
                    Text(
                      "Saved Accounts",
                      style: const TextStyle(
                        color: ThemeColor.primary,
                        fontSize: 16.0,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const Spacer(),
                    IconButton(
                      onPressed: () => Navigator.of(context).pop(),
                      icon: Icon(LineIcons.times),
                      color: ThemeColor.primary,
                      iconSize: 20.0,
                      splashRadius: 20.0,
                    ),
                  ],
                ),
                Expanded(
                  child: ListView.separated(
                    padding: const EdgeInsets.fromLTRB(10.0, 0.0, 10.0, 10.0),
                    itemBuilder: (context, index) {
                      return InkWell(
                        child: Padding(
                          padding: const EdgeInsets.all(10.0),
                          child: Text(savedAccounts[index]),
                        ),
                        onTap: () {
                          emailTxtController.text = savedAccounts[index];
                          Navigator.of(context).pop();
                        },
                      );
                    },
                    separatorBuilder: (context, index) {
                      return Divider(
                        height: 20.0,
                      );
                    },
                    itemCount: savedAccounts.length,
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  @override
  void dispose() {
    Helpers.changeStatusBarTheme(ThemeMode.dark);
    emailTxtController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final double _screenWidth = MediaQuery.of(context).size.width;
    precacheImage(AssetImage('assets/images/logo_banner_white.png'), context);

    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle(
        statusBarBrightness: Brightness.light,
        statusBarIconBrightness: Brightness.light,
      ),
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        backgroundColor: ThemeColor.accent,
        body: SafeArea(
          child: BlocBuilder<BusyStateCubit, bool>(
            builder: (_, showOverlay) {
              return OverlayLoader(
                isBusy: showOverlay,
                color: Colors.white,
                backgroundColor: ThemeColor.accent,
                child: Form(
                  key: formKey,
                  child: SingleChildScrollView(
                    physics: const BouncingScrollPhysics(),
                    padding: const EdgeInsets.symmetric(horizontal: 20.0),
                    reverse: true,
                    child: Column(
                      children: [
                        Image.asset(
                          'assets/images/logo_banner_white.png',
                          fit: BoxFit.fill,
                          width: _screenWidth * 0.65,
                        ),
                        const SizedBox(height: 20),
                        Align(
                          alignment: Alignment.centerLeft,
                          child: MaterialButton(
                            onPressed: onPatientLogin,
                            child: SizedBox(
                              width: 150.0,
                              child: Row(
                                children: [
                                  const Icon(
                                    LineIcons.userTie,
                                    size: 20.0,
                                    color: ThemeColor.buttonTextColor,
                                  ),
                                  const SizedBox(width: 3.0),
                                  const Text('Go To Patient Login'),
                                ],
                              ),
                            ),
                            textColor: ThemeColor.buttonTextColor,
                          ),
                        ),
                        const SizedBox(height: 5),
                        SizedBox(
                          height: 45.0,
                          child: Stack(
                            children: [
                              Positioned.fill(
                                child: TextFormField(
                                  decoration: InputDecoration(
                                    fillColor: ThemeColor.background2,
                                    filled: true,
                                    contentPadding: const EdgeInsets.symmetric(
                                        horizontal: 15.0, vertical: 10.0),
                                    hintText: 'Email or phone number',
                                    hintStyle: TextStyle(
                                      color: ThemeColor.inputHint,
                                      fontSize: 14.0,
                                    ),
                                    enabledBorder: OutlineInputBorder(
                                      borderSide: BorderSide(
                                        width: 1.0,
                                        color: ThemeColor.inputBorder,
                                      ),
                                      borderRadius: BorderRadius.circular(15.0),
                                    ),
                                    focusedBorder: OutlineInputBorder(
                                      borderSide: BorderSide(
                                        width: 1.0,
                                        color: ThemeColor.accent,
                                      ),
                                      borderRadius: BorderRadius.circular(15.0),
                                    ),
                                    prefixIcon: Icon(
                                      LineIcons.user,
                                      color: ThemeColor.secondary2,
                                    ),
                                    suffixIcon: const SizedBox(
                                      width: 10.0,
                                    ),
                                  ),
                                  controller: emailTxtController,
                                  style: const TextStyle(fontSize: 15.0),
                                  onSaved: (text) => email = text ?? "",
                                ),
                              ),
                              Positioned(
                                right: 10,
                                top: 3,
                                bottom: 5,
                                width: 40.0,
                                child: Material(
                                  color: ThemeColor.background,
                                  child: IconButton(
                                    onPressed: () => showSuggestions(),
                                    icon: const Icon(Icons.arrow_drop_down),
                                    splashRadius: 16.0,
                                    color: ThemeColor.primary,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 10.0),
                        // INPUT FIELD: PASSWORD
                        SizedBox(
                          height: 45.0,
                          child: TextFormField(
                            decoration: InputDecoration(
                              fillColor: ThemeColor.background2,
                              filled: true,
                              contentPadding: const EdgeInsets.symmetric(
                                  horizontal: 15.0, vertical: 10.0),
                              hintText: 'Password',
                              hintStyle: TextStyle(
                                color: ThemeColor.inputHint,
                                fontSize: 14.0,
                              ),
                              enabledBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                  width: 1.0,
                                  color: ThemeColor.inputBorder,
                                ),
                                borderRadius: BorderRadius.circular(15.0),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                  width: 1.0,
                                  color: ThemeColor.accent,
                                ),
                                borderRadius: BorderRadius.circular(15.0),
                              ),
                              prefixIcon: Icon(
                                LineIcons.lock,
                                color: ThemeColor.secondary2,
                              ),
                            ),
                            style: const TextStyle(fontSize: 15.0),
                            obscureText: true,
                            onSaved: (text) => password = text ?? "",
                          ),
                        ),
                        SizedBox(height: 30.0),
                        MaterialButton(
                          onPressed: onLogin,
                          height: 45.0,
                          minWidth: double.maxFinite,
                          child: const Text('LOGIN'),
                          textColor: ThemeColor.primary,
                          color: ThemeColor.buttonTextColor,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(25.0),
                          ),
                        ),
                        const SizedBox(height: 10.0),

                        Row(
                          children: [
                            const Spacer(),
                            GestureDetector(
                              onTap: openResetPassword,
                              child: Text(
                                'Forgot Password',
                                style: TextStyle(
                                  backgroundColor: ThemeColor.accent,
                                  color: ThemeColor.background,
                                  fontSize: 14.0,
                                  fontWeight: FontWeight.w500,
                                  decoration: TextDecoration.underline,
                                ),
                              ),
                            ),
                            const SizedBox(width: 5.0),
                          ],
                        ),
                        const SizedBox(height: 50.0),

                        Divider(
                          height: 30.0,
                          color: ThemeColor.background2.withAlpha(150),
                        ),

                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const Text(
                              "Don't have an account? ",
                              style: const TextStyle(
                                fontSize: 14.0,
                              ),
                            ),
                            GestureDetector(
                              onTap: openSignUp,
                              child: Text(
                                'Sign Up',
                                style: TextStyle(
                                  backgroundColor: ThemeColor.accent,
                                  color: ThemeColor.background,
                                  fontSize: 14.0,
                                  fontWeight: FontWeight.w600,
                                  decoration: TextDecoration.underline,
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 50.0),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            GestureDetector(
                              onTap: openPrivacyPolicy,
                              child: const Text(
                                'Privacy Policy',
                                style: const TextStyle(
                                  fontSize: 11.0,
                                  color: ThemeColor.foreground,
                                  decoration: TextDecoration.underline,
                                ),
                              ),
                            ),
                            const SizedBox(width: 10.0),
                            GestureDetector(
                              onTap: openTerms,
                              child: const Text(
                                'Terms and conditions',
                                style: const TextStyle(
                                  fontSize: 11.0,
                                  color: ThemeColor.foreground,
                                  decoration: TextDecoration.underline,
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 5.0),
                        Text(
                          'Copyright © CLinicK. All rights reserved.',
                          style: TextStyle(
                            fontSize: 11.0,
                            color: ThemeColor.foreground,
                          ),
                        ),
                        const SizedBox(height: 10.0),
                      ],
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }

  void onLogin() async {
    FocusScope.of(context).requestFocus(FocusNode());
    BlocProvider.of<BusyStateCubit>(context).change(true);

    await Future.delayed(Duration(milliseconds: 500));
    formKey.currentState?.save();

    bool _hasError = false;
    bool _isEmail = true;

    // * Check if the field(s) are empty then do not continue
    if (email.isEmpty || password.isEmpty) {
      toastError("Please fill up the fields above.");
      _hasError = true;
    }

    if (!_hasError && email.startsWith("09") && email.length == 11) {
      _isEmail = false;

      for (int i = 0; i < email.length; i++) {
        if (!Helpers.isDigit(email, i)) {
          _hasError = true;
          toastError("Please enter a valid phone number.");
          break;
        }
      }
    }

    // * Validate Input Values
    if (!_hasError && _isEmail) {
      if (!EmailValidator.validate(email)) {
        toastError("Please enter a valid email address.");
        _hasError = true;
      }
    }

    if (_hasError) {
      await Future.delayed(Duration(seconds: 2));
      BlocProvider.of<BusyStateCubit>(context).change(false);
      return;
    }

    try {
      if (_isEmail) {
        QuerySnapshot _data = await AppFirebase.firestore
            .collection(AppConfig.table_staffdata)
            .where('email', isEqualTo: email)
            .get();
        if (_data.docs.isNotEmpty) {
          await AppFirebase.auth.signInWithEmailAndPassword(
            email: email,
            password: password,
          );

          saveAccount();
        } else {
          throw FirebaseAuthException(code: 'user-not-found');
        }
      } else {
        QuerySnapshot _data = await AppFirebase.firestore
            .collection(AppConfig.table_staffdata)
            .where('phone', isEqualTo: email)
            .get();
        if (_data.docs.isNotEmpty) {
          await AppFirebase.auth.signInWithEmailAndPassword(
            email: _data.docs.first.data()['email'] ?? "",
            password: password,
          );

          saveAccount();
        } else {
          throw FirebaseAuthException(code: 'user-not-found');
        }
      }
    } on FirebaseAuthException catch (ex) {
      final String _errorMessage = Labels.authExceptionCodesToString(ex.code);
      toastError(_errorMessage);
      BlocProvider.of<BusyStateCubit>(context).change(false);
    } on PlatformException catch (ex) {
      final String _errorMessage = Labels.authExceptionCodesToString(ex.code);
      toastError(_errorMessage);
      BlocProvider.of<BusyStateCubit>(context).change(false);
    } catch (ex) {
      final String _errorMessage =
          Labels.authExceptionCodesToString("app-error");
      toastError(_errorMessage);
      BlocProvider.of<BusyStateCubit>(context).change(false);
    }
  }

  void openSignUp() {
    FocusScope.of(context).requestFocus(FocusNode());
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) {
          return BlocProvider(
            create: (_) => SignUpStateCubit(),
            child: StaffPageSignUp(),
          );
        },
      ),
    );
  }

  void openResetPassword() {
    FocusScope.of(context).requestFocus(FocusNode());
    Navigator.push(
      context,
      CupertinoPageRoute(
        builder: (context) {
          return BlocProvider(
            create: (_) => ResetPasswordStateCubit(),
            child: StaffPageResetPassword(),
          );
        },
      ),
    );
  }

  void onPatientLogin() {
    FocusScope.of(context).requestFocus(FocusNode());
    BlocProvider.of<UserTypeCubit>(context).change(UserType.patient);
  }

  void openPrivacyPolicy() async {
    final String _msg = await DefaultAssetBundle.of(context)
        .loadString('assets/text/policy.txt');
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) {
          return PageInfoReader(title: 'Privacy Policy', message: _msg);
        },
      ),
    );
  }

  void openTerms() async {
    final String _msg = await DefaultAssetBundle.of(context)
        .loadString('assets/text/terms.txt');
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) {
          return PageInfoReader(title: 'Terms and Conditions', message: _msg);
        },
      ),
    );
  }
}
