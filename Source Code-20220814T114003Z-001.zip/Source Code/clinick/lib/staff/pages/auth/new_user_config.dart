import 'package:clinick/blocs/cubits/new_user_state.dart';
import 'package:clinick/blocs/cubits/phone_state.dart';
import 'package:clinick/config/color.dart';
import 'package:clinick/config/labels.dart';
import 'package:clinick/database/app_firebase.dart';
import 'package:clinick/models/staff_data_model.dart';
import 'package:clinick/widgets/toast.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:intl/intl.dart';
import 'package:line_icons/line_icons.dart';

class StaffPageNewUser extends StatefulWidget {
  const StaffPageNewUser();

  @override
  _StaffPageNewUserState createState() => _StaffPageNewUserState();
}

class _StaffPageNewUserState extends State<StaffPageNewUser> {
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();
  final ValueNotifier<int> selectedGender = ValueNotifier(0);
  String firstName = "";
  String middleName = "";
  String lastName = "";

  String phone = "";
  String address = "";
  ValueNotifier<int> selectedSpecialization = ValueNotifier(0);

  String verificationCode = "";
  String verificationId = "";

  DateTime selectedDate = DateTime.now();
  late final TextEditingController dateTextController;
  bool isPhoneVerified = false;
  final isBusy = false;

  @override
  void initState() {
    dateTextController = TextEditingController(
      text: DateFormat('MMMM dd, yyyy').format(selectedDate),
    );

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async => false,
      child: MultiBlocProvider(
        providers: [
          BlocProvider(create: (_) => PhoneStateCubit()),
          BlocProvider(create: (_) => NewUserStateCubit()),
        ],
        child: Scaffold(
          body: SafeArea(
            child: SizedBox.expand(
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                padding: const EdgeInsets.all(15.0),
                child: Builder(
                  builder: (blocContext) {
                    return BlocBuilder<PhoneStateCubit, bool>(
                      builder: (context, state) {
                        return Form(
                          key: formKey,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const SizedBox(height: 20.0),

                              Text(
                                'Welcome!',
                                style: TextStyle(
                                  fontSize: 45.0,
                                  color: ThemeColor.accent,
                                  fontWeight: FontWeight.w900,
                                ),
                              ),

                              Text(
                                'The Right Care At The Right Click!',
                                style: TextStyle(
                                  fontSize: 20.0,
                                  color: ThemeColor.secondary.withAlpha(200),
                                ),
                              ),

                              const SizedBox(height: 10.0),

                              Text(
                                'Let us get some of your basic information before you continue.',
                                style: TextStyle(
                                  fontSize: 15.0,
                                  color: ThemeColor.secondary.withAlpha(200),
                                ),
                              ),

                              if (!state) const SizedBox(height: 40.0),

                              // Name
                              if (!state)
                                Text(
                                  'General',
                                  style: TextStyle(
                                    color: ThemeColor.secondary,
                                  ),
                                ),

                              const SizedBox(height: 10.0),

                              // INPUT FIELD: First Name
                              if (!state)
                                SizedBox(
                                  height: 45.0,
                                  child: TextFormField(
                                    decoration: InputDecoration(
                                      fillColor: ThemeColor.background,
                                      filled: true,
                                      contentPadding: const EdgeInsets.symmetric(horizontal: 15.0, vertical: 10.0),
                                      hintText: 'First Name',
                                      hintStyle: TextStyle(
                                        color: ThemeColor.inputHint,
                                        fontSize: 14.0,
                                      ),
                                      enabledBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                          width: 1.0,
                                          color: ThemeColor.inputBorder,
                                        ),
                                        borderRadius: BorderRadius.circular(15.0),
                                      ),
                                      focusedBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                          width: 1.0,
                                          color: ThemeColor.accent,
                                        ),
                                        borderRadius: BorderRadius.circular(15.0),
                                      ),
                                    ),
                                    style: const TextStyle(fontSize: 15.0),
                                    keyboardType: TextInputType.text,
                                    onSaved: (text) => firstName = text ?? "",
                                  ),
                                ),

                              const SizedBox(height: 10.0),

                              // INPUT FIELD: Middle Name
                              if (!state)
                                SizedBox(
                                  height: 45.0,
                                  child: TextFormField(
                                    decoration: InputDecoration(
                                      fillColor: ThemeColor.background,
                                      filled: true,
                                      contentPadding: const EdgeInsets.symmetric(horizontal: 15.0, vertical: 10.0),
                                      hintText: 'Middle Name',
                                      hintStyle: TextStyle(
                                        color: ThemeColor.inputHint,
                                        fontSize: 14.0,
                                      ),
                                      enabledBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                          width: 1.0,
                                          color: ThemeColor.inputBorder,
                                        ),
                                        borderRadius: BorderRadius.circular(15.0),
                                      ),
                                      focusedBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                          width: 1.0,
                                          color: ThemeColor.accent,
                                        ),
                                        borderRadius: BorderRadius.circular(15.0),
                                      ),
                                    ),
                                    style: const TextStyle(fontSize: 15.0),
                                    keyboardType: TextInputType.text,
                                    onSaved: (text) => middleName = text ?? "",
                                  ),
                                ),

                              const SizedBox(height: 10.0),

                              // INPUT FIELD: Last Name
                              if (!state)
                                SizedBox(
                                  height: 45.0,
                                  child: TextFormField(
                                    decoration: InputDecoration(
                                      fillColor: ThemeColor.background,
                                      filled: true,
                                      contentPadding: const EdgeInsets.symmetric(horizontal: 15.0, vertical: 10.0),
                                      hintText: 'Last Name',
                                      hintStyle: TextStyle(
                                        color: ThemeColor.inputHint,
                                        fontSize: 14.0,
                                      ),
                                      enabledBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                          width: 1.0,
                                          color: ThemeColor.inputBorder,
                                        ),
                                        borderRadius: BorderRadius.circular(15.0),
                                      ),
                                      focusedBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                          width: 1.0,
                                          color: ThemeColor.accent,
                                        ),
                                        borderRadius: BorderRadius.circular(15.0),
                                      ),
                                    ),
                                    style: const TextStyle(fontSize: 15.0),
                                    keyboardType: TextInputType.text,
                                    onSaved: (text) => lastName = text ?? "",
                                  ),
                                ),

                              if (!state) const SizedBox(height: 20.0),

                              if (!state)
                                Text(
                                  'Select your Gender',
                                  style: TextStyle(
                                    color: ThemeColor.secondary,
                                  ),
                                ),

                              if (!state) const SizedBox(height: 10.0),

                              if (!state)
                                SizedBox(
                                  height: 45,
                                  child: ValueListenableBuilder<int>(
                                    valueListenable: selectedGender,
                                    builder: (_, value, __) {
                                      return Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                        children: [
                                          GestureDetector(
                                            onTap: () => value == 1 ? selectedGender.value = 0 : null,
                                            child: Container(
                                              color: value == 0 ? null : ThemeColor.background2,
                                              padding: const EdgeInsets.fromLTRB(0.0, 5.0, 8.0, 5.0),
                                              decoration: value == 0
                                                  ? BoxDecoration(
                                                      border: Border.all(
                                                        width: 2.0,
                                                        color: ThemeColor.accent,
                                                      ),
                                                    )
                                                  : null,
                                              child: Row(
                                                children: [
                                                  Icon(
                                                    LineIcons.male,
                                                    size: 27.0,
                                                    color: value == 0 ? ThemeColor.accent : ThemeColor.secondary2,
                                                  ),
                                                  const SizedBox(width: 5.0),
                                                  Text(
                                                    'I am a male',
                                                    style: TextStyle(
                                                      color: value == 0 ? ThemeColor.accent : ThemeColor.secondary2,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                          GestureDetector(
                                            onTap: () => value == 0 ? selectedGender.value = 1 : null,
                                            child: Container(
                                              color: value == 1 ? null : ThemeColor.background2,
                                              padding: const EdgeInsets.fromLTRB(0.0, 5.0, 8.0, 5.0),
                                              decoration: value == 1
                                                  ? BoxDecoration(
                                                      border: Border.all(
                                                        width: 2.0,
                                                        color: ThemeColor.accent,
                                                      ),
                                                    )
                                                  : null,
                                              child: Row(
                                                children: [
                                                  Icon(
                                                    LineIcons.female,
                                                    size: 27.0,
                                                    color: value == 1 ? ThemeColor.accent : ThemeColor.secondary2,
                                                  ),
                                                  const SizedBox(width: 5.0),
                                                  Text(
                                                    'I am a female',
                                                    style: TextStyle(
                                                      color: value == 1 ? ThemeColor.accent : ThemeColor.secondary2,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ],
                                      );
                                    },
                                  ),
                                ),

                              if (!state) const SizedBox(height: 20.0),

                              // Birthdate
                              if (!state)
                                Text(
                                  'Birthdate',
                                  style: TextStyle(
                                    color: ThemeColor.secondary,
                                  ),
                                ),

                              if (!state) const SizedBox(height: 10.0),

                              if (!state)
                                SizedBox(
                                  height: 45.0,
                                  child: TextFormField(
                                    decoration: InputDecoration(
                                      fillColor: ThemeColor.background,
                                      filled: true,
                                      contentPadding: const EdgeInsets.symmetric(horizontal: 15.0, vertical: 10.0),
                                      enabledBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                          width: 1.0,
                                          color: ThemeColor.inputBorder,
                                        ),
                                        borderRadius: BorderRadius.circular(15.0),
                                      ),
                                      focusedBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                          width: 1.0,
                                          color: ThemeColor.accent,
                                        ),
                                        borderRadius: BorderRadius.circular(15.0),
                                      ),
                                      suffixIcon: GestureDetector(
                                        onTap: () => datePicker(),
                                        child: Icon(
                                          LineIcons.calendar,
                                          color: ThemeColor.accent,
                                        ),
                                      ),
                                    ),
                                    controller: dateTextController,
                                    readOnly: true,
                                    style: const TextStyle(fontSize: 15.0),
                                  ),
                                ),

                              if (!state) const SizedBox(height: 20.0),

                              // Contact Information
                              if (!state)
                                Text(
                                  'Contact Information',
                                  style: TextStyle(
                                    color: ThemeColor.secondary,
                                  ),
                                ),

                              if (!state) const SizedBox(height: 10.0),

                              // INPUT FIELD: Address
                              if (!state)
                                SizedBox(
                                  height: 45.0,
                                  child: TextFormField(
                                    decoration: InputDecoration(
                                      fillColor: ThemeColor.background,
                                      filled: true,
                                      contentPadding: const EdgeInsets.symmetric(horizontal: 15.0, vertical: 10.0),
                                      hintText: 'Address',
                                      hintStyle: TextStyle(
                                        color: ThemeColor.inputHint,
                                        fontSize: 14.0,
                                      ),
                                      enabledBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                          width: 1.0,
                                          color: ThemeColor.inputBorder,
                                        ),
                                        borderRadius: BorderRadius.circular(15.0),
                                      ),
                                      focusedBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                          width: 1.0,
                                          color: ThemeColor.accent,
                                        ),
                                        borderRadius: BorderRadius.circular(15.0),
                                      ),
                                    ),
                                    style: const TextStyle(fontSize: 15.0),
                                    keyboardType: TextInputType.text,
                                    onSaved: (text) => address = text ?? "",
                                  ),
                                ),

                              if (!state) const SizedBox(height: 10.0),

                              // INPUT FIELD: Phone
                              if (!state)
                                SizedBox(
                                  height: 70.0,
                                  child: TextFormField(
                                    decoration: InputDecoration(
                                      fillColor: ThemeColor.background,
                                      filled: true,
                                      contentPadding: const EdgeInsets.symmetric(horizontal: 15.0, vertical: 10.0),
                                      hintText: 'Phone Number',
                                      hintStyle: TextStyle(
                                        color: ThemeColor.inputHint,
                                        fontSize: 14.0,
                                      ),
                                      enabledBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                          width: 1.0,
                                          color: ThemeColor.inputBorder,
                                        ),
                                        borderRadius: BorderRadius.circular(15.0),
                                      ),
                                      focusedBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                          width: 1.0,
                                          color: ThemeColor.accent,
                                        ),
                                        borderRadius: BorderRadius.circular(15.0),
                                      ),
                                      prefixIcon: Icon(
                                        LineIcons.phone,
                                        color: ThemeColor.accent,
                                      ),
                                    ),
                                    maxLength: 11,
                                    style: const TextStyle(fontSize: 15.0),
                                    keyboardType: TextInputType.number,
                                    onSaved: (text) {
                                      if (!state) phone = text ?? "";
                                    },
                                  ),
                                ),

                              if (!state) const SizedBox(height: 15.0),

                              if (!state)
                                Text(
                                  'Specialization',
                                  style: TextStyle(
                                    color: ThemeColor.secondary,
                                  ),
                                ),

                              if (!state) const SizedBox(height: 10.0),

                              // DROP DOWN: Specialization
                              if (!state)
                                SizedBox(
                                  height: 45.0,
                                  child: ValueListenableBuilder<int>(
                                    valueListenable: selectedSpecialization,
                                    builder: (_, value, __) {
                                      return DropdownButtonFormField<int>(
                                        decoration: InputDecoration(
                                          fillColor: ThemeColor.background,
                                          filled: true,
                                          contentPadding: const EdgeInsets.symmetric(horizontal: 5.0, vertical: 10.0),
                                          hintText: 'Select your specialization',
                                          hintStyle: TextStyle(
                                            color: ThemeColor.inputHint,
                                            fontSize: 14.0,
                                          ),
                                          enabledBorder: OutlineInputBorder(
                                            borderSide: BorderSide(
                                              width: 1.0,
                                              color: ThemeColor.inputBorder,
                                            ),
                                            borderRadius: BorderRadius.circular(15.0),
                                          ),
                                          focusedBorder: OutlineInputBorder(
                                            borderSide: BorderSide(
                                              width: 1.0,
                                              color: ThemeColor.accent,
                                            ),
                                            borderRadius: BorderRadius.circular(15.0),
                                          ),
                                          prefixIcon: Icon(
                                            LineIcons.medicalBriefcase,
                                            color: ThemeColor.accent,
                                          ),
                                        ),
                                        value: value,
                                        style: const TextStyle(
                                          color: ThemeColor.primary,
                                          fontSize: 15.0,
                                        ),
                                        onChanged: (index) => selectedSpecialization.value = index!,
                                        items: StaffSpecializationTypes.values.map(
                                          (e) {
                                            return DropdownMenuItem(
                                              child: Text(e.asString),
                                              value: e.index,
                                            );
                                          },
                                        ).toList(),
                                      );
                                    },
                                  ),
                                ),

                              if (!state) const SizedBox(height: 40.0),

                              state
                                  ? SizedBox(
                                      height: 95.0,
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            'Please verify your phone number',
                                            style: TextStyle(
                                              color: ThemeColor.accent,
                                              fontWeight: FontWeight.bold,
                                            ),
                                          ),
                                          const SizedBox(height: 10.0),
                                          TextFormField(
                                            decoration: InputDecoration(
                                              fillColor: ThemeColor.background,
                                              filled: true,
                                              contentPadding:
                                                  const EdgeInsets.symmetric(horizontal: 15.0, vertical: 10.0),
                                              hintText: 'Verification Code',
                                              hintStyle: TextStyle(
                                                color: ThemeColor.inputHint,
                                                fontSize: 14.0,
                                              ),
                                              enabledBorder: OutlineInputBorder(
                                                borderSide: BorderSide(
                                                  width: 1.0,
                                                  color: ThemeColor.inputBorder,
                                                ),
                                                borderRadius: BorderRadius.circular(15.0),
                                              ),
                                              focusedBorder: OutlineInputBorder(
                                                borderSide: BorderSide(
                                                  width: 1.0,
                                                  color: ThemeColor.accent,
                                                ),
                                                borderRadius: BorderRadius.circular(15.0),
                                              ),
                                            ),
                                            style: const TextStyle(fontSize: 15.0),
                                            keyboardType: TextInputType.number,
                                            onSaved: (text) => verificationCode = text ?? "",
                                          ),
                                          const SizedBox(height: 5.0),
                                          Row(
                                            mainAxisAlignment: MainAxisAlignment.end,
                                            children: [
                                              GestureDetector(
                                                onTap: () => resendVerification(blocContext),
                                                child: Text(
                                                  "Resend",
                                                  style: TextStyle(
                                                    fontSize: 13.0,
                                                    color: ThemeColor.accent,
                                                    decoration: TextDecoration.underline,
                                                  ),
                                                ),
                                              ),
                                              const SizedBox(width: 5.0),
                                            ],
                                          ),
                                        ],
                                      ),
                                    )
                                  : const SizedBox(),

                              const SizedBox(height: 40.0),

                              BlocBuilder<NewUserStateCubit, bool>(
                                builder: (context, userState) {
                                  if (!userState) {
                                    return MaterialButton(
                                      onPressed: () => addUser(blocContext),
                                      minWidth: double.maxFinite,
                                      height: 45.0,
                                      child: Text(state ? 'VERIFY' : 'SUBMIT'),
                                      textColor: ThemeColor.buttonTextColor,
                                      color: ThemeColor.accent,
                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(25.0),
                                      ),
                                    );
                                  }
                                  return const Center(
                                      child: const CircularProgressIndicator(
                                    valueColor: AlwaysStoppedAnimation(ThemeColor.accent),
                                  ));
                                },
                              ),

                              const SizedBox(height: 10.0),

                              BlocBuilder<NewUserStateCubit, bool>(
                                builder: (context, userState) {
                                  if (!userState) {
                                    return MaterialButton(
                                      onPressed: () async {
                                        toastGeneral("Logging out of CLinicK..");
                                        await AppFirebase.signOut();
                                      },
                                      minWidth: double.maxFinite,
                                      height: 45.0,
                                      child: const Text('LOGOUT'),
                                      color: ThemeColor.buttonTextColor,
                                      textColor: ThemeColor.accent,
                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(25.0),
                                      ),
                                    );
                                  }
                                  return const SizedBox();
                                },
                              ),
                              const SizedBox(height: 20.0),
                            ],
                          ),
                        );
                      },
                    );
                  },
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  void datePicker() async {
    final _pickedDate = await showDatePicker(
      context: context,
      initialDate: selectedDate,
      firstDate: DateTime(1900),
      lastDate: DateTime.now(),
      builder: (BuildContext context, Widget? child) {
        return Theme(
          data: ThemeData.light().copyWith(
            primaryColor: ThemeColor.accent,
            accentColor: ThemeColor.accent,
            colorScheme: ColorScheme.light(
              primary: ThemeColor.accent,
            ),
            buttonTheme: ButtonThemeData(
              textTheme: ButtonTextTheme.primary,
            ),
          ),
          child: child!,
        );
      },
    );
    if (_pickedDate != null) {
      selectedDate = _pickedDate;
      dateTextController.text = DateFormat('MMMM dd, yyyy').format(selectedDate);
    }
  }

  void addUser(BuildContext blocContext) async {
    FocusScope.of(context).requestFocus(FocusNode());
    final bool _isBusy = blocContext.read<NewUserStateCubit>().state;
    final bool _isVerifying = !blocContext.read<PhoneStateCubit>().state;

    // * Check if the process is currently busy, if yes, do not continue
    if (_isBusy) return;
    blocContext.read<NewUserStateCubit>().change(true);
    await Future.delayed(Duration(milliseconds: 500));
    formKey.currentState?.save();

    bool _hasError = false;

    // * Check inputs for null, empty, and confirm password:
    if (phone.isEmpty || firstName.isEmpty || lastName.isEmpty || address.isEmpty) {
      toastError("Please complete all the required fields.");
      _hasError = true;
    }

    // * Validate Phone
    if (!_hasError && (phone.length < 11 || !phone.startsWith('09'))) {
      toastError("Please enter a valid phone number.");
      _hasError = true;
    }

    if (_hasError) {
      await Future.delayed(Duration(seconds: 2));
      blocContext.read<NewUserStateCubit>().change(false);
      return;
    }

    if (!isPhoneVerified) {
      if (_isVerifying) {
        // * Send a verification code:
        await sendVerificationCode(blocContext);
      } else {
        // * Check verification code
        if (verificationCode.isEmpty) {
          toastError("Please enter the verification code to continue");
          await Future.delayed(Duration(seconds: 2));
          blocContext.read<NewUserStateCubit>().change(false);
          return;
        } else {
          await checkVerificationCode(blocContext);
        }
      }
    }

    if (isPhoneVerified) {
      try {
        StaffDataModel _data = StaffDataModel(
          firstName: firstName,
          middleName: middleName,
          lastName: lastName,
          birthdate: selectedDate,
          gender: selectedGender.value,
          address: address,
          phone: phone,
          email: AppFirebase.auth.currentUser!.email,
          specialization: StaffSpecializationTypes.values[selectedSpecialization.value],
        );

        await AppFirebase.addUpdateStaffData(_data);
        await AppFirebase.auth.currentUser?.reload();
      } catch (ex) {
        toastError("Unable to update your user data. Please try again.");
        await Future.delayed(Duration(seconds: 1));
        blocContext.read<NewUserStateCubit>().change(false);
      }
    }
  }

  void resendVerification(BuildContext blocContext) async {
    FocusScope.of(context).requestFocus(FocusNode());
    final bool _isBusy = blocContext.read<NewUserStateCubit>().state;

    // * Check if the process is currently busy, if yes, do not continue
    if (_isBusy) return;
    blocContext.read<NewUserStateCubit>().change(true);

    await Future.delayed(Duration(seconds: 1));
    await sendVerificationCode(blocContext);

    blocContext.read<NewUserStateCubit>().change(false);
  }

  Future<void> checkVerificationCode(BuildContext blocContext) async {
    // * Check the entered verification
    final AuthCredential _credential = PhoneAuthProvider.credential(
      verificationId: verificationId,
      smsCode: verificationCode,
    );
    try {
      final UserCredential? user = await AppFirebase.auth.currentUser?.linkWithCredential(_credential);

      if (user != null) {
        isPhoneVerified = true;
      }
    } on FirebaseAuthException catch (ex) {
      final String _errorMessage = Labels.authExceptionCodesToString(ex.code);
      toastError(_errorMessage);
      blocContext.read<NewUserStateCubit>().change(false);
    } on PlatformException catch (ex) {
      final String _errorMessage = Labels.authExceptionCodesToString(ex.code);
      toastError(_errorMessage);
      blocContext.read<NewUserStateCubit>().change(false);
    } catch (ex) {
      final String _errorMessage = Labels.authExceptionCodesToString("app-error");
      toastError(_errorMessage);
      blocContext.read<NewUserStateCubit>().change(false);
    }
  }

  Future<void> sendVerificationCode(BuildContext blocContext) async {
    final bool _isVerifying = !blocContext.read<PhoneStateCubit>().state;
    if (_isVerifying) {
      toastGeneral("Sending verification code to your phone number '+63${phone.substring(1)}'");
    } else {
      toastGeneral("Resending verification code to your phone number '+63${phone.substring(1)}'");
    }

    final PhoneVerificationCompleted verificationCompleted = (PhoneAuthCredential phoneAuthCredential) async {
      await checkVerificationCode(blocContext);
    };

    final PhoneVerificationFailed verificationFailed = (FirebaseAuthException authException) {
      final String _errorMessage = Labels.authExceptionCodesToString(authException.code);
      toastError(_errorMessage);
      blocContext.read<NewUserStateCubit>().change(false);
    };

    final PhoneCodeAutoRetrievalTimeout codeAutoRetrievalTimeout = (String id) {
      verificationId = id;
    };

    final PhoneCodeSent codeSent = (String id, int? forceResendingToken) async {
      toastGeneral("Please check your phone's inbox for the verification code.");
      verificationId = id;

      // * Show verification field
      blocContext.read<PhoneStateCubit>().change(true);
      blocContext.read<NewUserStateCubit>().change(false);
    };

    await AppFirebase.auth.verifyPhoneNumber(
      phoneNumber: "+63" + phone.substring(1),
      verificationCompleted: verificationCompleted,
      verificationFailed: verificationFailed,
      codeSent: codeSent,
      codeAutoRetrievalTimeout: codeAutoRetrievalTimeout,
    );
  }
}
