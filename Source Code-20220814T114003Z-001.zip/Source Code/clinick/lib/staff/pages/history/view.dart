import 'dart:async';

import 'package:clinick/config/app_config.dart';
import 'package:clinick/config/color.dart';
import 'package:clinick/models/appointment_model.dart';
import 'package:clinick/staff/pages/history/blocs/events.dart';
import 'package:clinick/staff/pages/history/blocs/states.dart';
import 'package:clinick/staff/tabs/appointments/event_item_template.dart';
import 'package:clinick/widgets/state_view_template.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:line_icons/line_icons.dart';

import 'blocs/bloc.dart';

class StaffPageHistory extends StatefulWidget {
  @override
  _StaffPageHistoryState createState() => _StaffPageHistoryState();
}

class _StaffPageHistoryState extends State<StaffPageHistory> {
  Completer<void> refreshCompleter = Completer<void>();

  @override
  void initState() {
    BlocProvider.of<AppointmentHistoryBloc>(context).add(AppointmentHistoryEventRequest());
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0.0,
        leading: const SizedBox(),
        leadingWidth: 0.0,
        elevation: 0.0,
        title: Row(
          children: [
            const SizedBox(width: 10.0),
            IconButton(
              icon: const Icon(
                LineIcons.arrowLeft,
                color: ThemeColor.primary,
              ),
              splashRadius: 24.0,
              padding: const EdgeInsets.all(8.0),
              onPressed: () => Navigator.of(context).pop(),
            ),
            const SizedBox(width: 15.0),
            const Text(
              'Appointment History',
              style: const TextStyle(
                fontSize: 17.0,
                fontWeight: FontWeight.bold,
                color: ThemeColor.primary,
              ),
            ),
          ],
        ),
      ),
      body: RefreshIndicator(
        onRefresh: () {
          BlocProvider.of<AppointmentHistoryBloc>(context).add(AppointmentHistoryEventRefresh());
          return refreshCompleter.future;
        },
        child: BlocBuilder<AppointmentHistoryBloc, AppointmentHistoryState>(
          builder: (context, state) {
            if (state is AppointmentHistoryStateSuccess) {
              refreshCompleter.complete();
              refreshCompleter = Completer<void>();
              return CustomScrollView(
                physics: const BouncingScrollPhysics(),
                slivers: [
                  SliverList(
                    delegate: SliverChildBuilderDelegate(
                      (_, index) {
                        final AppointmentModel model = state.history[index];
                        return StaffEventItemTemplate(
                          model: model,
                          margin: const EdgeInsets.symmetric(vertical: 5.0, horizontal: 15.0),
                          showStatus: false,
                        );
                      },
                      childCount: state.history.length,
                    ),
                  ),
                  if (!state.hasReachedLimit && state.isLoading)
                    SliverToBoxAdapter(
                      child: const SizedBox(
                        height: 100.0,
                        child: Center(
                          child: const CircularProgressIndicator(
                            valueColor: AlwaysStoppedAnimation(
                              ThemeColor.accent,
                            ),
                          ),
                        ),
                      ),
                    ),
                  if (!state.hasReachedLimit && !state.isLoading)
                    SliverToBoxAdapter(
                      child: SizedBox(
                        height: 80.0,
                        child: Center(
                          child: MaterialButton(
                            onPressed: () => BlocProvider.of<AppointmentHistoryBloc>(context)
                                .add(AppointmentHistoryEventRequestNext()),
                            child: const Text('Show More'),
                            padding: const EdgeInsets.symmetric(horizontal: 15.0, vertical: 8.0),
                            color: ThemeColor.accent,
                            textColor: ThemeColor.buttonTextColor,
                          ),
                        ),
                      ),
                    ),
                  if (state.hasReachedLimit)
                    SliverToBoxAdapter(
                      child: const SizedBox(height: 30.0),
                    ),
                ],
              );
            } else if (state is AppointmentHistoryStateFailed) {
              return StateView(
                title: 'Sorry for the trouble!',
                message: "We encountered an error while trying to retrieve your history. Please try again.",
                assetPath: AppConfig.asset_failedImage,
              );
            } else if (state is AppointmentHistoryStateEmpty) {
              return StateView(
                title: 'Nothing to see here!',
                message:
                    "It seems that you don't have any completed appointment yet. Make sure that you mark your compeleted appointment as done.",
                assetPath: AppConfig.asset_emptyImage,
              );
            } else if (state is AppointmentHistoryStateInProgress) {
              return const Center(
                child: const CircularProgressIndicator(
                  valueColor: AlwaysStoppedAnimation(
                    ThemeColor.accent,
                  ),
                ),
              );
            }
            return const SizedBox();
          },
        ),
      ),
    );
  }
}
