import 'package:equatable/equatable.dart';

abstract class AppointmentHistoryEvent extends Equatable {
  const AppointmentHistoryEvent();

  @override
  List<Object> get props => [];
}

class AppointmentHistoryEventRequest extends AppointmentHistoryEvent {}

class AppointmentHistoryEventRequestNext extends AppointmentHistoryEvent {}

class AppointmentHistoryEventRefresh extends AppointmentHistoryEvent {}
