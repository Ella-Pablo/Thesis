import 'package:clinick/models/appointment_model.dart';
import 'package:equatable/equatable.dart';

abstract class AppointmentHistoryState extends Equatable {
  const AppointmentHistoryState();

  @override
  List<Object> get props => [];
}

class AppointmentHistoryStateEmpty extends AppointmentHistoryState {}

class AppointmentHistoryStateInProgress extends AppointmentHistoryState {}

class AppointmentHistoryStateSuccess extends AppointmentHistoryState {
  final List<AppointmentModel> history;
  final bool hasReachedLimit;
  final bool isLoading;
  AppointmentHistoryStateSuccess({required this.history, required this.hasReachedLimit, required this.isLoading});

  @override
  List<Object> get props => [history, hasReachedLimit, isLoading];
}

class AppointmentHistoryStateFailed extends AppointmentHistoryState {}
