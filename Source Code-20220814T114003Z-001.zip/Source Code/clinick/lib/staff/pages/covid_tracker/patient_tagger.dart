import 'package:clinick/config/app_config.dart';
import 'package:clinick/config/color.dart';
import 'package:clinick/staff/pages/covid_tracker/blocs/tagger_bloc/bloc.dart';
import 'package:clinick/staff/pages/covid_tracker/blocs/tagger_bloc/events.dart';
import 'package:clinick/staff/pages/covid_tracker/blocs/tagger_bloc/states.dart';
import 'package:clinick/widgets/overlay_loader.dart';
import 'package:clinick/widgets/state_view_template.dart';
import 'package:clinick/widgets/toast.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:line_icons/line_icons.dart';

import 'covid_tagger_template.dart';

class StaffPageCovidTagger extends StatefulWidget {
  const StaffPageCovidTagger({required this.userUid, required this.userName});
  final String userUid;
  final String userName;
  @override
  _StaffPageCovidTaggerState createState() => _StaffPageCovidTaggerState();
}

class _StaffPageCovidTaggerState extends State<StaffPageCovidTagger> {
  ValueNotifier<bool> isBusy = ValueNotifier(false);

  @override
  void initState() {
    BlocProvider.of<CovidTaggerBloc>(context).add(CovidTaggerEventRequest(userUid: widget.userUid));
    super.initState();
  }

  @override
  void dispose() {
    isBusy.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<bool>(
      valueListenable: isBusy,
      builder: (_, value, __) {
        return OverlayLoader(
          isBusy: value,
          child: Scaffold(
            appBar: AppBar(
              titleSpacing: 0.0,
              leading: const SizedBox(),
              leadingWidth: 0.0,
              elevation: 0.0,
              title: Row(
                children: [
                  const SizedBox(width: 10.0),
                  IconButton(
                    icon: const Icon(
                      LineIcons.arrowLeft,
                      color: ThemeColor.primary,
                    ),
                    splashRadius: 24.0,
                    padding: const EdgeInsets.all(8.0),
                    onPressed: () => Navigator.of(context).pop(),
                  ),
                  const SizedBox(width: 15.0),
                  const Text(
                    'Contact Tracing',
                    style: const TextStyle(
                      fontSize: 17.0,
                      fontWeight: FontWeight.bold,
                      color: ThemeColor.primary,
                    ),
                  ),
                  const Spacer(),
                  IconButton(
                    tooltip: 'Confirm',
                    icon: Icon(LineIcons.doubleCheck),
                    color: ThemeColor.accent,
                    splashRadius: 24.0,
                    onPressed: onConfirm,
                  ),
                  const SizedBox(width: 5.0),
                ],
              ),
            ),
            body: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 15.0),
              child: Column(
                children: [
                  const SizedBox(height: 5.0),
                  Material(
                    elevation: 12.0,
                    borderRadius: BorderRadius.circular(15.0),
                    color: ThemeColor.background,
                    shadowColor: ThemeColor.shadow.withOpacity(0.35),
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(10.0, 15.0, 15.0, 15.0),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Icon(
                            LineIcons.infoCircle,
                            size: 20.0,
                            color: ThemeColor.accent,
                          ),
                          const SizedBox(width: 5.0),
                          Expanded(
                            child: Text(
                              "Below is the Person Under Investigation (PUI) list referenced to patient '${widget.userName}'. All of the people in the list will be notified immediately upon confirmation.",
                              textAlign: TextAlign.justify,
                              style: const TextStyle(
                                fontSize: 12.0,
                                color: ThemeColor.secondary,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 20.0),
                  Expanded(
                    child: BlocBuilder<CovidTaggerBloc, CovidTaggerState>(
                      builder: (context, state) {
                        if (state is CovidTaggerStateSuccess) {
                          if (state.trackers.isNotEmpty) {
                            return ListView.separated(
                              physics: const BouncingScrollPhysics(parent: const AlwaysScrollableScrollPhysics()),
                              itemCount: state.trackers.length,
                              separatorBuilder: (context, index) => const SizedBox(height: 10.0),
                              itemBuilder: (context, index) {
                                return CovidTaggerItemTemplate(
                                  model: state.trackers[index],
                                );
                              },
                            );
                          }
                        } else if (state is CovidTaggerStateFailed) {
                          final double w = MediaQuery.of(context).size.width;
                          return SingleChildScrollView(
                            physics: const BouncingScrollPhysics(parent: const AlwaysScrollableScrollPhysics()),
                            child: Column(
                              children: [
                                StateView(
                                  title: 'Sorry for the trouble!',
                                  message:
                                      "We encountered an error while trying to process the request. Please try again.",
                                  assetPath: AppConfig.asset_failedImage,
                                  imageSize: Size(w * 0.55, w * 0.45),
                                ),
                              ],
                            ),
                          );
                        } else if (state is CovidTaggerStateInProgress) {
                          return const Center(
                            child: const CircularProgressIndicator(
                              valueColor: AlwaysStoppedAnimation(
                                ThemeColor.accent,
                              ),
                            ),
                          );
                        }

                        final double w = MediaQuery.of(context).size.width;
                        return SingleChildScrollView(
                          physics: const BouncingScrollPhysics(parent: const AlwaysScrollableScrollPhysics()),
                          child: Column(
                            children: [
                              StateView(
                                title: 'Nothing to see here!',
                                message:
                                    "It seems that no one has been in contact with this patient during his/her stay in the clinic.",
                                assetPath: AppConfig.asset_emptyImage,
                                imageSize: Size(w * 0.55, w * 0.45),
                              ),
                            ],
                          ),
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  void onConfirm() async {
    isBusy.value = true;

    int _res = await BlocProvider.of<CovidTaggerBloc>(context).confirmTags(widget.userUid, widget.userName);
    bool _isClose = false;

    if (_res == -1) {
      toastGeneral("No changes has been made because the PUI list is empty.");
      _isClose = true;
    } else if (_res == 0) {
      toastError("We encountered an error while trying to confirm the changes. Please try again.");
    } else {
      toastGeneral("Successfully saved the changes you made.");
      _isClose = true;
    }

    await Future.delayed(Duration(milliseconds: 200));

    if (_isClose) {
      Navigator.of(context).pop();
    } else {
      isBusy.value = false;
    }
  }
}
