import 'package:clinick/config/app_config.dart';
import 'package:clinick/config/color.dart';
import 'package:clinick/database/app_firebase.dart';
import 'package:clinick/models/covid_group_model.dart';
import 'package:clinick/staff/pages/covid_tracker/blocs/bloc.dart';
import 'package:clinick/staff/pages/covid_tracker/blocs/events.dart';
import 'package:clinick/staff/pages/covid_tracker/blocs/viewer_bloc/bloc.dart';
import 'package:clinick/staff/pages/covid_tracker/covid_group_viewer.dart';
import 'package:clinick/staff/pages/covid_tracker/logs/blocs/bloc.dart';
import 'package:clinick/staff/pages/covid_tracker/logs/view.dart';
import 'package:clinick/staff/pages/search/blocs/bloc.dart';
import 'package:clinick/staff/pages/search/view.dart';
import 'package:clinick/widgets/dialog_templates.dart';
import 'package:clinick/widgets/state_view_template.dart';
import 'package:clinick/widgets/toast.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:intl/intl.dart';
import 'package:line_icons/line_icons.dart';

import 'blocs/states.dart';

class StaffPageCovidTracker extends StatefulWidget {
  @override
  _StaffPageCovidTrackerState createState() => _StaffPageCovidTrackerState();
}

class _StaffPageCovidTrackerState extends State<StaffPageCovidTracker> {
  @override
  void initState() {
    BlocProvider.of<CovidGroupBloc>(context).add(CovidGroupEventRequest());
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0.0,
        leading: const SizedBox(),
        leadingWidth: 0.0,
        elevation: 0.0,
        title: Row(
          children: [
            const SizedBox(width: 10.0),
            IconButton(
              icon: const Icon(
                LineIcons.arrowLeft,
                color: ThemeColor.primary,
              ),
              splashRadius: 24.0,
              padding: const EdgeInsets.all(8.0),
              onPressed: () => Navigator.of(context).pop(),
            ),
            const SizedBox(width: 15.0),
            const Text(
              'Contact Tracing',
              style: const TextStyle(
                fontSize: 17.0,
                fontWeight: FontWeight.bold,
                color: ThemeColor.primary,
              ),
            ),
            const Spacer(),
            IconButton(
              tooltip: 'My Visit Logs',
              icon: Icon(LineIcons.calendar),
              color: ThemeColor.accent,
              splashRadius: 24.0,
              onPressed: showLogs,
            ),
            IconButton(
              tooltip: 'Tag a Covid-Positive Patient',
              icon: Icon(LineIcons.userShield),
              color: ThemeColor.accent,
              splashRadius: 24.0,
              onPressed: tagPatient,
            ),
            const SizedBox(width: 5.0),
          ],
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.fromLTRB(15.0, 5.0, 15.0, 0.0),
        child: SizedBox.expand(
          child: BlocBuilder<CovidGroupBloc, CovidGroupState>(
            builder: (_, state) {
              if (state is CovidGroupStateSuccess) {
                if (state.groups.isNotEmpty) {
                  return ListView.separated(
                    physics: const BouncingScrollPhysics(parent: const AlwaysScrollableScrollPhysics()),
                    itemCount: state.groups.length,
                    separatorBuilder: (context, index) => const SizedBox(height: 10.0),
                    itemBuilder: (context, index) {
                      final CovidGroupModel _model = state.groups[index];
                      return Material(
                        elevation: 5.0,
                        borderRadius: BorderRadius.circular(8.0),
                        color: ThemeColor.background,
                        shadowColor: ThemeColor.shadow.withOpacity(0.35),
                        child: InkWell(
                          borderRadius: BorderRadius.circular(15.0),
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) {
                                  return BlocProvider(
                                    create: (_) => CovidGroupViewerBloc(),
                                    child: StaffPageCovidGroupViewer(
                                      groupId: _model.id,
                                      userName: _model.userName,
                                    ),
                                  );
                                },
                              ),
                            );
                          },
                          child: Padding(
                            padding: const EdgeInsets.fromLTRB(15.0, 15.0, 15.0, 15.0),
                            child: Row(
                              children: [
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        '${_model.userName}',
                                        style: const TextStyle(
                                          fontSize: 14.0,
                                          fontWeight: FontWeight.w600,
                                          color: ThemeColor.accent,
                                        ),
                                      ),
                                      const SizedBox(height: 5.0),
                                      Text(
                                        "Created On: ${DateFormat('MMMM dd, yyyy  hh:mm a').format(_model.createdAt)}",
                                        style: const TextStyle(
                                          color: ThemeColor.secondary,
                                          fontSize: 12.0,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                IconButton(
                                  icon: Icon(LineIcons.trash),
                                  color: ThemeColor.accent,
                                  padding: EdgeInsets.zero,
                                  iconSize: 20.0,
                                  splashRadius: 20.0,
                                  onPressed: () async {
                                    final bool? _result = await showDialog(
                                      context: context,
                                      builder: (_) {
                                        return CriticalDialogTemplate(
                                          message:
                                              "You are permanently removing this COVID-19 Contact Tracing Tag. This action is not reversible.",
                                        );
                                      },
                                    );

                                    if (_result != null) {
                                      if (!_result) return;
                                    } else {
                                      return;
                                    }

                                    await removeGroup(_model.id);
                                  },
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  );
                }
              } else if (state is CovidGroupStateFailed) {
                return Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    StateView(
                      title: 'Sorry for the trouble!',
                      message:
                          "We encountered an error while trying to fetch your list of tagged COVID-19 positive patients. Please try again.",
                      assetPath: AppConfig.asset_failedImage,
                    ),
                  ],
                );
              } else if (state is CovidGroupStateInProgress) {
                return const Center(
                  child: const CircularProgressIndicator(
                    valueColor: AlwaysStoppedAnimation(
                      ThemeColor.accent,
                    ),
                  ),
                );
              }

              return Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  StateView(
                    title: 'Nothing to see here!',
                    message:
                        "You haven't tagged any patient as COVID-19 positive. Use the icon button in the top-right of this page to tag a patient.",
                    assetPath: AppConfig.asset_emptyImage,
                  ),
                ],
              );
            },
          ),
        ),
      ),
    );
  }

  void showLogs() {
    Navigator.push(
      context,
      CupertinoPageRoute(
        builder: (_) {
          return BlocProvider(
            create: (_) => CovidTimeLogBloc(),
            child: StaffPageTimeLogs(),
          );
        },
      ),
    );
  }

  void tagPatient() {
    Navigator.push(
      context,
      CupertinoPageRoute(
        builder: (_) {
          return BlocProvider(
            create: (_) => SearchPatientBloc(),
            child: StaffPageSearch(showTaggerOnly: true),
          );
        },
      ),
    );
  }

  Future<void> removeGroup(String groupId) async {
    toastGeneral("Deleting tag...");

    WriteBatch batch = AppFirebase.firestore.batch();

    QuerySnapshot _data = await AppFirebase.firestore.collection('covidpui').where('groupid', isEqualTo: groupId).get();

    for (var item in _data.docs) {
      batch.delete(item.reference);
    }

    await batch.commit();

    await AppFirebase.firestore.collection('covidpuigroup').doc(groupId).delete();

    toastGeneral("Successfully deleted");
  }
}
