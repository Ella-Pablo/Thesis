import 'package:clinick/config/color.dart';
import 'package:clinick/models/covid_tracker_model.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class CovidTaggerItemTemplate extends StatelessWidget {
  const CovidTaggerItemTemplate({required this.model});
  final CovidTrackerModel model;

  @override
  Widget build(BuildContext context) {
    return Material(
      elevation: 5.0,
      borderRadius: BorderRadius.circular(8.0),
      color: ThemeColor.background,
      shadowColor: ThemeColor.shadow.withOpacity(0.35),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(15.0, 15.0, 15.0, 15.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '${model.userName}',
              maxLines: 1,
              overflow: TextOverflow.clip,
              style: const TextStyle(
                fontSize: 14.0,
                fontWeight: FontWeight.w600,
                color: ThemeColor.accent,
              ),
            ),
            const SizedBox(height: 5.0),
            Text(
              '${DateFormat('MMMM dd, yyyy   hh:mm a').format(model.start)} - ${DateFormat('hh:mm a').format(model.end)}',
              style: const TextStyle(
                color: ThemeColor.secondary,
                fontSize: 12.0,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
