import 'package:clinick/config/app_config.dart';
import 'package:clinick/config/color.dart';
import 'package:clinick/staff/pages/covid_tracker/blocs/viewer_bloc/bloc.dart';
import 'package:clinick/staff/pages/covid_tracker/blocs/viewer_bloc/events.dart';
import 'package:clinick/widgets/state_view_template.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:intl/intl.dart';
import 'package:line_icons/line_icons.dart';

import 'blocs/viewer_bloc/states.dart';

class StaffPageCovidGroupViewer extends StatefulWidget {
  const StaffPageCovidGroupViewer({required this.groupId, required this.userName});
  final String groupId;
  final String userName;

  @override
  _StaffPageCovidGroupViewerState createState() => _StaffPageCovidGroupViewerState();
}

class _StaffPageCovidGroupViewerState extends State<StaffPageCovidGroupViewer> {
  @override
  void initState() {
    BlocProvider.of<CovidGroupViewerBloc>(context).add(CovidGroupViewerEventRequest(groupId: widget.groupId));
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 15.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 20.0),
              Row(
                children: [
                  const SizedBox(width: 5.0),
                  Expanded(
                    child: Text(
                      widget.userName,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontSize: 16.0,
                        color: ThemeColor.secondary,
                      ),
                    ),
                  ),
                  SizedBox(
                    width: 24.0,
                    height: 24.0,
                    child: IconButton(
                      icon: const Icon(
                        LineIcons.times,
                        color: ThemeColor.primary,
                      ),
                      splashRadius: 24.0,
                      padding: EdgeInsets.zero,
                      onPressed: () => Navigator.of(context).pop(),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20.0),
              Material(
                elevation: 5.0,
                borderRadius: BorderRadius.circular(15.0),
                color: ThemeColor.background,
                shadowColor: ThemeColor.shadow.withOpacity(0.35),
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(10.0, 15.0, 15.0, 15.0),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Icon(
                        LineIcons.infoCircle,
                        size: 20.0,
                        color: ThemeColor.accent,
                      ),
                      const SizedBox(width: 5.0),
                      const Expanded(
                        child: const Text(
                          "Below is the list of Person Under Investigation (PUI) with regard to this patient.",
                          textAlign: TextAlign.justify,
                          style: const TextStyle(
                            fontSize: 12.0,
                            color: ThemeColor.secondary,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 10.0),
              Expanded(
                child: BlocBuilder<CovidGroupViewerBloc, CovidGroupViewerState>(
                  builder: (_, state) {
                    if (state is CovidGroupViewerStateSuccess) {
                      if (state.trackers.isNotEmpty) {
                        return ListView.separated(
                          physics: const BouncingScrollPhysics(parent: const AlwaysScrollableScrollPhysics()),
                          itemCount: state.trackers.length,
                          separatorBuilder: (context, index) => const SizedBox(height: 10.0),
                          itemBuilder: (context, index) {
                            return Material(
                              elevation: 5.0,
                              borderRadius: BorderRadius.circular(8.0),
                              color: ThemeColor.background,
                              shadowColor: ThemeColor.shadow.withOpacity(0.35),
                              child: Padding(
                                padding: const EdgeInsets.all(15.0),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      state.trackers[index].userName,
                                      style: const TextStyle(
                                        fontSize: 14.0,
                                        color: ThemeColor.accent,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    const SizedBox(height: 5.0),
                                    Text(
                                      '${DateFormat('MMMM dd, yyyy   hh:mm a').format(state.trackers[index].start)} - ${DateFormat('hh:mm a').format(state.trackers[index].end)}',
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: const TextStyle(
                                        fontSize: 12.0,
                                        color: ThemeColor.secondary,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            );
                          },
                        );
                      }
                    } else if (state is CovidGroupViewerStateFailed) {
                      return Center(
                        child: StateView(
                          title: 'Sorry for the trouble!',
                          message: "We encountered an error while trying to process your request. Please try again.",
                          assetPath: AppConfig.asset_failedImage,
                        ),
                      );
                    } else if (state is CovidGroupViewerStateInProgress) {
                      return const Center(
                        child: const CircularProgressIndicator(
                          valueColor: AlwaysStoppedAnimation(
                            ThemeColor.accent,
                          ),
                        ),
                      );
                    }

                    return Center(
                      child: StateView(
                        title: 'Nothing to see here!',
                        message: "It seems that there is no PUIs tagged to this patient.",
                        assetPath: AppConfig.asset_emptyImage,
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
