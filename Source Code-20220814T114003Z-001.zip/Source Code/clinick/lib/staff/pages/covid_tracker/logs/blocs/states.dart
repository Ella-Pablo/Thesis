import 'package:clinick/models/covid_tracker_model.dart';
import 'package:equatable/equatable.dart';

abstract class CovidTimeLogState extends Equatable {
  const CovidTimeLogState();

  @override
  List<Object> get props => [];
}

class CovidTimeLogStateEmpty extends CovidTimeLogState {}

class CovidTimeLogStateInProgress extends CovidTimeLogState {}

class CovidTimeLogStateSuccess extends CovidTimeLogState {
  final List<CovidTrackerModel> visitTrackers;
  final bool refresher;
  final bool hasReachedLimit;
  final bool isLoading;
  const CovidTimeLogStateSuccess({
    required this.visitTrackers,
    required this.refresher,
    required this.hasReachedLimit,
    required this.isLoading,
  });

  @override
  List<Object> get props => [visitTrackers, refresher, hasReachedLimit, isLoading];
}

class CovidTimeLogStateFailed extends CovidTimeLogState {}
