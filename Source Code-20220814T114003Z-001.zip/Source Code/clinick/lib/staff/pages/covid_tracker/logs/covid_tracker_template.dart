import 'package:clinick/config/color.dart';
import 'package:clinick/models/covid_tracker_model.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class CovidTrackerItemTemplate extends StatelessWidget {
  const CovidTrackerItemTemplate({required this.model});
  final CovidTrackerModel model;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5.0),
      child: Material(
        elevation: 5.0,
        borderRadius: BorderRadius.circular(8.0),
        color: ThemeColor.background,
        shadowColor: ThemeColor.shadow.withOpacity(0.35),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(15.0, 15.0, 15.0, 15.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    '${DateFormat('MMMM dd, yyyy').format(model.start)}',
                    style: const TextStyle(
                      fontSize: 14.0,
                      fontWeight: FontWeight.w600,
                      color: ThemeColor.accent,
                    ),
                  ),
                  const Spacer(),
                  Text(
                    '${DateFormat('hh:mm a').format(model.start)} - ${DateFormat('hh:mm a').format(model.end)}',
                    style: const TextStyle(
                      fontSize: 12.0,
                      color: ThemeColor.secondary,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 5.0),
              Text(
                "You stayed at our clinic for a total of ${model.start.difference(model.end).abs().inMinutes} minutes.",
                style: const TextStyle(
                  color: ThemeColor.secondary,
                  fontSize: 12.0,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
