import 'package:clinick/config/app_config.dart';
import 'package:clinick/config/color.dart';
import 'package:clinick/widgets/state_view_template.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:line_icons/line_icons.dart';

import 'blocs/bloc.dart';
import 'blocs/events.dart';
import 'blocs/states.dart';
import 'covid_tracker_template.dart';

class StaffPageTimeLogs extends StatefulWidget {
  @override
  _StaffPageTimeLogsState createState() => _StaffPageTimeLogsState();
}

class _StaffPageTimeLogsState extends State<StaffPageTimeLogs> {
  @override
  void initState() {
    BlocProvider.of<CovidTimeLogBloc>(context).add(CovidTimeLogEventRequest());
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0.0,
        leading: const SizedBox(),
        leadingWidth: 0.0,
        elevation: 0.0,
        title: Row(
          children: [
            const SizedBox(width: 10.0),
            IconButton(
              icon: const Icon(
                LineIcons.arrowLeft,
                color: ThemeColor.primary,
              ),
              splashRadius: 24.0,
              padding: const EdgeInsets.all(8.0),
              onPressed: () => Navigator.of(context).pop(),
            ),
            const SizedBox(width: 15.0),
            const Text(
              'My Visit History',
              style: const TextStyle(
                fontSize: 17.0,
                fontWeight: FontWeight.bold,
                color: ThemeColor.primary,
              ),
            ),
            const Spacer(),
            IconButton(
              tooltip: 'Refresh',
              icon: Icon(LineIcons.syncIcon),
              color: ThemeColor.accent,
              splashRadius: 24.0,
              onPressed: () => BlocProvider.of<CovidTimeLogBloc>(context).add(CovidTimeLogEventRequest()),
            ),
            const SizedBox(width: 5.0),
          ],
        ),
      ),
      body: BlocBuilder<CovidTimeLogBloc, CovidTimeLogState>(
        builder: (context, state) {
          if (state is CovidTimeLogStateSuccess) {
            return CustomScrollView(
              physics: const BouncingScrollPhysics(parent: const AlwaysScrollableScrollPhysics()),
              slivers: [
                SliverPadding(
                  padding: const EdgeInsets.symmetric(horizontal: 15.0, vertical: 10.0),
                  sliver: SliverList(
                    delegate: SliverChildBuilderDelegate(
                      (_, index) {
                        return CovidTrackerItemTemplate(
                          model: state.visitTrackers[index],
                        );
                      },
                      childCount: state.visitTrackers.length,
                    ),
                  ),
                ),
                if (!state.hasReachedLimit && state.isLoading)
                  SliverToBoxAdapter(
                    child: const SizedBox(
                      height: 100.0,
                      child: Center(
                        child: const CircularProgressIndicator(
                          valueColor: AlwaysStoppedAnimation(
                            ThemeColor.accent,
                          ),
                        ),
                      ),
                    ),
                  ),
                if (!state.hasReachedLimit && !state.isLoading)
                  SliverToBoxAdapter(
                    child: SizedBox(
                      height: 80.0,
                      child: Center(
                        child: MaterialButton(
                          onPressed: () =>
                              BlocProvider.of<CovidTimeLogBloc>(context).add(CovidTimeLogEventRequestNext()),
                          child: const Text('Show More'),
                          padding: const EdgeInsets.symmetric(horizontal: 15.0, vertical: 8.0),
                          color: ThemeColor.accent,
                          textColor: ThemeColor.buttonTextColor,
                        ),
                      ),
                    ),
                  ),
                if (state.hasReachedLimit)
                  SliverToBoxAdapter(
                    child: const SizedBox(height: 30.0),
                  ),
              ],
            );
          } else if (state is CovidTimeLogStateFailed) {
            return StateView(
              title: 'Sorry for the trouble!',
              message:
                  "We encountered an error while trying to fetch your attendance log. We encourage you to contact our administrator immediately.",
              assetPath: AppConfig.asset_failedImage,
            );
          } else if (state is CovidTimeLogStateEmpty) {
            return StateView(
              title: 'Nothing to see here!',
              message:
                  "It seems that you haven't appeared at the clinic yet. The time and duration of your attendance will appear here.",
              assetPath: AppConfig.asset_emptyImage,
            );
          } else if (state is CovidTimeLogStateInProgress) {
            return const Center(
              child: const CircularProgressIndicator(
                valueColor: AlwaysStoppedAnimation(
                  ThemeColor.accent,
                ),
              ),
            );
          }
          return const SizedBox();
        },
      ),
    );
  }
}
