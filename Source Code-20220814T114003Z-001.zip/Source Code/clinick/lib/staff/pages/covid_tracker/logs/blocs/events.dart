import 'package:equatable/equatable.dart';

abstract class CovidTimeLogEvent extends Equatable {
  const CovidTimeLogEvent();

  @override
  List<Object> get props => [];
}

class CovidTimeLogEventRequest extends CovidTimeLogEvent {}

class CovidTimeLogEventRequestNext extends CovidTimeLogEvent {}

class CovidTimeLogEventRefresh extends CovidTimeLogEvent {}
