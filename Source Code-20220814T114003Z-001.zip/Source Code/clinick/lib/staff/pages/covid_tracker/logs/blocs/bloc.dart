import 'dart:async';
import 'package:clinick/database/app_firebase.dart';
import 'package:clinick/models/covid_tracker_model.dart';
import 'package:clinick/staff/pages/covid_tracker/logs/blocs/events.dart';
import 'package:clinick/staff/pages/covid_tracker/logs/blocs/states.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class CovidTimeLogBloc extends Bloc<CovidTimeLogEvent, CovidTimeLogState> {
  CovidTimeLogBloc() : super(CovidTimeLogStateEmpty());

  List<CovidTrackerModel> visitTrackers = [];
  QueryDocumentSnapshot? lastDocument;
  bool refresher = false;

  @override
  Stream<CovidTimeLogState> mapEventToState(CovidTimeLogEvent event) async* {
    try {
      if (event is CovidTimeLogEventRequest) {
        yield CovidTimeLogStateInProgress();
        await Future.delayed(Duration(seconds: 1));

        QuerySnapshot _visitData = await AppFirebase.firestore
            .collection('covidtrackers')
            .where('userid', isEqualTo: AppFirebase.uid())
            .orderBy('start', descending: true)
            .limit(20)
            .get();

        refresher = !refresher;

        visitTrackers.clear();
        visitTrackers = _visitData.docs.map((e) => CovidTrackerModel.fromSnapshot(e.id, e.data())).toList();

        if (visitTrackers.length < 20) {
          if (visitTrackers.isEmpty) {
            yield CovidTimeLogStateEmpty();
            return;
          }
          yield CovidTimeLogStateSuccess(
            hasReachedLimit: true,
            isLoading: false,
            refresher: refresher,
            visitTrackers: visitTrackers,
          );
          return;
        }

        lastDocument = _visitData.docs.last;

        yield CovidTimeLogStateSuccess(
          visitTrackers: visitTrackers,
          refresher: refresher,
          hasReachedLimit: false,
          isLoading: false,
        );
      } else if (event is CovidTimeLogEventRequestNext) {
        if (lastDocument == null) {
          add(CovidTimeLogEventRequest());
          return;
        }

        yield CovidTimeLogStateSuccess(
          visitTrackers: visitTrackers,
          refresher: refresher,
          hasReachedLimit: false,
          isLoading: true,
        );

        QuerySnapshot _visitData = await AppFirebase.firestore
            .collection('covidtrackers')
            .where('userid', isEqualTo: AppFirebase.uid())
            .orderBy('start', descending: true)
            .startAfterDocument(lastDocument!)
            .limit(20)
            .get();

        refresher = !refresher;

        if (_visitData.docs.isEmpty) {
          yield CovidTimeLogStateSuccess(
            visitTrackers: visitTrackers,
            hasReachedLimit: true,
            isLoading: false,
            refresher: refresher,
          );
          return;
        }

        if (_visitData.docs.length >= 20) {
          lastDocument = _visitData.docs.last;
        }

        visitTrackers.addAll(_visitData.docs.map((e) => CovidTrackerModel.fromSnapshot(e.id, e.data())));

        yield CovidTimeLogStateSuccess(
          visitTrackers: visitTrackers,
          hasReachedLimit: _visitData.docs.length < 20,
          isLoading: false,
          refresher: refresher,
        );
      }
    } catch (ex) {
      //print(ex);
      yield CovidTimeLogStateFailed();
    }
  }
}
