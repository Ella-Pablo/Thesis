import 'package:equatable/equatable.dart';

abstract class CovidGroupViewerEvent extends Equatable {
  const CovidGroupViewerEvent();

  @override
  List<Object> get props => [];
}

class CovidGroupViewerEventRequest extends CovidGroupViewerEvent {
  const CovidGroupViewerEventRequest({required this.groupId});
  final String groupId;
}
