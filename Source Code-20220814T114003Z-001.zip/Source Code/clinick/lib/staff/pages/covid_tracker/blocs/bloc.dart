import 'dart:async';

import 'package:clinick/database/app_firebase.dart';
import 'package:clinick/models/covid_group_model.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'events.dart';
import 'states.dart';

class CovidGroupBloc extends Bloc<CovidGroupEvent, CovidGroupState> {
  CovidGroupBloc() : super(CovidGroupStateInProgress());

  StreamSubscription? subscription;
  List<CovidGroupModel> groups = [];
  bool refresher = true;

  @override
  Stream<CovidGroupState> mapEventToState(CovidGroupEvent event) async* {
    if (event is CovidGroupEventRequest) {
      yield CovidGroupStateInProgress();

      subscription?.cancel();
      subscription = AppFirebase.firestore
          .collection('covidpuigroup')
          .where("staffid", isEqualTo: AppFirebase.uid())
          .snapshots()
          .listen(
        (event) {
          try {
            groups.clear();

            for (var item in event.docs) {
              groups.add(CovidGroupModel.fromSnapshot(item.id, item.data()));
            }

            if (groups.isEmpty) {
              emit(
                CovidGroupStateEmpty(),
              );
              return;
            }

            groups.sort((a, b) => a.createdAt.millisecondsSinceEpoch.compareTo(b.createdAt.millisecondsSinceEpoch));

            refresher = !refresher;

            emit(CovidGroupStateSuccess(
              groups: groups,
              refresher: refresher,
            ));
          } catch (ex) {
            emit(
              CovidGroupStateFailed(),
            );
          }
        },
      );
    }
  }

  @override
  Future<void> close() {
    subscription?.cancel();
    return super.close();
  }
}
