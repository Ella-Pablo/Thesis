import 'package:equatable/equatable.dart';

abstract class CovidGroupEvent extends Equatable {
  const CovidGroupEvent();

  @override
  List<Object> get props => [];
}

class CovidGroupEventRequest extends CovidGroupEvent {}
