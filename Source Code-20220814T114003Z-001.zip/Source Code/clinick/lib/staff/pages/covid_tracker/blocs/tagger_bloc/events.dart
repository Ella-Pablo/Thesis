import 'package:equatable/equatable.dart';

abstract class CovidTaggerEvent extends Equatable {
  const CovidTaggerEvent();

  @override
  List<Object> get props => [];
}

class CovidTaggerEventRequest extends CovidTaggerEvent {
  const CovidTaggerEventRequest({required this.userUid});
  final String userUid;
}
