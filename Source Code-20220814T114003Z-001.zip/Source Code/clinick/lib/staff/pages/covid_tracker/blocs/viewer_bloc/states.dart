import 'package:clinick/models/covid_tracker_model.dart';
import 'package:equatable/equatable.dart';

abstract class CovidGroupViewerState extends Equatable {
  const CovidGroupViewerState();

  @override
  List<Object> get props => [];
}

class CovidGroupViewerStateEmpty extends CovidGroupViewerState {}

class CovidGroupViewerStateInProgress extends CovidGroupViewerState {}

class CovidGroupViewerStateSuccess extends CovidGroupViewerState {
  final List<CovidTrackerModel> trackers;
  final bool refresher;
  CovidGroupViewerStateSuccess({required this.trackers, required this.refresher});

  @override
  List<Object> get props => [trackers, refresher];
}

class CovidGroupViewerStateFailed extends CovidGroupViewerState {}
