import 'package:clinick/models/covid_group_model.dart';
import 'package:equatable/equatable.dart';

abstract class CovidGroupState extends Equatable {
  const CovidGroupState();

  @override
  List<Object> get props => [];
}

class CovidGroupStateEmpty extends CovidGroupState {}

class CovidGroupStateInProgress extends CovidGroupState {}

class CovidGroupStateSuccess extends CovidGroupState {
  final List<CovidGroupModel> groups;
  final bool refresher;
  CovidGroupStateSuccess({required this.groups, required this.refresher});

  @override
  List<Object> get props => [groups, refresher];
}

class CovidGroupStateFailed extends CovidGroupState {}
