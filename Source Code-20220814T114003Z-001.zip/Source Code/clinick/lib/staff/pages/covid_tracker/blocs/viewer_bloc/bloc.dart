import 'dart:async';
import 'package:clinick/database/app_firebase.dart';
import 'package:clinick/models/covid_tracker_model.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'events.dart';
import 'states.dart';

class CovidGroupViewerBloc extends Bloc<CovidGroupViewerEvent, CovidGroupViewerState> {
  CovidGroupViewerBloc() : super(CovidGroupViewerStateEmpty());

  List<CovidTrackerModel> trackers = [];
  bool refresher = false;

  @override
  Stream<CovidGroupViewerState> mapEventToState(CovidGroupViewerEvent event) async* {
    try {
      if (event is CovidGroupViewerEventRequest) {
        yield CovidGroupViewerStateInProgress();

        QuerySnapshot _data =
            await AppFirebase.firestore.collection('covidpui').where('groupid', isEqualTo: event.groupId).get();

        if (_data.size <= 0) {
          yield CovidGroupViewerStateEmpty();
          return;
        }

        trackers.clear();
        trackers.addAll(_data.docs.map((e) => CovidTrackerModel.fromSnapshot(e.id, e.data())));

        yield CovidGroupViewerStateSuccess(
          trackers: trackers,
          refresher: refresher,
        );
      }
    } catch (ex) {
      //print(ex);
      yield CovidGroupViewerStateFailed();
    }
  }
}
