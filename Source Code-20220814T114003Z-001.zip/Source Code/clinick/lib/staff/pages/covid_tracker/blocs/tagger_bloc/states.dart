import 'package:clinick/models/covid_tracker_model.dart';
import 'package:equatable/equatable.dart';

abstract class CovidTaggerState extends Equatable {
  const CovidTaggerState();

  @override
  List<Object> get props => [];
}

class CovidTaggerStateEmpty extends CovidTaggerState {}

class CovidTaggerStateInProgress extends CovidTaggerState {}

class CovidTaggerStateSuccess extends CovidTaggerState {
  final List<CovidTrackerModel> trackers;
  final bool refresher;
  CovidTaggerStateSuccess({required this.trackers, required this.refresher});

  @override
  List<Object> get props => [trackers, refresher];
}

class CovidTaggerStateFailed extends CovidTaggerState {}
