import 'dart:async';
import 'package:clinick/database/app_firebase.dart';
import 'package:clinick/models/covid_group_model.dart';
import 'package:clinick/models/covid_tracker_model.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'events.dart';
import 'states.dart';

class CovidTaggerBloc extends Bloc<CovidTaggerEvent, CovidTaggerState> {
  CovidTaggerBloc() : super(CovidTaggerStateEmpty());

  List<CovidTrackerModel> trackers = [];
  bool refresher = false;

  @override
  Stream<CovidTaggerState> mapEventToState(CovidTaggerEvent event) async* {
    try {
      if (event is CovidTaggerEventRequest) {
        yield CovidTaggerStateInProgress();

        final DateTime _now = DateTime.now();

        QuerySnapshot _userData = await AppFirebase.firestore
            .collection('covidtrackers')
            .where('start', isGreaterThanOrEqualTo: _now.subtract(const Duration(days: 15)).millisecondsSinceEpoch)
            .where('userid', isEqualTo: event.userUid)
            .get();

        QuerySnapshot _otherData = await AppFirebase.firestore
            .collection('covidtrackers')
            .where('start', isGreaterThanOrEqualTo: _now.subtract(const Duration(days: 15)).millisecondsSinceEpoch)
            .get();

        if (_userData.size <= 0) {
          yield CovidTaggerStateEmpty();
          return;
        }

        final List<CovidTrackerModel> _userTrackers =
            _userData.docs.map((e) => CovidTrackerModel.fromSnapshot(e.id, e.data())).toList();
        final List<CovidTrackerModel> _otherTrackers =
            _otherData.docs.map((e) => CovidTrackerModel.fromSnapshot(e.id, e.data())).toList();

        trackers.clear();

        for (var track in _otherTrackers) {
          if (track.userUid == event.userUid) continue;
          for (var ref in _userTrackers) {
            if (isBetween(track.start, track.end, ref.start, ref.end)) {
              if (trackers.indexWhere((e) => e.userUid == track.userUid) == -1) {
                trackers.add(track);
              }
            }
          }
        }

        yield CovidTaggerStateSuccess(
          trackers: trackers,
          refresher: refresher,
        );
      }
    } catch (ex) {
      //print(ex);
      yield CovidTaggerStateFailed();
    }
  }

  bool isBetween(DateTime start, DateTime end, DateTime refStart, DateTime refEnd) {
    if (start.millisecondsSinceEpoch >= refStart.millisecondsSinceEpoch &&
        start.millisecondsSinceEpoch <= refEnd.millisecondsSinceEpoch) {
      return true;
    } else if (end.millisecondsSinceEpoch >= refStart.millisecondsSinceEpoch &&
        end.millisecondsSinceEpoch <= refEnd.millisecondsSinceEpoch) {
      return true;
    } else if (refStart.millisecondsSinceEpoch >= start.millisecondsSinceEpoch &&
        refStart.millisecondsSinceEpoch <= end.millisecondsSinceEpoch) {
      return true;
    } else if (refEnd.millisecondsSinceEpoch >= start.millisecondsSinceEpoch &&
        refEnd.millisecondsSinceEpoch <= end.millisecondsSinceEpoch) {
      return true;
    }

    return false;
  }

  Future<int> confirmTags(String userUid, String userName) async {
    if (trackers.isEmpty) return -1;
    try {
      CovidGroupModel _group = CovidGroupModel(
        id: "",
        staffUid: AppFirebase.uid(),
        userName: userName,
        userUid: userUid,
        createdAt: DateTime.now(),
      );

      DocumentReference _ref = await AppFirebase.firestore.collection('covidpuigroup').add(_group.toMap());

      WriteBatch batch = AppFirebase.firestore.batch();

      for (var track in trackers) {
        batch.set(
          AppFirebase.firestore.collection('covidpui').doc(),
          {
            'userid': track.userUid,
            'username': track.userName,
            'start': track.start.millisecondsSinceEpoch,
            'end': track.end.millisecondsSinceEpoch,
            'groupid': _ref.id,
          },
        );
      }

      batch.commit();
    } catch (ex) {
      //print(ex);
      return 0;
    }

    return 1;
  }
}
