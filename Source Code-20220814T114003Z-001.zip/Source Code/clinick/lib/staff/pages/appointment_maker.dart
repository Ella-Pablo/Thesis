import 'package:clinick/config/app_config.dart';
import 'package:clinick/config/color.dart';
import 'package:clinick/database/app_firebase.dart';
import 'package:clinick/database/msg_firebase.dart';
import 'package:clinick/models/appointment_model.dart';
import 'package:clinick/models/notification_channel_types.dart';
import 'package:clinick/widgets/toast.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:line_icons/line_icons.dart';
import 'package:table_calendar/table_calendar.dart';

class AppointmentMaker extends StatefulWidget {
  AppointmentMaker({required this.userUid, required this.userName});

  final String userUid;
  final String userName;

  @override
  _AppointmentMakerState createState() => _AppointmentMakerState();
}

class _AppointmentMakerState extends State<AppointmentMaker> {
  final ValueNotifier<DateTime?> selectedDay = ValueNotifier(null);
  final ValueNotifier<TimeOfDay?> selectedStart = ValueNotifier(null);
  final ValueNotifier<TimeOfDay?> selectedEnd = ValueNotifier(null);
  final ValueNotifier<int> selectedType = ValueNotifier(0);

  bool isBusy = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0.0,
        leading: const SizedBox(),
        leadingWidth: 0.0,
        elevation: 0.0,
        title: Row(
          children: [
            const SizedBox(width: 10.0),
            IconButton(
              icon: const Icon(
                LineIcons.arrowLeft,
                color: ThemeColor.primary,
              ),
              splashRadius: 24.0,
              padding: const EdgeInsets.all(8.0),
              onPressed: () => Navigator.of(context).pop(),
            ),
            const SizedBox(width: 15.0),
            const Text(
              'Add An Appointment',
              style: const TextStyle(
                fontSize: 17.0,
                fontWeight: FontWeight.bold,
                color: ThemeColor.primary,
              ),
            ),
            const Spacer(),
            IconButton(
              tooltip: 'Create Appointment',
              icon: Icon(LineIcons.save),
              color: ThemeColor.primary,
              splashRadius: 24.0,
              onPressed: () => onSave(),
            ),
            const SizedBox(width: 5.0),
          ],
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 15.0),
        physics: const BouncingScrollPhysics(),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 20.0),
            Material(
              elevation: 12.0,
              borderRadius: BorderRadius.circular(15.0),
              color: ThemeColor.background,
              shadowColor: ThemeColor.shadow.withOpacity(0.35),
              child: Padding(
                padding: const EdgeInsets.fromLTRB(10.0, 15.0, 15.0, 15.0),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Icon(
                      LineIcons.infoCircle,
                      size: 20.0,
                      color: ThemeColor.accent,
                    ),
                    const SizedBox(width: 5.0),
                    const Expanded(
                      child: const Text(
                        "Make sure that your selected schedule especially the time will not overlap with any of your existing appointments to prevent conflict of schedule.",
                        textAlign: TextAlign.justify,
                        style: const TextStyle(
                          fontSize: 12.0,
                          color: ThemeColor.secondary,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 30.0),
            Row(
              children: [
                const Icon(
                  LineIcons.medicalNotes,
                  size: 20.0,
                  color: ThemeColor.accent,
                ),
                const SizedBox(width: 5.0),
                Text(
                  "Select Appointment Type",
                  style: const TextStyle(
                    color: ThemeColor.primary,
                    fontSize: 15.0,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20.0),
            SizedBox(
              height: 45.0,
              child: ValueListenableBuilder<int>(
                valueListenable: selectedType,
                builder: (_, value, __) {
                  return DropdownButtonFormField<int>(
                    decoration: InputDecoration(
                      fillColor: ThemeColor.background,
                      filled: true,
                      contentPadding: const EdgeInsets.symmetric(
                          horizontal: 5.0, vertical: 10.0),
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          width: 1.0,
                          color: ThemeColor.inputBorder,
                        ),
                        borderRadius: BorderRadius.circular(15.0),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          width: 1.0,
                          color: ThemeColor.accent,
                        ),
                        borderRadius: BorderRadius.circular(15.0),
                      ),
                      prefixIcon: Icon(
                        LineIcons.angleRight,
                        color: ThemeColor.accent,
                        size: 20.0,
                      ),
                    ),
                    value: value,
                    style: const TextStyle(
                      color: ThemeColor.primary,
                      fontSize: 15.0,
                    ),
                    onChanged: (index) => selectedType.value = index!,
                    items: AppConfig.appointment_type.entries.map(
                      (e) {
                        return DropdownMenuItem(
                          child: SizedBox(
                            width: MediaQuery.of(context).size.width - 120.0,
                            child: Text(
                              e.value,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          value: e.key,
                        );
                      },
                    ).toList(),
                  );
                },
              ),
            ),
            const SizedBox(height: 20.0),
            Row(
              children: [
                const Icon(
                  LineIcons.calendar,
                  size: 20.0,
                  color: ThemeColor.accent,
                ),
                const SizedBox(width: 5.0),
                Text(
                  "Select Appointment Date",
                  style: const TextStyle(
                    color: ThemeColor.primary,
                    fontSize: 15.0,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
            ValueListenableBuilder<DateTime?>(
              valueListenable: selectedDay,
              builder: (_, value, __) {
                return TableCalendar(
                  focusedDay: value ?? DateTime.now(),
                  firstDay: DateTime.now(),
                  lastDay: DateTime(DateTime.now().year + 1),
                  availableGestures: AvailableGestures.horizontalSwipe,
                  headerStyle: HeaderStyle(
                    titleCentered: true,
                    formatButtonVisible: false,
                  ),
                  calendarStyle: CalendarStyle(
                    todayDecoration: BoxDecoration(
                      color: ThemeColor.accent.withOpacity(0.5),
                      shape: BoxShape.circle,
                    ),
                    isTodayHighlighted: true,
                    selectedDecoration: BoxDecoration(
                      color: ThemeColor.accent,
                      shape: BoxShape.circle,
                    ),
                    selectedTextStyle:
                        const TextStyle(color: ThemeColor.buttonTextColor),
                  ),
                  selectedDayPredicate: (day) {
                    return isSameDay(value, day);
                  },
                  onDaySelected: (iSelectedDay, _) {
                    selectedDay.value = iSelectedDay;
                  },
                );
              },
            ),
            const SizedBox(height: 15.0),
            Row(
              children: [
                const Icon(
                  LineIcons.clock,
                  size: 20.0,
                  color: ThemeColor.accent,
                ),
                const SizedBox(width: 5.0),
                Text(
                  "Select Appointment Time",
                  style: const TextStyle(
                    color: ThemeColor.primary,
                    fontSize: 15.0,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20.0),
            ValueListenableBuilder<TimeOfDay?>(
              valueListenable: selectedStart,
              builder: (_, value, __) {
                return Row(
                  children: [
                    const SizedBox(width: 30.0),
                    Text(
                      "Start Time: ",
                      style: const TextStyle(
                        color: ThemeColor.secondary2,
                        fontSize: 15.0,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    const SizedBox(width: 5.0),
                    Expanded(
                      child: Text(
                        value == null ? "None" : value.format(context),
                        style: const TextStyle(
                          color: ThemeColor.secondary,
                          fontSize: 14.0,
                        ),
                      ),
                    ),
                    GestureDetector(
                      onTap: () => selectStartTime(),
                      child: Text(
                        "select",
                        style: const TextStyle(
                          backgroundColor: ThemeColor.background,
                          color: ThemeColor.accent,
                          decoration: TextDecoration.underline,
                          fontSize: 13.0,
                        ),
                      ),
                    ),
                    const SizedBox(width: 20.0),
                  ],
                );
              },
            ),
            const SizedBox(height: 20.0),
            ValueListenableBuilder<TimeOfDay?>(
              valueListenable: selectedEnd,
              builder: (_, value, __) {
                return Row(
                  children: [
                    const SizedBox(width: 30.0),
                    Text(
                      "End Time: ",
                      style: const TextStyle(
                        color: ThemeColor.secondary2,
                        fontSize: 15.0,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    const SizedBox(width: 5.0),
                    Expanded(
                      child: Text(
                        value == null ? "None" : value.format(context),
                        style: const TextStyle(
                          color: ThemeColor.secondary,
                          fontSize: 14.0,
                        ),
                      ),
                    ),
                    GestureDetector(
                      onTap: () => selectEndTime(),
                      child: Text(
                        "select",
                        style: const TextStyle(
                          backgroundColor: ThemeColor.background,
                          color: ThemeColor.accent,
                          decoration: TextDecoration.underline,
                          fontSize: 13.0,
                        ),
                      ),
                    ),
                    const SizedBox(width: 20.0),
                  ],
                );
              },
            ),
            const SizedBox(height: 50.0),
          ],
        ),
      ),
    );
  }

  void onSave() async {
    if (isBusy) return;
    isBusy = true;

    bool _hasError = false;
    if (selectedDay.value == null) {
      toastError(
          "Please select an appointment date. Just click the desired day and you are good to go.");
      _hasError = true;
    } else if (selectedStart.value == null || selectedEnd.value == null) {
      toastError(
          "Please select an appointment time. Pick a valid start and end time to proceed.");
      _hasError = true;
    } else if (widget.userUid.isEmpty) {
      toastError(
          "It seems that you haven't selected a patient yet. Please try to restart the page.");
      _hasError = true;
    }

    if (_hasError) {
      isBusy = false;
      return;
    }

    try {
      toastGeneral("Creating your appointment...");

      final AppointmentModel _model = AppointmentModel(
        staffUid: AppFirebase.uid(),
        staffName: AppFirebase.staffData!.fullName,
        userUid: widget.userUid,
        userName: widget.userName,
        date: selectedDay.value,
        start: selectedStart.value,
        end: selectedEnd.value,
        status: AppointmentStatus.pending,
        type: selectedType.value,
      );

      await AppFirebase.firestore
          .collection('appointments')
          .add(_model.toMap());

      String _peerToken = "";
      DocumentSnapshot _snapshot = await AppFirebase.firestore
          .collection('fcmtokens')
          .doc(widget.userUid)
          .get();

      if (_snapshot.exists) {
        _peerToken = _snapshot.data()?['token'] ?? "";
      }

      if (_peerToken.isNotEmpty) {
        MsgFirebase.sendNotificationToUser(
          _peerToken,
          "Appointment",
          "You have a pending '${AppConfig.appointment_type[selectedType.value]!}' appointment with ${AppFirebase.staffData!.fullName}.",
          NotifChannelTypes.appointment,
        );
      }

      toastGeneral("Successfully created the appointment.");
      await Future.delayed(Duration(seconds: 1));
      Navigator.of(context).pop();
    } catch (ex) {
      isBusy = false;
      toastError(
          "An unknown error has occured while trying to save your appointment. Please try again.");
    }
  }

  void selectStartTime() async {
    final _time = await showTimePicker(
        context: context, initialTime: TimeOfDay(hour: 12, minute: 0));

    if (_time != null) {
      if (selectedEnd.value != null) {
        if (_time.hour > selectedEnd.value!.hour) {
          toastError(
              "Incorrect time range. Start time should always be earlier than end time.");
        } else if ((_time.hour == selectedEnd.value!.hour) &&
            _time.minute >= selectedEnd.value!.minute) {
          toastError(
              "Incorrect time range. Start time should always be earlier than end time.");
        } else {
          selectedStart.value = _time;
        }
      } else {
        selectedStart.value = _time;
      }
    }
  }

  void selectEndTime() async {
    final _time = await showTimePicker(
        context: context, initialTime: TimeOfDay(hour: 13, minute: 0));

    if (_time != null) {
      if (selectedStart.value != null) {
        if (_time.hour < selectedStart.value!.hour) {
          toastError(
              "Incorrect time range. Start time should always be earlier than end time.");
        } else if ((_time.hour == selectedStart.value!.hour) &&
            _time.minute <= selectedStart.value!.minute) {
          toastError(
              "Incorrect time range. Start time should always be earlier than end time.");
        } else {
          selectedEnd.value = _time;
        }
      } else {
        selectedEnd.value = _time;
      }
    }
  }
}
