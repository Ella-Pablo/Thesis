import 'dart:io';
import 'dart:math';

import 'package:clinick/config/color.dart';
import 'package:clinick/database/app_firebase.dart';
import 'package:clinick/models/upload_item_model.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:line_icons/line_icons.dart';

class UploadItemTemplate extends StatefulWidget {
  const UploadItemTemplate({
    Key? key,
    required this.file,
    required this.deleteFunction,
    required this.onDoneCallback,
    required this.userName,
    required this.userId,
  }) : super(key: key);
  final String userName;
  final String userId;
  final File file;
  final Function(String) deleteFunction;
  final Function() onDoneCallback;
  @override
  UploadItemTemplateState createState() => UploadItemTemplateState();
}

class UploadItemTemplateState extends State<UploadItemTemplate> {
  final ValueNotifier<UploadItemStatus> status = ValueNotifier(UploadItemStatus.idle);
  final ValueNotifier<MedicalRecordsType> type = ValueNotifier(MedicalRecordsType.general);
  final ValueNotifier<double> progress = ValueNotifier(0.0);

  @override
  void dispose() {
    status.dispose();
    type.dispose();
    progress.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "${widget.file.path.substring(widget.file.path.lastIndexOf('/') + 1)}",
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: ThemeColor.accent,
                      fontSize: 14.0,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 5.0),
                  FutureBuilder<String>(
                    initialData: "Computing file size...",
                    future: computeFileSize(),
                    builder: (context, snapshot) {
                      return Text(
                        "File Size:  ${snapshot.data}",
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: ThemeColor.secondary,
                          fontSize: 13.0,
                        ),
                      );
                    },
                  ),
                ],
              ),
            ),
            IconButton(
              icon: Icon(LineIcons.trash),
              iconSize: 20.0,
              splashRadius: 20.0,
              color: ThemeColor.accent,
              onPressed: () {
                if (status.value == UploadItemStatus.idle || status.value == UploadItemStatus.failed) {
                  widget.deleteFunction(widget.file.path);
                }
              },
            ),
          ],
        ),
        const SizedBox(height: 5.0),
        ValueListenableBuilder<MedicalRecordsType>(
          valueListenable: type,
          builder: (_, value, __) {
            return Table(
              border: TableBorder.all(color: ThemeColor.primary, width: 1.0),
              children: [
                TableRow(
                  children: [
                    GestureDetector(
                      onTap: () {
                        if (status.value == UploadItemStatus.idle || status.value == UploadItemStatus.failed) {
                          type.value = MedicalRecordsType.general;
                        }
                      },
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(
                          "General",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 13.0,
                            color: value == MedicalRecordsType.general ? ThemeColor.accent : ThemeColor.secondary,
                            fontWeight: value == MedicalRecordsType.general ? FontWeight.w600 : FontWeight.normal,
                          ),
                        ),
                      ),
                    ),
                    GestureDetector(
                      onTap: () {
                        if (status.value == UploadItemStatus.idle || status.value == UploadItemStatus.failed) {
                          type.value = MedicalRecordsType.laboratory;
                        }
                      },
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(
                          "Laboratory",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 13.0,
                            color: value == MedicalRecordsType.laboratory ? ThemeColor.accent : ThemeColor.secondary,
                            fontWeight: value == MedicalRecordsType.laboratory ? FontWeight.w600 : FontWeight.normal,
                          ),
                        ),
                      ),
                    ),
                    GestureDetector(
                      onTap: () {
                        if (status.value == UploadItemStatus.idle || status.value == UploadItemStatus.failed) {
                          type.value = MedicalRecordsType.radiology;
                        }
                      },
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(
                          "Radiology",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 13.0,
                            color: value == MedicalRecordsType.radiology ? ThemeColor.accent : ThemeColor.secondary,
                            fontWeight: value == MedicalRecordsType.radiology ? FontWeight.w600 : FontWeight.normal,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            );
          },
        ),
        const SizedBox(height: 10.0),
        ValueListenableBuilder<double>(
          valueListenable: progress,
          builder: (_, value, __) {
            return LinearProgressIndicator(
              value: value,
              backgroundColor: ThemeColor.secondary,
            );
          },
        ),
        const SizedBox(height: 3.0),
        ValueListenableBuilder<UploadItemStatus>(
          valueListenable: status,
          builder: (_, value, __) {
            return Text(
              'Status: ${getStatusString()}',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                color: ThemeColor.secondary,
                fontSize: 13.0,
              ),
            );
          },
        ),
      ],
    );
  }

  void startUpload() async {
    if (status.value == UploadItemStatus.uploading && status.value == UploadItemStatus.done) return;
    status.value = UploadItemStatus.uploading;
    final String _name = DateFormat('MMM dd yyyy').format(DateTime.now()) +
        " - ${widget.file.path.substring(widget.file.path.lastIndexOf('/') + 1)}";

    late final String _folder;
    if (type.value == MedicalRecordsType.laboratory) {
      _folder = "lab_records";
    } else if (type.value == MedicalRecordsType.radiology) {
      _folder = "radiology_records";
    } else {
      _folder = "general_records";
    }

    UploadTask _task = AppFirebase.storage.ref().child(_folder).child(widget.userId).child(_name).putFile(widget.file);
    status.value = UploadItemStatus.uploading;
    _task.snapshotEvents.listen((snapshot) async {
      progress.value = snapshot.bytesTransferred / snapshot.totalBytes;

      if (_task.snapshot.state == TaskState.success) {
        await AppFirebase.firestore.collection('records').add({
          'createdat': DateTime.now().millisecondsSinceEpoch,
          'userid': widget.userId,
          'staffid': AppFirebase.uid(),
          'username': widget.userName,
          'staffname': AppFirebase.staffData!.fullName,
          'filename': _name,
          'url': await _task.snapshot.ref.getDownloadURL(),
          'type': type.value.index,
        });
        status.value = UploadItemStatus.done;
        widget.onDoneCallback();
      }
    }).onError((_) {
      status.value = UploadItemStatus.failed;
    });
  }

  Future<String> computeFileSize() async {
    String _size = "0 B";
    int bytes = await widget.file.length();
    if (bytes > 0) {
      const suffixes = ["B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB"];
      var i = (log(bytes) / log(1024)).floor();
      _size = ((bytes / pow(1024, i)).toStringAsFixed(2)) + ' ' + suffixes[i];
    }
    return _size;
  }

  String getStatusString() {
    if (status.value == UploadItemStatus.failed) {
      return "Failed";
    } else if (status.value == UploadItemStatus.uploading) {
      return "Uploading...";
    } else if (status.value == UploadItemStatus.done) {
      return "Done!";
    }
    return "Waiting for action";
  }
}
