import 'dart:io';
import 'package:equatable/equatable.dart';

abstract class RecordAdderState extends Equatable {
  const RecordAdderState();

  @override
  List<Object> get props => [];
}

class RecordAdderStateEmpty extends RecordAdderState {}

class RecordAdderStateInProgress extends RecordAdderState {}

class RecordAdderStateSuccess extends RecordAdderState {
  final List<File> uploadItems;
  final bool refresher;
  const RecordAdderStateSuccess({required this.uploadItems, required this.refresher});

  @override
  List<Object> get props => [uploadItems, refresher];
}

class RecordAdderStateFailed extends RecordAdderState {}
