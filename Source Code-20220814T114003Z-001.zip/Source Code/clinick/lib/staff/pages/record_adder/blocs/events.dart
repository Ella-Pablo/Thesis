import 'dart:io';
import 'package:equatable/equatable.dart';

abstract class RecordAdderEvent extends Equatable {
  const RecordAdderEvent();

  @override
  List<Object> get props => [];
}

class RecordAdderEventUploadAll extends RecordAdderEvent {}

class RecordAdderEventAddItems extends RecordAdderEvent {
  final List<File> filesToAdd;
  const RecordAdderEventAddItems({required this.filesToAdd});
}
