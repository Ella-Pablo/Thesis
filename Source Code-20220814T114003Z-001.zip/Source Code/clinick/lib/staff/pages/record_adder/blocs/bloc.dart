import 'dart:async';
import 'dart:io';
import 'package:clinick/widgets/toast.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'events.dart';
import 'states.dart';

class RecordAdderBloc extends Bloc<RecordAdderEvent, RecordAdderState> {
  RecordAdderBloc() : super(RecordAdderStateEmpty());

  List<File> uploadItems = [];
  bool refresher = false;

  @override
  Stream<RecordAdderState> mapEventToState(RecordAdderEvent event) async* {
    if (event is RecordAdderEventAddItems) {
      yield RecordAdderStateInProgress();
      await Future.delayed(const Duration(seconds: 1));

      int _duplicates = 0;
      for (File file in event.filesToAdd) {
        if (uploadItems.indexWhere((e) => e.path == file.path) >= 0) {
          _duplicates++;
          continue;
        }
        uploadItems.add(file);
      }

      if (_duplicates > 0) toastGeneral("Skipped $_duplicates duplicate files.");
      refresher = !refresher;

      yield RecordAdderStateSuccess(
        uploadItems: uploadItems,
        refresher: refresher,
      );
    }
  }

  void deleteFile(String path) {
    int _index = uploadItems.indexWhere((element) => element.path == path);
    if (_index >= 0) {
      uploadItems.removeAt(_index);
      refresher = !refresher;

      emit(RecordAdderStateSuccess(
        uploadItems: uploadItems,
        refresher: refresher,
      ));
      toastGeneral("Successfully deleted from your list.");
    }
  }
}
