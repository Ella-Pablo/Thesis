import 'dart:io';

import 'package:clinick/config/color.dart';
import 'package:clinick/database/app_firebase.dart';
import 'package:clinick/database/msg_firebase.dart';
import 'package:clinick/models/notification_channel_types.dart';
import 'package:clinick/models/upload_item_model.dart';
import 'package:clinick/staff/pages/record_adder/blocs/bloc.dart';
import 'package:clinick/staff/pages/record_adder/blocs/events.dart';
import 'package:clinick/staff/pages/record_adder/upload_item_template.dart';
import 'package:clinick/widgets/overlay_loader.dart';
import 'package:clinick/widgets/toast.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:line_icons/line_icons.dart';

import 'blocs/states.dart';

class RecordAdder extends StatefulWidget {
  const RecordAdder({required this.userId, required this.userName});
  final String userId;
  final String userName;
  @override
  _RecordAdderState createState() => _RecordAdderState();
}

class _RecordAdderState extends State<RecordAdder> {
  List<File> items = [];
  final ValueNotifier<double> totalProgress = ValueNotifier(0.0);
  List<GlobalKey<UploadItemTemplateState>> keys = [];
  bool alreadyStarted = false;

  @override
  void dispose() {
    totalProgress.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async => false,
      child: Scaffold(
        appBar: AppBar(
          titleSpacing: 0.0,
          leading: const SizedBox(),
          leadingWidth: 0.0,
          elevation: 0.0,
          title: Row(
            children: [
              const SizedBox(width: 10.0),
              IconButton(
                icon: const Icon(
                  LineIcons.arrowLeft,
                  color: ThemeColor.primary,
                ),
                splashRadius: 24.0,
                padding: const EdgeInsets.all(8.0),
                onPressed: () => Navigator.of(context).pop(),
              ),
              const SizedBox(width: 15.0),
              const Text(
                'Add Medical Records',
                style: const TextStyle(
                  fontSize: 17.0,
                  fontWeight: FontWeight.bold,
                  color: ThemeColor.primary,
                ),
              ),
              const Spacer(),
              const SizedBox(width: 5.0),
            ],
          ),
        ),
        body: Padding(
          padding: const EdgeInsets.all(15.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Material(
                elevation: 12.0,
                borderRadius: BorderRadius.circular(15.0),
                color: ThemeColor.background,
                shadowColor: ThemeColor.shadow.withOpacity(0.35),
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(10.0, 15.0, 15.0, 15.0),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Icon(
                        LineIcons.infoCircle,
                        size: 20.0,
                        color: ThemeColor.accent,
                      ),
                      const SizedBox(width: 5.0),
                      const Expanded(
                        child: const Text(
                          "Please do not leave or go back while the files are being uploaded. Failure to do so will cancel all the current upload tasks.",
                          textAlign: TextAlign.justify,
                          style: const TextStyle(
                            fontSize: 12.0,
                            color: ThemeColor.secondary,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 15.0),
              Material(
                elevation: 12.0,
                borderRadius: BorderRadius.circular(15.0),
                color: ThemeColor.background,
                shadowColor: ThemeColor.shadow.withOpacity(0.35),
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(10.0, 15.0, 15.0, 5.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          const Text(
                            "Upload For:  ",
                            style: const TextStyle(
                              color: ThemeColor.primary,
                              fontSize: 16.0,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Expanded(
                            child: Text(
                              "${widget.userName}",
                              maxLines: 1,
                              overflow: TextOverflow.clip,
                              style: const TextStyle(
                                color: ThemeColor.accent,
                                fontWeight: FontWeight.w600,
                                fontSize: 15.0,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10.0),
                      ValueListenableBuilder<double>(
                        valueListenable: totalProgress,
                        builder: (_, value, __) {
                          return LinearProgressIndicator(
                            backgroundColor: ThemeColor.secondary,
                            value: value > 0.0 ? value / items.length : 0.0,
                          );
                        },
                      ),
                      const SizedBox(height: 5.0),
                      ValueListenableBuilder<double>(
                        valueListenable: totalProgress,
                        builder: (_, value, __) {
                          return Text(
                            value > 0.0 ? "Total Progress: ${value.toStringAsFixed(2)}%" : "Idle",
                            style: const TextStyle(
                              color: ThemeColor.secondary,
                              fontSize: 11.0,
                            ),
                          );
                        },
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          /*TextButton(
                            onPressed: pickFiles,
                            child: Text("Add Files"),
                            style: TextButton.styleFrom(
                              primary: ThemeColor.accent,
                            ),
                          ),*/
                          IconButton(
                            icon: Icon(LineIcons.camera),
                            splashRadius: 24.0,
                            color: ThemeColor.accent,
                            tooltip: 'Take a Picture',
                            onPressed: pickCamera,
                          ),
                          IconButton(
                            icon: Icon(LineIcons.paperclip),
                            splashRadius: 24.0,
                            color: ThemeColor.accent,
                            tooltip: 'Add Files',
                            onPressed: pickFiles,
                          ),
                          TextButton(
                            onPressed: uploadAll,
                            child: Text("Upload All"),
                            style: TextButton.styleFrom(
                              primary: ThemeColor.accent,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 15.0),
              Expanded(
                child: SizedBox(
                  width: double.maxFinite,
                  child: Material(
                    elevation: 12.0,
                    borderRadius: BorderRadius.circular(15.0),
                    color: ThemeColor.background,
                    shadowColor: ThemeColor.shadow.withOpacity(0.35),
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(10.0, 15.0, 15.0, 15.0),
                      child: BlocBuilder<RecordAdderBloc, RecordAdderState>(
                        builder: (_, state) {
                          if (state is RecordAdderStateEmpty) {
                            return Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Icon(
                                  LineIcons.fileUpload,
                                  size: 120.0,
                                  color: ThemeColor.secondary.withOpacity(0.25),
                                ),
                                const SizedBox(height: 10.0),
                                Text(
                                  "Add Files to be uploaded to this patient's online records. (jpg, png, pdf, and doc files only)",
                                  textAlign: TextAlign.center,
                                  style: const TextStyle(
                                    color: ThemeColor.secondary,
                                    fontSize: 14.0,
                                  ),
                                ),
                              ],
                            );
                          } else if (state is RecordAdderStateFailed) {
                            return Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Icon(
                                  LineIcons.exclamationTriangle,
                                  size: 120.0,
                                  color: ThemeColor.secondary.withOpacity(0.25),
                                ),
                                const SizedBox(height: 10.0),
                                Text(
                                  "Unable to fetch your files. Please try to reopen this page.",
                                  textAlign: TextAlign.center,
                                  style: const TextStyle(
                                    color: ThemeColor.secondary,
                                    fontSize: 14.0,
                                  ),
                                ),
                              ],
                            );
                          }

                          if (state is RecordAdderStateSuccess) {
                            for (var item in state.uploadItems) {
                              if (items.where((e) => e.path == item.path).isNotEmpty) continue;
                              final GlobalKey<UploadItemTemplateState> _key = GlobalKey<UploadItemTemplateState>();
                              keys.add(_key);
                              items.add(item);
                            }
                          }

                          return OverlayLoader(
                            isBusy: state is RecordAdderStateInProgress,
                            child: ListView.separated(
                              physics: const BouncingScrollPhysics(parent: const AlwaysScrollableScrollPhysics()),
                              itemCount: items.length,
                              separatorBuilder: (_, index) {
                                return Divider(
                                  height: 30.0,
                                );
                              },
                              itemBuilder: (_, index) {
                                return UploadItemTemplate(
                                    key: keys[index],
                                    file: items[index],
                                    deleteFunction: deleteItem,
                                    onDoneCallback: () => updateTotalProgress(),
                                    userId: widget.userId,
                                    userName: widget.userName);
                              },
                            ),
                          );
                        },
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void updateTotalProgress() async {
    int _done = 0;
    for (var key in keys) {
      if (key.currentState?.status.value == UploadItemStatus.done) {
        _done++;
      }
    }
    final double _newProgress = (_done / items.length) * 100;
    if (_newProgress >= 100) {
      totalProgress.value = 95.0;
      String _peerToken = "";
      DocumentSnapshot _snapshot = await AppFirebase.firestore.collection('fcmtokens').doc(widget.userId).get();

      if (_snapshot.exists) {
        _peerToken = _snapshot.data()?['token'] ?? "";
      }

      if (_peerToken.isNotEmpty) {
        MsgFirebase.sendNotificationToUser(
          _peerToken,
          "Medical Records",
          "${AppFirebase.staffData!.fullName} uploaded file(s) in your medical records storage.",
          NotifChannelTypes.records,
        );
      }
      totalProgress.value = 100.0;

      toastGeneral("Successfully uploaded all the files.");
    } else {
      totalProgress.value = _newProgress;
    }
  }

  void deleteItem(String path) {
    final _toDel = items.indexWhere((element) => element.path == path);
    if (_toDel >= 0) {
      items.removeAt(_toDel);
      keys.removeAt(_toDel);
    }
    BlocProvider.of<RecordAdderBloc>(context).deleteFile(path);
  }

  void uploadAll() async {
    if (keys.isEmpty) return;
    if (alreadyStarted) {
      toastError("You have already started the download process. Please reopen this page.");
      return;
    }

    alreadyStarted = true;
    for (var key in keys) {
      key.currentState?.startUpload();
    }
  }

  void pickFiles() async {
    if (alreadyStarted) {
      toastError("You have already started the download process. Please reopen this page.");
      return;
    }

    FilePickerResult? _result = await FilePicker.platform.pickFiles(
      allowMultiple: true,
      type: FileType.custom,
      allowedExtensions: [
        'jpg',
        'pdf',
        'png',
        'doc',
        'txt',
      ],
    );

    if (_result != null) {
      BlocProvider.of<RecordAdderBloc>(context).add(
        RecordAdderEventAddItems(
          filesToAdd: _result.paths.map((e) => File(e!)).toList(),
        ),
      );
    }
  }

  void pickCamera() async {
    final ImagePicker picker = ImagePicker();
    final pickedFile = await picker.getImage(
      source: ImageSource.camera,
    );

    if (pickedFile != null) {
      var newProfileImage = await ImageCropper.cropImage(
        sourcePath: pickedFile.path,
        androidUiSettings: AndroidUiSettings(
          toolbarTitle: 'Crop Image',
          toolbarColor: ThemeColor.accent,
          toolbarWidgetColor: Colors.white,
          initAspectRatio: CropAspectRatioPreset.original,
          lockAspectRatio: false,
          activeControlsWidgetColor: ThemeColor.accent,
        ),
      );
      if (newProfileImage != null) {
        BlocProvider.of<RecordAdderBloc>(context).add(
          RecordAdderEventAddItems(
            filesToAdd: [newProfileImage],
          ),
        );
      }
    }
  }
}
