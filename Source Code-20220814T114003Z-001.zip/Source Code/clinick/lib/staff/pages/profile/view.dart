import 'dart:io';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:clinick/config/app_config.dart';
import 'package:clinick/config/color.dart';
import 'package:clinick/database/app_firebase.dart';
import 'package:clinick/models/staff_data_model.dart';
import 'package:clinick/widgets/profile_info_templates.dart';
import 'package:clinick/widgets/toast.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:line_icons/line_icons.dart';
import 'editing_state_cubit.dart';
import 'profile_state_cubit.dart';

class StaffPageProfile extends StatefulWidget {
  @override
  _StaffPageProfileState createState() => _StaffPageProfileState();
}

class _StaffPageProfileState extends State<StaffPageProfile> {
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();
  final ValueNotifier<bool> imagePicked = ValueNotifier(false);

  File? newProfileImage;
  ValueNotifier<int> selectedSpecialization = ValueNotifier(0);
  String address = "";

  @override
  void initState() {
    selectedSpecialization.value = AppFirebase.staffData!.specialization.index;
    address = AppFirebase.staffData!.address;

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: BlocBuilder<ProfileStateCubit, bool>(
          builder: (_, isBusy) {
            return Stack(
              children: [
                Positioned.fill(
                  child: SingleChildScrollView(
                    physics: const BouncingScrollPhysics(),
                    padding: const EdgeInsets.all(15.0),
                    child: BlocBuilder<EditingStateCubit, bool>(
                      builder: (context, isEditing) {
                        return Form(
                          key: formKey,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              isEditing ? editingHeader() : normalHeader(),
                              const SizedBox(height: 30.0),
                              ValueListenableBuilder<bool>(
                                valueListenable: imagePicked,
                                builder: (_, value, __) {
                                  late final DecorationImage? _decorationImg;

                                  if (value && newProfileImage != null) {
                                    _decorationImg = DecorationImage(
                                      image: FileImage(newProfileImage!),
                                      fit: BoxFit.fill,
                                    );
                                  } else if (AppFirebase.staffData!.photo.isNotEmpty) {
                                    _decorationImg = DecorationImage(
                                      image: CachedNetworkImageProvider(AppFirebase.staffData!.photo),
                                      fit: BoxFit.fill,
                                    );
                                  } else {
                                    _decorationImg = DecorationImage(
                                      image: AssetImage(AppConfig.asset_noImage),
                                      fit: BoxFit.fill,
                                    );
                                  }

                                  return Center(
                                    child: Container(
                                      height: 120.0,
                                      width: 120.0,
                                      decoration: BoxDecoration(
                                        color: ThemeColor.background,
                                        shape: BoxShape.circle,
                                        boxShadow: [
                                          BoxShadow(
                                            blurRadius: 6,
                                            spreadRadius: 2,
                                            color: ThemeColor.shadow.withOpacity(0.35),
                                            offset: Offset(0, 0),
                                          ),
                                        ],
                                        image: _decorationImg,
                                      ),
                                      clipBehavior: Clip.antiAlias,
                                      alignment: Alignment.bottomCenter,
                                      child: isEditing
                                          ? GestureDetector(
                                              onTap: () => uploadNewnewProfileImage(),
                                              child: Container(
                                                height: 30.0,
                                                color: Colors.white.withOpacity(0.75),
                                                alignment: Alignment.center,
                                                child: Text(
                                                  "Edit Image",
                                                  style: const TextStyle(
                                                    fontSize: 11.0,
                                                    decoration: TextDecoration.underline,
                                                    color: ThemeColor.secondary2,
                                                  ),
                                                ),
                                              ),
                                            )
                                          : const SizedBox(),
                                    ),
                                  );
                                },
                              ),
                              const SizedBox(height: 15.0),
                              Center(
                                child: Text(
                                  "${AppFirebase.staffData!.fullName}",
                                  maxLines: 2,
                                  style: const TextStyle(
                                    fontSize: 19.0,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ),
                              const SizedBox(height: 30.0),
                              SizedBox(
                                width: double.maxFinite,
                                child: Material(
                                  elevation: 5.0,
                                  borderRadius: BorderRadius.circular(8.0),
                                  color: ThemeColor.background,
                                  shadowColor: ThemeColor.shadow.withOpacity(0.35),
                                  child: Padding(
                                    padding: const EdgeInsets.all(20.0),
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        const SizedBox(height: 20.0),
                                        InfoTextHeader(
                                          title: 'Specialization',
                                          icon: LineIcons.medicalBriefcase,
                                        ),
                                        const SizedBox(height: 10.0),
                                        isEditing
                                            ? SizedBox(
                                                height: 45.0,
                                                child: ValueListenableBuilder<int>(
                                                  valueListenable: selectedSpecialization,
                                                  builder: (_, value, __) {
                                                    return DropdownButtonFormField<int>(
                                                      decoration: InputDecoration(
                                                        fillColor: ThemeColor.background,
                                                        filled: true,
                                                        contentPadding: const EdgeInsets.symmetric(
                                                            horizontal: 10.0, vertical: 10.0),
                                                        hintText: 'Select your specialization',
                                                        hintStyle: TextStyle(
                                                          color: ThemeColor.inputHint,
                                                          fontSize: 14.0,
                                                        ),
                                                        enabledBorder: OutlineInputBorder(
                                                          borderSide: BorderSide(
                                                            width: 1.0,
                                                            color: ThemeColor.inputBorder,
                                                          ),
                                                          borderRadius: BorderRadius.circular(15.0),
                                                        ),
                                                        focusedBorder: OutlineInputBorder(
                                                          borderSide: BorderSide(
                                                            width: 1.0,
                                                            color: ThemeColor.accent,
                                                          ),
                                                          borderRadius: BorderRadius.circular(15.0),
                                                        ),
                                                      ),
                                                      value: value,
                                                      style: const TextStyle(
                                                        color: ThemeColor.primary,
                                                        fontSize: 15.0,
                                                      ),
                                                      onChanged: (index) => selectedSpecialization.value = index!,
                                                      items: StaffSpecializationTypes.values.map(
                                                        (e) {
                                                          return DropdownMenuItem(
                                                            child: Text(e.asString),
                                                            value: e.index,
                                                          );
                                                        },
                                                      ).toList(),
                                                    );
                                                  },
                                                ),
                                              )
                                            : InfoTextMessage(
                                                message: StaffSpecializationTypes
                                                    .values[selectedSpecialization.value].asString),
                                        const SizedBox(height: 30.0),
                                        InfoTextHeader(
                                          title: 'Email',
                                          icon: LineIcons.at,
                                        ),
                                        const SizedBox(height: 10.0),
                                        InfoTextMessage(message: AppFirebase.auth.currentUser?.email ?? ""),
                                        const SizedBox(height: 15.0),
                                        InfoTextHeader(
                                          title: 'Address',
                                          icon: LineIcons.mapMarked,
                                        ),
                                        const SizedBox(height: 10.0),
                                        isEditing
                                            ? SizedBox(
                                                width: double.maxFinite,
                                                height: 45.0,
                                                child: TextFormField(
                                                  decoration: InputDecoration(
                                                    fillColor: ThemeColor.background,
                                                    filled: true,
                                                    contentPadding:
                                                        const EdgeInsets.symmetric(horizontal: 15.0, vertical: 10.0),
                                                    enabledBorder: OutlineInputBorder(
                                                      borderSide: BorderSide(
                                                        width: 1.0,
                                                        color: ThemeColor.inputBorder,
                                                      ),
                                                      borderRadius: BorderRadius.circular(10.0),
                                                    ),
                                                    focusedBorder: OutlineInputBorder(
                                                      borderSide: BorderSide(
                                                        width: 1.0,
                                                        color: ThemeColor.inputBorder,
                                                      ),
                                                      borderRadius: BorderRadius.circular(10.0),
                                                    ),
                                                  ),
                                                  initialValue: address,
                                                  style: const TextStyle(fontSize: 15.0),
                                                  keyboardType: TextInputType.text,
                                                  onSaved: (text) => address = text ?? "",
                                                ),
                                              )
                                            : InfoTextMessage(message: address),
                                        const SizedBox(height: 15.0),
                                        InfoTextHeader(
                                          title: 'Phone Number',
                                          icon: LineIcons.phone,
                                        ),
                                        const SizedBox(height: 10.0),
                                        InfoTextMessage(message: AppFirebase.staffData!.phone ?? ""),
                                        const SizedBox(height: 30.0),
                                        InfoTextHeader(
                                          title: 'Birthdate',
                                          icon: LineIcons.calendar,
                                        ),
                                        const SizedBox(height: 10.0),
                                        InfoTextMessage(
                                            message: AppFirebase.staffData!.birthdateString +
                                                "  (${AppFirebase.staffData!.age.toString()} years old)"),
                                        const SizedBox(height: 15.0),
                                        InfoTextHeader(
                                          title: 'Gender',
                                          icon: LineIcons.genderless,
                                        ),
                                        const SizedBox(height: 10.0),
                                        InfoTextMessage(
                                            message: AppFirebase.staffData!.gender == 1 ? "Female" : "Male"),
                                        const SizedBox(height: 20.0),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                              const SizedBox(height: 20.0),
                              MaterialButton(
                                onPressed: () async {
                                  Navigator.of(context).pop();
                                  toastGeneral("Signing out from CLinicK...");
                                  await AppFirebase.signOut();
                                },
                                height: 50.0,
                                minWidth: double.maxFinite,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                                child: const Text('LOGOUT'),
                                textColor: ThemeColor.buttonTextColor,
                                color: ThemeColor.accent,
                              ),
                              const SizedBox(height: 10.0),
                              Center(
                                child: Text(
                                  AppConfig.app_version,
                                  style: const TextStyle(
                                    fontSize: 11.0,
                                    color: ThemeColor.secondary,
                                  ),
                                ),
                              ),
                              const SizedBox(height: 20.0),
                            ],
                          ),
                        );
                      },
                    ),
                  ),
                ),
                if (isBusy)
                  Positioned.fill(
                    child: Container(
                      color: Colors.white70,
                      child: const Center(
                        child: const CircularProgressIndicator(
                          valueColor: AlwaysStoppedAnimation(ThemeColor.accent),
                        ),
                      ),
                    ),
                  ),
              ],
            );
          },
        ),
      ),
    );
  }

  Widget editingHeader() {
    return Row(
      children: [
        Container(
          height: 40.0,
          width: 40.0,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            boxShadow: [
              BoxShadow(
                spreadRadius: 1.0,
                blurRadius: 4.0,
                color: ThemeColor.shadow.withOpacity(0.25),
                offset: Offset(0, 0),
              )
            ],
          ),
          clipBehavior: Clip.antiAlias,
          child: Material(
            color: ThemeColor.background,
            child: IconButton(
              onPressed: () {
                if (BlocProvider.of<ProfileStateCubit>(context).state) return;
                newProfileImage = null;
                imagePicked.value = false;
                BlocProvider.of<ProfileStateCubit>(context).change(false);
                BlocProvider.of<EditingStateCubit>(context).change(false);
              },
              tooltip: "Exit Edit Mode",
              icon: const Icon(
                LineIcons.times,
                color: ThemeColor.secondary2,
              ),
            ),
          ),
        ),
        const SizedBox(width: 15.0),
        const Text(
          'Editing My Profile',
          style: const TextStyle(
            color: ThemeColor.secondary2,
            fontSize: 17.0,
          ),
        ),
        const Spacer(),
        Container(
          height: 40.0,
          width: 40.0,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            boxShadow: [
              BoxShadow(
                spreadRadius: 1.0,
                blurRadius: 4.0,
                color: ThemeColor.shadow.withOpacity(0.25),
                offset: Offset(0, 0),
              )
            ],
          ),
          clipBehavior: Clip.antiAlias,
          child: Material(
            color: ThemeColor.background,
            child: IconButton(
              onPressed: () => onSave(),
              tooltip: "Save Changes",
              icon: const Icon(
                LineIcons.save,
                color: ThemeColor.secondary2,
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget normalHeader() {
    return Row(
      children: [
        Container(
          height: 40.0,
          width: 40.0,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            boxShadow: [
              BoxShadow(
                spreadRadius: 1.0,
                blurRadius: 4.0,
                color: ThemeColor.shadow.withOpacity(0.25),
                offset: Offset(0, 0),
              )
            ],
          ),
          clipBehavior: Clip.antiAlias,
          child: Material(
            color: ThemeColor.background,
            child: InkWell(
              onTap: () async {
                Navigator.of(context).pop();
              },
              child: const Center(
                child: const Icon(
                  LineIcons.arrowLeft,
                  color: ThemeColor.secondary2,
                ),
              ),
            ),
          ),
        ),
        const SizedBox(width: 15.0),
        const Text(
          'My Profile',
          style: const TextStyle(
            color: ThemeColor.secondary2,
            fontSize: 17.0,
          ),
        ),
        const Spacer(),
        Container(
          height: 40.0,
          width: 40.0,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            boxShadow: [
              BoxShadow(
                spreadRadius: 1.0,
                blurRadius: 4.0,
                color: ThemeColor.shadow.withOpacity(0.25),
                offset: Offset(0, 0),
              )
            ],
          ),
          clipBehavior: Clip.antiAlias,
          child: Material(
            color: ThemeColor.background,
            child: IconButton(
              onPressed: () {
                BlocProvider.of<EditingStateCubit>(context).change(true);
              },
              tooltip: "Go To Edit Mode",
              icon: const Icon(
                LineIcons.edit,
                color: ThemeColor.secondary2,
              ),
            ),
          ),
        ),
      ],
    );
  }

  Future<void> uploadNewnewProfileImage() async {
    final ImagePicker picker = ImagePicker();
    final pickedFile = await picker.getImage(
      source: ImageSource.gallery,
    );

    if (pickedFile != null) {
      newProfileImage = await ImageCropper.cropImage(
        sourcePath: pickedFile.path,
        aspectRatioPresets: [
          CropAspectRatioPreset.square,
        ],
        maxWidth: 200,
        maxHeight: 200,
        androidUiSettings: AndroidUiSettings(
            toolbarTitle: 'Crop Image',
            toolbarColor: ThemeColor.accent,
            toolbarWidgetColor: Colors.white,
            initAspectRatio: CropAspectRatioPreset.original,
            activeControlsWidgetColor: ThemeColor.accent,
            lockAspectRatio: true),
      );
      if (newProfileImage != null) {
        imagePicked.value = true;
      }
    }
  }

  void onSave() async {
    FocusScope.of(context).requestFocus(FocusNode());
    bool _isBusy = BlocProvider.of<ProfileStateCubit>(context).state;

    // * Check if the process is currently busy, if yes, do not continue
    if (_isBusy) return;
    BlocProvider.of<ProfileStateCubit>(context).change(true);
    formKey.currentState?.save();

    // * Check if the field(s) are empty then do not continue
    if (address.isEmpty) {
      toastError("Please do not leave the address field empty.");
      await Future.delayed(Duration(seconds: 2));
      BlocProvider.of<ProfileStateCubit>(context).change(false);
      return;
    }

    String? _photoUrl;

    if (newProfileImage != null && imagePicked.value == true) {
      try {
        toastGeneral("Uploading your new profile image...");
        TaskSnapshot _task = await AppFirebase.storage
            .ref()
            .child('profile_imgs')
            .child(AppFirebase.uid() + ".jpg")
            .putFile(newProfileImage!);

        if (_task.state == TaskState.success) {
          _photoUrl = await _task.ref.getDownloadURL();
          await AppFirebase.firestore.collection('staffs').doc(AppFirebase.uid()).set(
            {'photo': _photoUrl},
            SetOptions(merge: true),
          );
        }
      } catch (ex) {
        toastError("Unable to upload your new profile image. Please try again.");
        newProfileImage = null;
        imagePicked.value = false;
        BlocProvider.of<ProfileStateCubit>(context).change(false);
        return;
      }
    }

    try {
      toastGeneral("Saving your changes...");
      await AppFirebase.addUpdateStaffDataByMap({
        'address': address,
        'specialization': selectedSpecialization.value,
      });

      AppFirebase.staffData = StaffDataModel.editData(
        AppFirebase.staffData!,
        address,
        StaffSpecializationTypes.values[selectedSpecialization.value],
        _photoUrl,
      );

      await Future.delayed(Duration(seconds: 1));
      newProfileImage = null;
      imagePicked.value = false;

      toastGeneral("Successfully saved the changes you made.");
    } catch (ex) {
      toastError("Unable to save the changes you made. Please try again.");
    }

    BlocProvider.of<ProfileStateCubit>(context).change(false);
    BlocProvider.of<EditingStateCubit>(context).change(false);
  }
}
