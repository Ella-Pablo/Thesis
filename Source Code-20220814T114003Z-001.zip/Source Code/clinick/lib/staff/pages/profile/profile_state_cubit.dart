import 'package:flutter_bloc/flutter_bloc.dart';

class ProfileStateCubit extends Cubit<bool> {
  ProfileStateCubit() : super(false);

  void change(bool newState) {
    if (state != newState) {
      emit(newState);
    }
  }
}
