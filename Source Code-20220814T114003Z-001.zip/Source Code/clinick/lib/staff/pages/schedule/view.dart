import 'package:clinick/config/app_config.dart';
import 'package:clinick/config/color.dart';
import 'package:clinick/database/app_firebase.dart';
import 'package:clinick/models/schedule_model.dart';
import 'package:clinick/models/staff_data_model.dart';
import 'package:clinick/staff/pages/schedule/blocs/bloc.dart';
import 'package:clinick/staff/pages/schedule/blocs/events.dart';
import 'package:clinick/staff/pages/schedule/blocs/states.dart';
import 'package:clinick/staff/pages/schedule/scheduler_item.dart';
import 'package:clinick/widgets/dialog_templates.dart';
import 'package:clinick/widgets/state_view_template.dart';
import 'package:clinick/widgets/toast.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:line_icons/line_icons.dart';

class StaffPageSchedule extends StatefulWidget {
  @override
  _StaffPageScheduleState createState() => _StaffPageScheduleState();
}

class _StaffPageScheduleState extends State<StaffPageSchedule> {
  @override
  void initState() {
    BlocProvider.of<StaffScheduleBloc>(context).add(StaffScheduleEventRequest());
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0.0,
        leading: const SizedBox(),
        leadingWidth: 0.0,
        elevation: 0.0,
        title: Row(
          children: [
            const SizedBox(width: 10.0),
            IconButton(
              icon: const Icon(
                LineIcons.arrowLeft,
                color: ThemeColor.primary,
              ),
              splashRadius: 24.0,
              padding: const EdgeInsets.all(8.0),
              onPressed: () => Navigator.of(context).pop(),
            ),
            const SizedBox(width: 15.0),
            const Text(
              'My Schedule',
              style: const TextStyle(
                fontSize: 17.0,
                fontWeight: FontWeight.bold,
                color: ThemeColor.primary,
              ),
            ),
            const Spacer(),
            IconButton(
              tooltip: 'Edit All Schedule',
              icon: Icon(LineIcons.editAlt),
              color: ThemeColor.accent,
              splashRadius: 24.0,
              onPressed: () => onEditAll(),
            ),
            IconButton(
              tooltip: 'Create/Reset Schedules',
              icon: Icon(LineIcons.calendarPlus),
              color: ThemeColor.accent,
              splashRadius: 24.0,
              onPressed: () => onCreateClicked(),
            ),
            const SizedBox(width: 5.0),
          ],
        ),
      ),
      body: BlocBuilder<StaffScheduleBloc, StaffScheduleState>(
        builder: (context, state) {
          if (state is StaffScheduleStateSuccess) {
            final ScheduleModel _schedule = state.schedule;
            return ListView.builder(
              itemCount: _schedule.schedules.length,
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.all(15.0),
              itemBuilder: (context, index) {
                final ScheduleItemModel _scheduleItem = _schedule.schedules[index];
                final String _sub = _scheduleItem.isNoSchedule
                    ? "No Schedule"
                    : "${_scheduleItem.start!.format(context)}  to  ${_scheduleItem.end!.format(context)}";
                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 5.0),
                  child: SchedulerItem(
                    title: _scheduleItem.name,
                    subtitle: _sub,
                    onEditClicked: () => onSingleEdit(_scheduleItem.day, _schedule.schedules),
                    onUnSchedClicked: () => onUnSched(_scheduleItem.day, _schedule.schedules),
                  ),
                );
              },
            );
          } else if (state is StaffScheduleStateInProgress) {
            return const Center(
              child: const CircularProgressIndicator(
                valueColor: AlwaysStoppedAnimation(
                  ThemeColor.accent,
                ),
              ),
            );
          } else if (state is StaffScheduleStateEmpty) {
            return StateView(
              title: 'Nothing to see here!',
              message:
                  "It looks like you haven't set your schedule. Kindly create your schedule by clicking the 'calendar' icon above.",
              assetPath: AppConfig.asset_emptyImage,
            );
          } else if (state is StaffScheduleStateFailed) {
            return StateView(
              title: 'Sorry for the trouble!',
              message: "We encountered an error while trying to retrieve your schedules. Please try again.",
              assetPath: AppConfig.asset_failedImage,
            );
          }

          return const SizedBox();
        },
      ),
    );
  }

  void onEditAll() async {
    final StaffScheduleState _state = BlocProvider.of<StaffScheduleBloc>(context).state;
    if (_state is StaffScheduleStateInProgress) {
      toastGeneral("The system is currently busy. Please try again later.");
      return;
    } else if (!(_state is StaffScheduleStateSuccess)) {
      toastError("This action cannot proceed with an empty schedule.");
      return;
    }

    toastGeneral('Select your start time');
    await Future.delayed(Duration(milliseconds: 500));

    final TimeOfDay? _start = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
    );

    if (_start != null) {
      toastGeneral('Select your end time');
      await Future.delayed(Duration(milliseconds: 500));

      final TimeOfDay? _end = await showTimePicker(
        context: context,
        initialTime: TimeOfDay.now(),
      );

      if (_end != null) {
        // Show alert before continuing
        final bool? _result = await showDialog(
          context: context,
          builder: (_) {
            return CriticalDialogTemplate(
              message: 'This action will replace all of the current data of your schedule and is not reversible.',
            );
          },
        );

        if (_result != null) {
          if (!_result) return;
        } else {
          return;
        }

        await AppFirebase.firestore.collection('schedules').doc(AppFirebase.uid()).set(
              ScheduleModel(
                staffName: "", // * Not Included
                specialization: StaffSpecializationTypes.values[0], // * Not Included
                schedules: List.generate(
                    7,
                    (index) => ScheduleItemModel(
                          day: index,
                          start: _start,
                          end: _end,
                        )).toList(),
              ).toMap(true),
              SetOptions(merge: true),
            );

        toastGeneral('Successfully saved your changes.');
      }
    }
  }

  void onUnSched(int index, List<ScheduleItemModel> schedules) async {
    // Show alert before continuing
    final bool? _result = await showDialog(
      context: context,
      builder: (_) {
        return CriticalDialogTemplate(
          message: "This action will mark the selected day as 'No Schedule'.",
        );
      },
    );

    if (_result != null) {
      if (!_result) return;
    } else {
      return;
    }

    final List<ScheduleItemModel> _finalList = [];

    for (ScheduleItemModel sched in schedules) {
      if (sched.day == index) {
        _finalList.add(ScheduleItemModel(day: index, start: null, end: null));
      } else {
        _finalList.add(sched);
      }
    }
    await AppFirebase.firestore.collection('schedules').doc(AppFirebase.uid()).set(
          ScheduleModel(
            staffName: "", // * Not Included
            specialization: StaffSpecializationTypes.values[0], // * Not Included
            schedules: _finalList,
          ).toMap(true),
          SetOptions(merge: true),
        );

    toastGeneral('Successfully saved your changes.');
  }

  void onSingleEdit(int index, List<ScheduleItemModel> schedules) async {
    toastGeneral('Select your start time');
    await Future.delayed(Duration(milliseconds: 500));

    final TimeOfDay? _start = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
    );

    if (_start != null) {
      toastGeneral('Select your end time');
      await Future.delayed(Duration(milliseconds: 500));

      final TimeOfDay? _end = await showTimePicker(
        context: context,
        initialTime: TimeOfDay.now(),
      );

      if (_end != null) {
        final List<ScheduleItemModel> _finalList = [];

        for (ScheduleItemModel sched in schedules) {
          if (sched.day == index) {
            _finalList.add(ScheduleItemModel(day: index, start: _start, end: _end));
          } else {
            _finalList.add(sched);
          }
        }

        await AppFirebase.firestore.collection('schedules').doc(AppFirebase.uid()).set(
              ScheduleModel(
                staffName: "", // * Not Included
                specialization: StaffSpecializationTypes.values[0], // * Not Included
                schedules: _finalList,
              ).toMap(true),
              SetOptions(merge: true),
            );

        toastGeneral('Successfully saved your changes.');
      }
    }
  }

  void onCreateClicked() async {
    final StaffScheduleState _state = BlocProvider.of<StaffScheduleBloc>(context).state;

    if (_state is StaffScheduleStateInProgress) {
      toastGeneral("The system is currently busy. Please try again later.");
      return;
    }

    bool _isSafe = _state is StaffScheduleStateEmpty;

    if (!_isSafe) {
      // Show alert before continuing
      final bool? _result = await showDialog(
        context: context,
        builder: (_) {
          return CriticalDialogTemplate(
            message: 'This action will wipe out any previous data of your schedule and is not reversible.',
          );
        },
      );

      if (_result != null) {
        if (!_result) return;
      } else {
        return;
      }
    }

    await Future.delayed(Duration(seconds: 1));

    // * Create/Reset Schedule:
    await AppFirebase.firestore.collection('schedules').doc(AppFirebase.uid()).set(
          ScheduleModel(
            staffName: AppFirebase.staffData?.fullName ?? "",
            specialization: AppFirebase.staffData?.specialization ?? StaffSpecializationTypes.values[0],
            schedules: List.generate(
                7,
                (index) => ScheduleItemModel(
                      day: index,
                      start: TimeOfDay(hour: 8, minute: 0),
                      end: TimeOfDay(hour: 16, minute: 0),
                    )).toList(),
          ).toMap(),
          SetOptions(merge: true),
        );
    toastGeneral('Successfully generated new schedules.');
  }
}
