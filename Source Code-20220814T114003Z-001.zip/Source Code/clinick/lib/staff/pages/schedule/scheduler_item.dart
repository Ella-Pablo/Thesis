import 'package:clinick/config/color.dart';
import 'package:flutter/material.dart';
import 'package:line_icons/line_icons.dart';

class SchedulerItem extends StatelessWidget {
  const SchedulerItem({
    required this.title,
    required this.subtitle,
    required this.onEditClicked,
    required this.onUnSchedClicked,
  });

  final String title;
  final String subtitle;
  final Function onEditClicked;
  final Function onUnSchedClicked;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.maxFinite,
      child: Material(
        elevation: 5.0,
        borderRadius: BorderRadius.circular(8.0),
        color: ThemeColor.background,
        shadowColor: ThemeColor.shadow.withOpacity(0.35),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(15.0, 10.0, 5.0, 10.0),
          child: Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        fontSize: 16.0,
                        fontWeight: FontWeight.bold,
                        color: ThemeColor.secondary2,
                      ),
                    ),
                    const SizedBox(height: 3.0),
                    Row(
                      children: [
                        Icon(
                          LineIcons.businessTime,
                          color: ThemeColor.accent,
                          size: 16.0,
                        ),
                        const SizedBox(width: 5.0),
                        Text(
                          subtitle,
                          style: const TextStyle(
                            fontSize: 14.0,
                            color: ThemeColor.secondary,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              IconButton(
                tooltip: 'Set to No Schedule',
                icon: Icon(LineIcons.calendarTimes),
                color: ThemeColor.accent,
                iconSize: 20.0,
                splashRadius: 20.0,
                padding: EdgeInsets.zero,
                onPressed: () => onUnSchedClicked(),
              ),
              IconButton(
                tooltip: 'Edit Time',
                icon: Icon(LineIcons.pen),
                color: ThemeColor.accent,
                iconSize: 20.0,
                splashRadius: 20.0,
                padding: EdgeInsets.zero,
                onPressed: () => onEditClicked(),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
