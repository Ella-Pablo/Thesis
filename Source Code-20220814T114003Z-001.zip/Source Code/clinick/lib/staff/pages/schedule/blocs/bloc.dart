import 'dart:async';

import 'package:clinick/database/app_firebase.dart';
import 'package:clinick/models/schedule_model.dart';
import 'package:clinick/staff/pages/schedule/blocs/events.dart';
import 'package:clinick/staff/pages/schedule/blocs/states.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class StaffScheduleBloc extends Bloc<StaffScheduleEvent, StaffScheduleState> {
  StaffScheduleBloc() : super(StaffScheduleStateInProgress());

  StreamSubscription? subscription;
  ScheduleModel? schedule;
  bool refresher = true;

  @override
  Stream<StaffScheduleState> mapEventToState(StaffScheduleEvent event) async* {
    if (event is StaffScheduleEventRequest) {
      yield StaffScheduleStateInProgress();
      await Future.delayed(Duration(seconds: 1));

      subscription?.cancel();
      subscription = AppFirebase.firestore.collection('schedules').doc(AppFirebase.uid()).snapshots().listen(
        (event) {
          if (state is StaffScheduleStateEmpty) emit(StaffScheduleStateInProgress());

          try {
            if (!event.exists) {
              emit(
                StaffScheduleStateEmpty(),
              );
              return;
            }

            schedule = ScheduleModel.fromSnapshot(event.id, event.data()!);

            refresher = !refresher;

            emit(StaffScheduleStateSuccess(
              schedule: schedule!,
              refresher: refresher,
            ));
          } catch (ex) {
            //print(ex);
            emit(
              StaffScheduleStateFailed(),
            );
          }
        },
      );
    }
  }

  @override
  Future<void> close() {
    subscription?.cancel();
    return super.close();
  }
}
