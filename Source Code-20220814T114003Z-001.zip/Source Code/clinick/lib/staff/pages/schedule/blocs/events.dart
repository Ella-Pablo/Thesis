import 'package:equatable/equatable.dart';

abstract class StaffScheduleEvent extends Equatable {
  const StaffScheduleEvent();

  @override
  List<Object> get props => [];
}

class StaffScheduleEventRequest extends StaffScheduleEvent {}
