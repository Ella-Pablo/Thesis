import 'package:clinick/models/schedule_model.dart';
import 'package:equatable/equatable.dart';

abstract class StaffScheduleState extends Equatable {
  const StaffScheduleState();

  @override
  List<Object> get props => [];
}

class StaffScheduleStateEmpty extends StaffScheduleState {}

class StaffScheduleStateInProgress extends StaffScheduleState {}

class StaffScheduleStateSuccess extends StaffScheduleState {
  final ScheduleModel schedule;
  final bool refresher;
  const StaffScheduleStateSuccess({required this.schedule, required this.refresher});

  @override
  List<Object> get props => [schedule, refresher];
}

class StaffScheduleStateFailed extends StaffScheduleState {}
