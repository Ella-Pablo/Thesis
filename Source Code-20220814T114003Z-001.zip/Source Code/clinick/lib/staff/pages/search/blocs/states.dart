import 'package:clinick/models/patient_data_model.dart';
import 'package:equatable/equatable.dart';

abstract class SearchPatientState extends Equatable {
  const SearchPatientState();

  @override
  List<Object> get props => [];
}

class SearchPatientStateEmpty extends SearchPatientState {}

class SearchPatientStateInProgress extends SearchPatientState {}

class SearchPatientStateSuccess extends SearchPatientState {
  final List<PatientDataModel> patients;
  const SearchPatientStateSuccess({required this.patients});

  @override
  List<Object> get props => [patients];
}

class SearchPatientStateFailed extends SearchPatientState {}
