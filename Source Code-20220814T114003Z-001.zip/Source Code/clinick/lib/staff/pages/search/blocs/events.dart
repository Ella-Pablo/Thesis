import 'package:equatable/equatable.dart';

abstract class SearchPatientEvent extends Equatable {
  const SearchPatientEvent();

  @override
  List<Object> get props => [];
}

class SearchPatientEventEventRequest extends SearchPatientEvent {
  const SearchPatientEventEventRequest({required this.keywords});
  final String keywords;
}
