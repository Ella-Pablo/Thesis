import 'package:cached_network_image/cached_network_image.dart';
import 'package:clinick/blocs/messaging/chatbox/bloc.dart';
import 'package:clinick/config/app_config.dart';
import 'package:clinick/config/color.dart';
import 'package:clinick/database/app_firebase.dart';
import 'package:clinick/database/msg_firebase.dart';
import 'package:clinick/models/message_info_model.dart';
import 'package:clinick/models/patient_data_model.dart';
import 'package:clinick/patient/views/pages/search/blocs/states.dart';
import 'package:clinick/staff/pages/appointment_maker.dart';
import 'package:clinick/staff/pages/covid_tracker/blocs/tagger_bloc/bloc.dart';
import 'package:clinick/staff/pages/covid_tracker/patient_tagger.dart';
import 'package:clinick/staff/pages/record_adder/blocs/bloc.dart';
import 'package:clinick/staff/pages/record_adder/view.dart';
import 'package:clinick/staff/pages/search/blocs/bloc.dart';
import 'package:clinick/staff/pages/search/blocs/events.dart';
import 'package:clinick/staff/pages/search/blocs/states.dart';
import 'package:clinick/views/chat_box/view.dart';
import 'package:clinick/widgets/state_view_template.dart';
import 'package:clinick/widgets/toast.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:line_icons/line_icons.dart';

class StaffPageSearch extends StatefulWidget {
  const StaffPageSearch({this.showTaggerOnly = false});
  final bool showTaggerOnly;
  @override
  _PatientStaffPageSearch createState() => _PatientStaffPageSearch();
}

class _PatientStaffPageSearch extends State<StaffPageSearch> {
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();
  String keywords = "";
  String peerImageUrl = "";

  void startSearch() {
    FocusScope.of(context).requestFocus(FocusNode());
    formKey.currentState?.save();

    if (keywords.isEmpty) {
      toastGeneral("Please enter a name to search.");
      return;
    }

    BlocProvider.of<SearchPatientBloc>(context).add(
      SearchPatientEventEventRequest(
        keywords: keywords,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0.0,
        backgroundColor: ThemeColor.background,
        elevation: 0.0,
        title: Form(
          key: formKey,
          child: TextFormField(
            decoration: InputDecoration(
              hintText: "Enter your Patient's Name",
              hintStyle: const TextStyle(
                color: ThemeColor.inputHint,
                fontSize: 16.0,
              ),
              enabledBorder: InputBorder.none,
              focusedBorder: InputBorder.none,
            ),
            style: const TextStyle(
              fontSize: 17.0,
              color: ThemeColor.secondary,
            ),
            onSaved: (text) => keywords = text ?? "",
            onFieldSubmitted: (text) => startSearch(),
          ),
        ),
        actions: [
          IconButton(
            tooltip: "Start Searching",
            icon: Icon(
              Icons.person_search_outlined,
              color: ThemeColor.accent,
            ),
            onPressed: () => startSearch(),
          ),
          const SizedBox(width: 5.0),
        ],
      ),
      body: BlocBuilder<SearchPatientBloc, SearchPatientState>(
        builder: (context, state) {
          if (state is SearchPatientStateSuccess) {
            return Padding(
              padding: const EdgeInsets.symmetric(horizontal: 15.0),
              child: ListView.builder(
                physics: const BouncingScrollPhysics(),
                itemBuilder: (context, index) {
                  final PatientDataModel model = state.patients[index];

                  return Padding(
                    padding: const EdgeInsets.symmetric(vertical: 7.0),
                    child: Material(
                      elevation: 5.0,
                      shadowColor: ThemeColor.shadow.withOpacity(0.35),
                      color: ThemeColor.background,
                      borderRadius: BorderRadius.circular(8.0),
                      child: Padding(
                        padding: const EdgeInsets.all(10.0),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              height: 80.0,
                              width: 80.0,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                border: Border.all(
                                  color: ThemeColor.background2,
                                  width: 2.0,
                                ),
                              ),
                              child: ClipOval(
                                child: CachedNetworkImage(
                                  imageUrl: model.photo,
                                  fit: BoxFit.fill,
                                  memCacheHeight: 150,
                                  memCacheWidth: 150,
                                  placeholder: (_, __) {
                                    return const Center(
                                      child: SizedBox(
                                        width: 20.0,
                                        height: 20.0,
                                        child: const CircularProgressIndicator(
                                          strokeWidth: 2.0,
                                        ),
                                      ),
                                    );
                                  },
                                  errorWidget: (_, __, ___) {
                                    return Image.asset(
                                      AppConfig.asset_noImage,
                                      fit: BoxFit.cover,
                                    );
                                  },
                                ),
                              ),
                            ),
                            const SizedBox(width: 5.0),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const SizedBox(height: 10.0),
                                  Text(
                                    model.fullName,
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(
                                      fontSize: 15.0,
                                      color: ThemeColor.accent,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                  Row(
                                    children: [
                                      Icon(
                                        Icons.place,
                                        size: 14.0,
                                        color: ThemeColor.accent,
                                      ),
                                      const SizedBox(width: 5.0),
                                      Text(
                                        model.address,
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: const TextStyle(
                                          fontSize: 13.5,
                                          color: ThemeColor.secondary,
                                        ),
                                      ),
                                    ],
                                  ),
                                  Row(
                                    children: [
                                      Icon(
                                        Icons.phone,
                                        size: 14.0,
                                        color: ThemeColor.accent,
                                      ),
                                      const SizedBox(width: 5.0),
                                      Text(
                                        model.phone!,
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: const TextStyle(
                                          fontSize: 13.5,
                                          color: ThemeColor.secondary,
                                        ),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 10.0),
                                  SizedBox(
                                    height: 30.0,
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.end,
                                      children: [
                                        if (!widget.showTaggerOnly)
                                          IconButton(
                                            tooltip: 'Add Medical Record',
                                            onPressed: () => onAddMedicalRecord(model),
                                            splashRadius: 24.0,
                                            padding: EdgeInsets.zero,
                                            icon: Icon(LineIcons.medicalFile),
                                            color: ThemeColor.accent,
                                          ),
                                        if (!widget.showTaggerOnly)
                                          IconButton(
                                            tooltip: 'Add An Appointment',
                                            onPressed: () {
                                              if (model.id == null) {
                                                toastError(
                                                    "Unable to get this patient's id. Please try to refresh the page or contact the administrator.");
                                                return;
                                              }
                                              Navigator.push(
                                                context,
                                                CupertinoPageRoute(
                                                  builder: (context) {
                                                    return AppointmentMaker(
                                                      userUid: model.id!,
                                                      userName: model.fullName,
                                                    );
                                                  },
                                                ),
                                              );
                                            },
                                            splashRadius: 24.0,
                                            padding: EdgeInsets.zero,
                                            icon: Icon(LineIcons.calendarPlus),
                                            color: ThemeColor.accent,
                                          ),
                                        if (!widget.showTaggerOnly)
                                          IconButton(
                                            tooltip: 'Message',
                                            onPressed: () => onOpenConvo(model.id!, model.fullName),
                                            splashRadius: 24.0,
                                            padding: EdgeInsets.zero,
                                            icon: Icon(LineIcons.sms),
                                            color: ThemeColor.accent,
                                          ),
                                        if (widget.showTaggerOnly)
                                          IconButton(
                                            tooltip: 'Tag as COVID-19 Positive',
                                            onPressed: () => onTagPatient(model.id!, model.fullName),
                                            splashRadius: 24.0,
                                            padding: EdgeInsets.zero,
                                            icon: Icon(LineIcons.userShield),
                                            color: ThemeColor.accent,
                                          ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                },
                itemCount: state.patients.length,
              ),
            );
          } else if (state is SearchDoctorStateFailed) {
            return StateView(
              title: 'Sorry for the trouble!',
              message: "We encountered an error while trying to process your query. Please try again.",
              assetPath: AppConfig.asset_failedImage,
            );
          } else if (state is SearchDoctorStateEmpty) {
            return StateView(
              title: 'Nothing to see here!',
              message: "It seems that your query doesn't match with any of our data. Try another keyword(s).",
              assetPath: AppConfig.asset_emptyImage,
            );
          } else if (state is SearchPatientStateInProgress) {
            return const Center(
              child: const CircularProgressIndicator(
                valueColor: AlwaysStoppedAnimation(
                  ThemeColor.accent,
                ),
              ),
            );
          }
          return const SizedBox();
        },
      ),
    );
  }

  void onTagPatient(String userId, String userName) {
    Navigator.push(
      context,
      CupertinoPageRoute(
        builder: (context) {
          return BlocProvider(
            create: (_) => CovidTaggerBloc(),
            child: StaffPageCovidTagger(
              userUid: userId,
              userName: userName,
            ),
          );
        },
      ),
    );
  }

  void onAddMedicalRecord(PatientDataModel model) {
    if (model.id == null) {
      toastError("Unable to get this patient's id. Please try to refresh the page or contact the administrator.");
      return;
    }
    Navigator.push(
      context,
      CupertinoPageRoute(
        builder: (context) {
          return BlocProvider(
            create: (_) => RecordAdderBloc(),
            child: RecordAdder(
              userId: model.id!,
              userName: model.fullName,
            ),
          );
        },
      ),
    );
  }

  void onOpenConvo(String userId, String userName) async {
    toastGeneral("Opening Conversation...");

    MessageInfoModel _model = await MsgFirebase.checkCreateConvo(
      userId,
      userName,
      false,
      false,
    );

    String _peerToken = "";
    DocumentSnapshot _snapshot =
        await AppFirebase.firestore.collection('fcmtokens').doc(_model.users[_model.peerIndex]).get();

    if (_snapshot.exists) {
      _peerToken = _snapshot.data()?['token'] ?? "";
    }

    Navigator.push(
      context,
      CupertinoPageRoute(
        builder: (context) {
          return BlocProvider(
            create: (_) => MessageBloc(),
            child: ChatBox(
              infoModel: _model,
              peerImage: peerImageUrl,
              peerToken: _peerToken,
              showToolbar: true,
            ),
          );
        },
      ),
    );
  }
}
