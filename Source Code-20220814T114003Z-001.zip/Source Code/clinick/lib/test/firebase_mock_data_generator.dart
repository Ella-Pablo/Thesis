import 'package:clinick/database/app_firebase.dart';
import 'package:clinick/models/appointment_model.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class FirebaseMockDataGenerator {
  static Future<void> generateMockHistory(List<String> staffids, int numOfDataPerId) async {
    WriteBatch batch = AppFirebase.firestore.batch();

    for (var id in staffids) {
      for (int i = 0; i < numOfDataPerId; i++) {
        batch.set(
          AppFirebase.firestore.collection('history').doc(),
          AppointmentModel(
            userUid: 'ZrzweLTxM5OFZJqi4HWLgh1Hek22',
            userName: 'Mock Data Result $i',
            staffUid: id,
            staffName: 'Staff Name',
            status: AppointmentStatus.done,
            type: 4,
            date: DateTime.fromMillisecondsSinceEpoch(1619276400000),
            start: TimeOfDay(hour: 8, minute: 0),
            end: TimeOfDay(hour: 16, minute: 0),
          ).toMap(),
        );
      }
    }

    await batch.commit();
  }
}
