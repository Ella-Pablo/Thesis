import 'package:background_fetch/background_fetch.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:timezone/data/latest.dart' as tz;

import 'blocs/cubits/busy_state.dart';
import 'config/color.dart';
import 'blocs/user_type_cubit.dart';
import 'database/app_firebase.dart';
import 'models/message_info_model.dart';
import 'models/notification_channel_types.dart';
import 'patient/view.dart';
import 'patient/views/pages/auth/login.dart';
import 'patient/views/pages/auth/verification.dart';
import 'repository/notifications.dart';
import 'staff/pages/auth/login.dart';
import 'staff/pages/auth/verification.dart';
import 'staff/view.dart';
import 'widgets/toast.dart';

class MyApp extends StatefulWidget {
  const MyApp({required this.initialUserType});
  final UserType initialUserType;

  @override
  MyAppState createState() => MyAppState();
}

class MyAppState extends State<MyApp> {
  void registerNotification() async {
    try {
      final FirebaseMessaging _firebaseMessaging = FirebaseMessaging.instance;

      NotificationSettings settings = await _firebaseMessaging.requestPermission(
        alert: true,
        announcement: false,
        badge: true,
        carPlay: false,
        criticalAlert: false,
        provisional: false,
        sound: true,
      );

      if (settings.authorizationStatus == AuthorizationStatus.provisional) {
        toastGeneral('User granted provisional permission');
      } else if (settings.authorizationStatus != AuthorizationStatus.authorized) {
        toastError('User declined or has not accepted permission');
        return;
      }

      FirebaseMessaging.onMessage.listen((RemoteMessage message) async {
        final NotifChannelTypes channelType = NotifChannelTypes.values[int.tryParse(message.data['notiftype']) ?? 0];
        late final AndroidNotificationDetails androidPlatformChannelSpecifics;

        if (channelType == NotifChannelTypes.messages) {
          return;
        } else {
          androidPlatformChannelSpecifics = LocalNotifs.getNotificationDetials(channelType);
        }

        var platformChannelSpecifics = new NotificationDetails(
          android: androidPlatformChannelSpecifics,
        );

        await FlutterLocalNotificationsPlugin().show(
          DateTime.now().millisecondsSinceEpoch,
          message.notification?.title ?? "Untitled Notification",
          message.notification?.body ?? "",
          platformChannelSpecifics,
        );
      });
    } catch (ex) {}
  }

  void configLocalNotifications() async {
    var initializationSettingsAndroid = new AndroidInitializationSettings('app_icon');
    var initializationSettingsIOS = new IOSInitializationSettings();
    var initializationSettings = new InitializationSettings(
      android: initializationSettingsAndroid,
      iOS: initializationSettingsIOS,
    );
    tz.initializeTimeZones();
    await FlutterLocalNotificationsPlugin().initialize(initializationSettings);
  }

  // Platform messages are asynchronous, so we initialize in an async method.
  Future<void> initPlatformState() async {
    // Configure BackgroundFetch.
    await BackgroundFetch.configure(
        BackgroundFetchConfig(
            minimumFetchInterval: 720, //1440
            stopOnTerminate: false,
            enableHeadless: true,
            requiresBatteryNotLow: false,
            requiresCharging: false,
            requiresStorageNotLow: false,
            requiresDeviceIdle: false,
            requiredNetworkType: NetworkType.NONE), (String taskId) async {
      // PRINT: print("[BackgroundFetch] Event received $taskId");
      await Firebase.initializeApp();
      await LocalNotifs.registerTodayMedicationTracker();

      BackgroundFetch.finish(taskId);
    }, (String taskId) async {
      // PRINT: print("[BackgroundFetch] TASK TIMEOUT taskId: $taskId");
      BackgroundFetch.finish(taskId);
    });

    if (!mounted) return;
  }

  @override
  void initState() {
    registerNotification();
    configLocalNotifications();
    initPlatformState();

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) => UserTypeCubit(initialType: widget.initialUserType),
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        color: ThemeColor.background,
        title: 'CLinicK',
        theme: ThemeColor.themeData,
        home: StreamBuilder<User?>(
          stream: AppFirebase.auth.userChanges(),
          builder: (context, snapshot) {
            return BlocBuilder<UserTypeCubit, UserType>(
              builder: (context, state) {
                if (state == UserType.patient) {
                  if (snapshot.data == null) {
                    // * If there is no account logged in, show the login page
                    return BlocProvider(
                      create: (_) => BusyStateCubit(),
                      child: PatientPageLogin(),
                    );
                  } else {
                    // * Check if email is verified
                    if (snapshot.data!.emailVerified == false) {
                      return BlocProvider(
                        create: (_) => BusyStateCubit(),
                        child: PatientPageVerification(),
                      );
                    }
                  }

                  // * Main UI
                  return PatientView();
                } else {
                  if (snapshot.data == null) {
                    // * If there is no account logged in, show the login page
                    return BlocProvider(
                      create: (_) => BusyStateCubit(),
                      child: StaffPageLogin(),
                    );
                  } else {
                    // * Check if email is verified
                    if (snapshot.data!.emailVerified == false) {
                      return BlocProvider(
                        create: (_) => BusyStateCubit(),
                        child: StaffPageVerification(),
                      );
                    }
                  }

                  // * Main UI
                  return StaffView();
                }
              },
            );
          },
        ),
      ),
    );
  }
}
