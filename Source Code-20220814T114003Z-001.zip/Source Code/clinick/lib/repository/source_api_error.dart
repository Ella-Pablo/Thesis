enum SourceApiErrorCodes {
  no_internet_connection,
  connection_timeout,
  internal_error,
  server_error,
  parsing_error,
  unknown,
}

extension SourceApiErrorCodesAsString on SourceApiErrorCodes {
  String get asString {
    switch (this) {
      case SourceApiErrorCodes.no_internet_connection:
        return "Please make sure you are connected to a network with sufficient internet access.";
      case SourceApiErrorCodes.connection_timeout:
        return "Network timeout. It seems that you have an unstable network. Please try again.";
      case SourceApiErrorCodes.server_error:
        return "It seems there is a problem retrieving data from the server. Please try again.";
      case SourceApiErrorCodes.internal_error:
        return "The application encountered an internal error. Please try again.";
      case SourceApiErrorCodes.parsing_error:
        return "The application failed to parse the collected data. Please try again.";
      case SourceApiErrorCodes.unknown:
      default:
        return "An unknown error has occured while getting the data. Please try again.";
    }
  }
}
