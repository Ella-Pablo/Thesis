import 'dart:io';

import 'package:clinick/models/news_model.dart';
import 'package:clinick/models/source_model.dart';
import 'package:clinick/repository/source_api_error.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_cache_manager/flutter_cache_manager.dart';
import 'package:html/dom.dart';
import 'package:html/parser.dart';
import 'package:http/http.dart';

class NewsAPI {
  static String queryNode(Element element, String selector, [String attributeNode = ""]) {
    final Element? node = element.querySelector(selector);
    if (node != null) {
      if (attributeNode == "") {
        String content = node.text.trim();
        return content;
      } else {
        String content = node.attributes[attributeNode]!.trim();
        return content;
      }
    }
    return "";
  }

  static Future<SourceModelHtml> getHtmlSource(String url, [cache = false, BaseCacheManager? cacher]) async {
    final Client httpClient = Client();
    final Map<String, String> headers = {
      "user-agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.83 Safari/537.36 Edg/85.0.564.44",
      "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
      "accept-language": "en-US,en;q=0.5",
      "accept-encoding": "gzip, deflate",
      "connection": "keep-alive",
    };
    final BaseCacheManager _finalCacher = cacher ?? DefaultCacheManager();
    SourceApiErrorCodes? _errorCode;
    bool _hasError = false;

    try {
      final _resp = await httpClient.get(Uri.parse(url), headers: headers);
      if (_resp.statusCode == 200) {
        if (cache) {
          await _finalCacher.removeFile(url);
          await _finalCacher.putFile(url, _resp.bodyBytes);
        }

        final Document _doc = await compute(parse, _resp.body);
        return SourceModelHtml(
          document: _doc,
        );
      } else {
        _errorCode = SourceApiErrorCodes.server_error;
        _hasError = true;
      }
    } on SocketException catch (ex) {
      int _code = ex.osError!.errorCode;
      if (_code == 7) {
        _errorCode = SourceApiErrorCodes.no_internet_connection;
      } else if (_code == 110) {
        _errorCode = SourceApiErrorCodes.connection_timeout;
      }
      _hasError = true;
    } catch (ex) {
      _errorCode = SourceApiErrorCodes.internal_error;
      _hasError = true;
    }

    if (_hasError && cache) {
      File? _cachedFile = await _finalCacher.getSingleFile(url);
      String _cacheRes = await _cachedFile.readAsString();
      final Document _doc = await compute(parse, _cacheRes);
      return SourceModelHtml(
        document: _doc,
        isFromCache: true,
        errorCode: _errorCode,
      );
    }

    return SourceModelHtml(
      document: null,
      isFromCache: false,
      errorCode: _errorCode,
    );
  }

  static Future<SourceModelNews> getNews() async {
    SourceModelHtml _source = await getHtmlSource('https://www.medicalnewstoday.com/');

    // * There is an error when getting the source
    if (_source.errorCode != null || _source.document == null) {
      return SourceModelNews(
        list: null,
        errorCode: _source.errorCode ?? SourceApiErrorCodes.internal_error,
      );
    }

    final Document doc = _source.document!;
    final List<NewsModel> list = [];

    try {
      int count = 0;
      for (var node in doc.querySelectorAll("#latest-news > ul > li")) {
        count++;

        final String _title = queryNode(node, "div > div > a");
        final String _url = 'https://www.medicalnewstoday.com' + queryNode(node, "div > div > a", "href");
        final String _image = 'https:' + queryNode(node, "div > figure > a > span > span > lazy-image", "src");

        list.add(
          NewsModel(
            url: _url,
            title: _title,
            image: _image,
          ),
        );

        if (count >= 4) break;
      }

      return SourceModelNews(
        list: list,
      );
    } catch (ex) {
      return SourceModelNews(
        list: null,
        errorCode: SourceApiErrorCodes.parsing_error,
      );
    }
  }
}
