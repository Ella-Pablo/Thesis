import 'dart:core';
import 'package:clinick/config/app_config.dart';
import 'package:clinick/config/color.dart';
import 'package:clinick/widgets/state_view_template.dart';
import 'package:clinick/widgets/toast.dart';
import 'package:flutter/material.dart';
import 'package:line_icons/line_icons.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'paypal_services.dart';

class PaypalPayment extends StatefulWidget {
  PaypalPayment({required this.toPurchase});
  final Map<String, dynamic> toPurchase;

  @override
  State<StatefulWidget> createState() {
    return PaypalPaymentState();
  }
}

class PaypalPaymentState extends State<PaypalPayment> {
  String? checkoutUrl;
  String? executeUrl;
  String? accessToken;
  bool alreadyLoadedInit = false;
  PaypalServices services = PaypalServices();

  bool isEnableShipping = false;
  bool isEnableAddress = false;

  final String returnURL = 'return.example.com';
  final String cancelURL = 'cancel.example.com';

  Future<String> initPlatform() async {
    if (alreadyLoadedInit) return checkoutUrl ?? "";

    try {
      accessToken = await services.getAccessToken();
      if (accessToken == null) throw Exception();

      final res = await services.createPaypalPayment(widget.toPurchase, accessToken!);
      if (res != null) {
        checkoutUrl = res["approvalUrl"];
        executeUrl = res["executeUrl"];

        toastGeneral("Please wait while we load paypal webpage.");
        alreadyLoadedInit = true;
      }
    } catch (e) {
      rethrow;
    }

    return checkoutUrl ?? "";
  }

  @override
  void initState() {
    super.initState();
    WebView.platform = SurfaceAndroidWebView();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0.0,
        leading: const SizedBox(),
        leadingWidth: 0.0,
        elevation: 0.0,
        title: Row(
          children: [
            const SizedBox(width: 10.0),
            IconButton(
              icon: const Icon(
                LineIcons.arrowLeft,
                color: ThemeColor.primary,
              ),
              splashRadius: 24.0,
              padding: const EdgeInsets.all(8.0),
              onPressed: () => Navigator.of(context).pop(),
            ),
            const SizedBox(width: 15.0),
            const Text(
              'Payment Method',
              style: const TextStyle(
                fontSize: 17.0,
                fontWeight: FontWeight.bold,
                color: ThemeColor.primary,
              ),
            ),
          ],
        ),
      ),
      body: FutureBuilder<String>(
        future: initPlatform(),
        builder: (context, snapshot) {
          if (snapshot.hasData) {
            if (snapshot.data!.isEmpty) {
              return SizedBox.expand(
                child: StateView(
                  title: "Sorry for the trouble!",
                  message: "We encountered an error while trying to create your transaction. Please try again.",
                  assetPath: AppConfig.asset_failedImage,
                ),
              );
            }

            return WebView(
              initialUrl: checkoutUrl,
              javascriptMode: JavascriptMode.unrestricted,
              navigationDelegate: (NavigationRequest request) {
                if (request.url.contains(returnURL)) {
                  final uri = Uri.parse(request.url);
                  final payerID = uri.queryParameters['PayerID'];
                  if (payerID != null) {
                    services.executePayment(executeUrl, payerID, accessToken).then((id) {
                      Navigator.of(context).pop(true);
                    });
                  } else {
                    Navigator.of(context).pop();
                  }
                  return NavigationDecision.prevent;
                } else if (request.url.contains(cancelURL)) {
                  Navigator.of(context).pop();
                  return NavigationDecision.prevent;
                }
                return NavigationDecision.navigate;
              },
            );
          } else if (snapshot.hasError) {
            return SizedBox.expand(
              child: StateView(
                title: "Sorry for the trouble!",
                message: "We encountered an error while trying to create your transaction. Please try again.",
                assetPath: AppConfig.asset_failedImage,
              ),
            );
          }

          return SizedBox.expand(
            child: Center(
              child: const CircularProgressIndicator(
                valueColor: AlwaysStoppedAnimation(ThemeColor.accent),
              ),
            ),
          );
        },
      ),
    );
  }
}
