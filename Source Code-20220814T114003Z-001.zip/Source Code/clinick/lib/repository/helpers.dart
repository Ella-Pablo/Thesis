import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class Helpers {
  static void changeStatusBarTheme(ThemeMode theme) {
    if (theme == ThemeMode.light) {
      SystemChrome.setSystemUIOverlayStyle(
        SystemUiOverlayStyle(
          statusBarColor: Colors.transparent,
          statusBarBrightness: Brightness.light,
          statusBarIconBrightness: Brightness.light,
        ),
      );
    } else {
      SystemChrome.setSystemUIOverlayStyle(
        SystemUiOverlayStyle(
          statusBarColor: Colors.transparent,
          statusBarBrightness: Brightness.dark,
          statusBarIconBrightness: Brightness.dark,
        ),
      );
    }
  }

  static bool isDigit(String s, int idx) => (s.codeUnitAt(idx) ^ 0x30) <= 9 && (s.codeUnitAt(idx) ^ 0x30) >= 0;
}
