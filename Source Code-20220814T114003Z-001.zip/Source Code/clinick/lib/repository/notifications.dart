import 'package:clinick/config/app_config.dart';
import 'package:clinick/models/appointment_model.dart';
import 'package:clinick/models/notification_channel_types.dart';
import 'package:clinick/models/tracker_model.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:timezone/timezone.dart' as tz;

class LocalNotifs {
  static Future<void> checkAddAppointment(BuildContext context, AppointmentModel appointment) async {
    if (appointment.status != AppointmentStatus.paid) return;

    final int _time = DateTime(
      appointment.date!.year,
      appointment.date!.month,
      appointment.date!.day,
      appointment.start!.hour - 2,
      appointment.start!.minute,
    ).millisecondsSinceEpoch;

    if (DateTime.now().compareTo(DateTime.fromMillisecondsSinceEpoch(_time)) >= 0) return;

    final flutterLocalNotificationsPlugin = FlutterLocalNotificationsPlugin();
    final List<PendingNotificationRequest> _pendingNotifs =
        await flutterLocalNotificationsPlugin.pendingNotificationRequests();

    if (_pendingNotifs.indexWhere((e) => e.payload == appointment.id) == -1) {
      final String? _type = AppConfig.appointment_type[appointment.type];
      int _id = 0;
      _pendingNotifs.forEach((e) {
        if (e.id > _id) _id = e.id;
      });
      _id++;
      await flutterLocalNotificationsPlugin
          .zonedSchedule(
            _id,
            "Appointment Reminder${_type == null ? '' : ': $_type'}",
            "You have an appointment with '${appointment.staffName}' on ${appointment.start!.format(context)}.",
            tz.TZDateTime.fromMillisecondsSinceEpoch(tz.local, _time),
            NotificationDetails(
              android: AndroidNotificationDetails(
                "clinick_tracker",
                "CLinicK Tracker Notification",
                "CLinicK Tracker Notification",
                styleInformation: BigTextStyleInformation(''),
                playSound: true,
              ),
            ),
            uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
            androidAllowWhileIdle: true,
            payload: appointment.id,
          )
          .onError((error, stackTrace) {});
    }
  }

  static AndroidNotificationDetails getNotificationDetials(NotifChannelTypes notifType) {
    String _channelId = "clinick_default";
    String _channelName = "CLinicK Notification";
    String _channelDesc = "CLinicK Notification";

    if (notifType == NotifChannelTypes.appointment) {
      _channelId = "clinick_appointment";
      _channelName = "CLinicK Appointment Notification";
      _channelDesc = "CLinicK Appointment Notification";
    } else if (notifType == NotifChannelTypes.messages) {
      _channelId = "clinick_messages";
      _channelName = "CLinicK Message Notification";
      _channelDesc = "CLinicK Message Notification";
    } else if (notifType == NotifChannelTypes.records) {
      _channelId = "clinick_records";
      _channelName = "CLinicK Records Notification";
      _channelDesc = "CLinicK Records Notification";
    }

    return AndroidNotificationDetails(
      _channelId,
      _channelName,
      _channelDesc,
      playSound: true,
      enableVibration: true,
      styleInformation: BigTextStyleInformation(''),
    );
  }

  static Future<void> registerTodayMedicationTracker() async {
    final flutterLocalNotificationsPlugin = FlutterLocalNotificationsPlugin();
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    final String userId = prefs.getString('userid') ?? "";

    QuerySnapshot _data = await FirebaseFirestore.instance
        .collection('trackers')
        .where('userid', isEqualTo: userId)
        .get(GetOptions(source: Source.cache));
    if (_data.docs.isEmpty) return;

    List<TrackerModel> _trackers = _data.docs.map((e) => TrackerModel.fromSnapshot(e.id, e.data())).toList();

    if (_trackers.isEmpty) return;

    final List<PendingNotificationRequest> _pendingNotifs =
        await flutterLocalNotificationsPlugin.pendingNotificationRequests();
    int _id = 0;
    _pendingNotifs.forEach((e) {
      if (e.id > _id) _id = e.id;
    });

    for (TrackerModel track in _trackers) {
      final DateTime _now = DateTime.now();

      if (track.end == null) {
      } else if (_now.compareTo(track.start!) >= 0 && _now.compareTo(track.end!) <= 0) {
      } else {
        continue;
      }

      if (_pendingNotifs
              .indexWhere((e) => e.payload!.startsWith("${track.id}.${_now.year}.${_now.month}.${_now.day}")) ==
          -1) {
        if (track.morning!) {
          _id++;
          registerTrackerNotif(
            flutterLocalNotificationsPlugin,
            _id,
            track,
            0,
          );
        }
        if (track.afternoon!) {
          _id++;
          registerTrackerNotif(
            flutterLocalNotificationsPlugin,
            _id,
            track,
            1,
          );
        }
        if (track.evening!) {
          _id++;
          registerTrackerNotif(
            flutterLocalNotificationsPlugin,
            _id,
            track,
            2,
          );
        }
        if (track.bedtime!) {
          _id++;
          registerTrackerNotif(
            flutterLocalNotificationsPlugin,
            _id,
            track,
            3,
          );
        }
      }

      // Also add tomorrow
      final DateTime _now1 = DateTime.now().add(Duration(days: 1));

      if (track.end == null) {
      } else if (_now1.compareTo(track.start!) >= 0 && _now1.compareTo(track.end!) <= 0) {
      } else {
        continue;
      }

      if (_pendingNotifs
              .indexWhere((e) => e.payload!.startsWith("${track.id}.${_now1.year}.${_now1.month}.${_now1.day}")) ==
          -1) {
        if (track.morning!) {
          _id++;
          registerTrackerNotif(
            flutterLocalNotificationsPlugin,
            _id,
            track,
            0,
            1,
          );
        }
        if (track.afternoon!) {
          _id++;
          registerTrackerNotif(
            flutterLocalNotificationsPlugin,
            _id,
            track,
            1,
            1,
          );
        }
        if (track.evening!) {
          _id++;
          registerTrackerNotif(
            flutterLocalNotificationsPlugin,
            _id,
            track,
            2,
            1,
          );
        }
        if (track.bedtime!) {
          _id++;
          registerTrackerNotif(
            flutterLocalNotificationsPlugin,
            _id,
            track,
            3,
            1,
          );
        }
      }
    }
  }

  static Future<void> registerTrackerNotif(
      FlutterLocalNotificationsPlugin plugin, int id, TrackerModel tracker, int time,
      [int dayAdded = 0]) async {
    late final tz.TZDateTime datetime;
    late final DateTime _now;
    if (dayAdded > 0) {
      _now = DateTime.now().add(Duration(days: 1));
    } else {
      _now = DateTime.now();
    }

    if (time == 1) {
      datetime = tz.TZDateTime.fromMillisecondsSinceEpoch(
          tz.local, DateTime(_now.year, _now.month, _now.day, 13).millisecondsSinceEpoch);
    } else if (time == 2) {
      datetime = tz.TZDateTime.fromMillisecondsSinceEpoch(
          tz.local, DateTime(_now.year, _now.month, _now.day, 18).millisecondsSinceEpoch);
    } else if (time == 3) {
      datetime = tz.TZDateTime.fromMillisecondsSinceEpoch(
          tz.local, DateTime(_now.year, _now.month, _now.day, 21).millisecondsSinceEpoch);
    } else {
      datetime = tz.TZDateTime.fromMillisecondsSinceEpoch(
          tz.local, DateTime(_now.year, _now.month, _now.day, 8).millisecondsSinceEpoch);
    }

    await plugin
        .zonedSchedule(
          id,
          "Medication Reminder",
          "It is time for you to take '${tracker.name}' for your ${tracker.purpose}.\nQuantity/Dosage: ${tracker.quantity}",
          datetime,
          NotificationDetails(
            android: AndroidNotificationDetails(
              "clinick_tracker",
              "CLinicK Tracker Notification",
              "CLinicK Tracker Notification",
              styleInformation: BigTextStyleInformation(''),
              playSound: true,
            ),
          ),
          uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
          androidAllowWhileIdle: true,
          payload: "${tracker.id}.${_now.year}.${_now.month}.${_now.day}.$time",
        )
        .onError((error, stackTrace) {});
  }
}
