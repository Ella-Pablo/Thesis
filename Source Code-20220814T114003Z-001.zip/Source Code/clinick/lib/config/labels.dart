/// A static class that contains all the visual text found/shown in the application
class Labels {
  // * Defaults
  static const String default_no_name_patient = "Unnamed Patient";
  static const String default_no_name_staff = "Unnamed Specialist";

  // * FIREBASE AUTH EXCEPTION CODES
  static String authExceptionCodesToString(String errorCode) {
    switch (errorCode) {
      case "user-disabled":
        return "It seems that your account has been disabled. Contact supportt to get your account back.";

      case "user-not-found":
        return "Sorry, but we don't recognize that user. If you think that this is a mistake, kindly contact us.";

      case "invalid-email":
        return "Unable to process the details you entered. Please input a valid email address.";

      case "network-request-failed":
        return "Please make sure you are connected to a network with sufficient internet access.";

      case "invalid-credential":
        return "There is a problem verifying your account credentials. Please try again.";

      case "weak-password":
        return "Weak Password. Please use a password that have at least 6 characters.";

      case "wrong-password":
        return "Unable to login. It seems that you have entered an incorrect password.";

      case "account-exists-with-different-credential":
        return "The account credential you selected is being used by another user.";

      case 'too-many-requests':
        return "Too many request sent from this device. Please try again later.";

      case "facebook-cancelled":
        return "Facebook login operation has been cancelled by the user.";

      case "facebook-failed":
        return "Unable to login using the facebook account you selected. Please try again.";

      case "facebook-in-progress":
        return "There is already an operation in progress. Please wait.";

      case "app-error":
        return "The application has encountered an internal error. Please try again or contact support.";

      case "invalid-phone-number":
        return "It looks like phone number you entered is not valid. Please try again.";

      case "invalid-verification-code":
        return "The verification code you entered is incorrect. Please try again";

      case "credential-already-in-use":
        return "The phone number you entered is already in use by another user.";

      case "email-already-in-use":
        return "The email address you entered is already in use by another user.";

      case "unknown":
      default:
        return "Unknown server error has occured. Please try again or contact support.";
    }
  }
}
