class StaffSpecialization {
  StaffSpecialization._();

  static StaffSpecialization _instance = StaffSpecialization._();
  static StaffSpecialization get instance => _instance;

  Map<int, String> staffSpecialization = {
    0: "fever,high,blood,pressure,dizziness,pneumonia,stomach,pain,vertigo,headaches,cold,cough,nausea,uti,headache,physician,general,",
    1: "immunization,vaccine,children,child,kid,infant,baby,toddler,cough,cold,stomach,flu,pediatric,cancer,pediatrics,pediatrician,",
    2: "sore,throat,snoring,snore,coughing,cough,mouth,sores,hear,hearing,voice,nose,ear,ears,ent,ear-nose-throat,",
    3: "acidity,jaundice,constipation,piles,acid,gastroenterologist,gastro,",
    4: "knee,pain,shoulder,leg,back,bone,bones,ortho,orthopedic,orthopedist,",
    5: "acne,acnes,scar,scars,dermatology,vitiligo,dandruff,hair,loss,eczema,funga,infection,skin,skins,hairs,nail,hair,nails,rash,rashes,mole,moles,psoriasis,dermatitis,birthmark,melanoma,vitiligo,hives,cellulitis,wart,melasma,contact,derma,dermatitis,laser,dermatalogist,dermatrologists,",
    6: "ecg,ekg,heart,attack,arrythmia,exercise,stress,test,shortness,breath,short,stroke,heat,high,blood,chest,pain,palpitation,palpitate,cardio,cardiologist,cardiologists,",
    7: "gynecologist,gynecologists,obstetric,obstetrician,obstetricians,irregular,periods,menopause,ovarian,cysts,vaginal,vagina,cervix,discharge,pcos,pregnant,hormone,breast,sti,std,pap,smear,infertility,cesarean,sections,section,hysterectomy,cervical,cancer,ivf,egg-freezing,egg,freezing,mammogram,uti,birth,control,",
    8: "erection,premature,ejaculation,hiv,aids,penis,pain,sex,sexologist,sexologists,",
    9: "psychiatrist,psychiatrists,panic,attack,bipolar,autism,schizophrenia,suicide,hearing,voices,mental,psychological,psychology,psych,trauma,hallucinations,delusions,delusion,hallucinate,alcohol,drug,emotion,personal,personality,emotional,outburst,obsessive,compulsive,gender,dysphoria,personality,substance-related,sleep,addiction,addict,depress,depression,anxiety,adhd,alzheimer’s,alzheimers,alzheimer,psychoteraphy,ect,antidepressant,antipsychotic,sedatives,anxiolytics,hypnotics,mood,stabilizer,stimulants,disorder,disorders,",
    10: "x-ray,ct,scan,mri,biopsy,mammogram,scanning,ultrasound,xray,ultrasonic,technologist,technologists,radio,radiologic,radiologist,radiologists,radtech,",
    11: "swab,rapid,blood,urine,stool,vaccination,test,feces,waste,technologist,technologists,medtech,medical,",
    12: "tooth,extraction,teeth,ache,decay,gum,gums,disease,",
  };
}
