class AppConfig {
  static const String app_version = "Version 2.00 (Test Mode)";

  static const String table_patientData = "patients";
  static const String table_staffdata = "staffs";

  static const String asset_noImage = "assets/images/no_photo.png";
  static const String asset_emptyImage = "assets/images/illustration_empty.png";
  static const String asset_failedImage =
      "assets/images/illustration_error.png";

  static const Map<int, String> appointment_type = {
    0: "Other",
    1: "Consultation",
    2: "Oral Prophylaxis",
    3: "Fluoride Treatment",
    4: "PIT & Fissure Sealant",
    5: "Composite Restoration (per surface)",
    6: "Tooth Extraction",
    7: "Special Surgery",
    8: "Soft Tissue Surgery",
    9: "Root Canal Treatment (per canal)",
    10: "Periodontal Treatment (per quadrant)",
    11: "Direct Veneers (per tooth)",
    12: "Indirect Veneers (per tooth) - Ceramage",
    13: "Indirect Veneers (per tooth) - All Porcelain",
    14: "Indirect Veneers (per tooth) - Zirconia",
    15: "Mouthguard",
    16: "Dental Crown (per unit) - Plastic",
    17: "Dental Crown (per unit) - Ordinary Metal",
    18: "Dental Crown (per unit) - Emax",
    19: "Dental Crown (per unit) - Zirconia",
    20: "RPD (per arch) - One-piece casted",
    21: "RPD (per arch) - Stayplate",
    22: "RPD (per arch) - Flexible",
    23: "RPD (per arch) - Combination)",
    24: "Complete Dentures (U/L) - Plastic",
    25: "Complete Dentures (U/L) - Ivocap",
    26: "Complete Dentures (U/L) - Thermosens",
    27: "Retainers (per arch) - Straight",
    28: "Retainers (per arch) - Invisible",
    29: "Orthodontic Treatment - Conventional",
    30: "Orthodontic Treatment - Ceramic",
    31: "Orthodontic Treatment - Self-Ligating",
    32: "Whitening - In Office",
    33: "Whitening - Take-Home",
    34: "Periapical X-Ray",
    35: "Panaromic X-Ray",
  };

  static const Map<int, String> appointment_price = {
    0: "PHP 0.0",
    1: "PHP 300.0",
    2: "PHP 600.0",
    3: "PHP 500.0",
    4: "PHP 600.0",
    5: "PHP 600.0",
    6: "PHP 600.0",
    7: "PHP 7000.0",
    8: "PHP 4000.0",
    9: "PHP 4000.0",
    10: "PHP 2500.0",
    11: "PHP 3500.0",
    12: "PHP 8000.0",
    13: "PHP 15000.0",
    14: "PHP 17000.0",
    15: "PHP 5000.0",
    16: "PHP 3000.0",
    17: "PHP 6000.0",
    18: "PHP 15000.0",
    19: "PHP 15000.0",
    20: "PHP 10000.0",
    21: "PHP 4000.0",
    22: "PHP 12000.0",
    23: "PHP 15000.0",
    24: "PHP 7000.0",
    25: "PHP 15000.0",
    26: "PHP 15000.0",
    27: "PHP 3500.0",
    28: "PHP 3500.0",
    29: "PHP 35000.0",
    30: "PHP 50000.0",
    31: "PHP 50000.0",
    32: "PHP 15000.0",
    33: "PHP 10000.0",
    34: "PHP 550.0",
    35: "PHP 900.0",
  };
}
