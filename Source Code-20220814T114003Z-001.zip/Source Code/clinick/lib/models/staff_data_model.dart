import 'package:intl/intl.dart';

enum StaffSpecializationTypes {
  general_physician,
  pediatrician,
  ent,
  gastroenterologist,
  orthopedist,
  dermatologist,
  cardiologist,
  gynecologist,
  sexologist,
  psychiatrist,
  radtech,
  medtech,
  dentist,
}

extension StaffSpecializationTypesAsString on StaffSpecializationTypes {
  String get asString {
    switch (this) {
      case StaffSpecializationTypes.general_physician:
        return "General Physician";
      case StaffSpecializationTypes.pediatrician:
        return "Pediatrician";
      case StaffSpecializationTypes.ent:
        return "Ear-Nose-Throat (ENT) Specialist";
      case StaffSpecializationTypes.gastroenterologist:
        return "Gastroenterologist";
      case StaffSpecializationTypes.orthopedist:
        return "Orthopedist";
      case StaffSpecializationTypes.dermatologist:
        return "Dermatologist";
      case StaffSpecializationTypes.cardiologist:
        return "Cardiologist";
      case StaffSpecializationTypes.gynecologist:
        return "Gynecologist/Obstetrician";
      case StaffSpecializationTypes.sexologist:
        return "Sexologist";
      case StaffSpecializationTypes.psychiatrist:
        return "Psychiatrist";
      case StaffSpecializationTypes.radtech:
        return "Radiologic Technologist";
      case StaffSpecializationTypes.medtech:
        return "Medical Technologist";
      case StaffSpecializationTypes.dentist:
        return "Dentist";
    }
  }
}

/// This contains all the data of user that came from firestore database (online)
class StaffDataModel {
  final String? id;
  final String? firstName;
  final String middleName;
  final String? lastName;
  final int? gender;

  String get fullName {
    late final String _prefix;
    if (specialization != StaffSpecializationTypes.medtech ||
        specialization != StaffSpecializationTypes.radtech) {
      _prefix = "Dr. ";
    } else {
      _prefix = "";
    }
    return "$_prefix$firstName ${middleName.isNotEmpty ? middleName + " " : ''}$lastName";
  }

  final String? email;
  final String? phone;
  final String address;
  final String photo;
  final StaffSpecializationTypes specialization;

  final DateTime? birthdate;
  String get birthdateString => DateFormat('MMMM dd, yyyy').format(birthdate!);

  const StaffDataModel({
    required this.firstName,
    required this.lastName,
    required this.gender,
    required this.birthdate,
    required this.email,
    required this.phone,
    this.id,
    this.middleName = "",
    this.address = "",
    this.photo = "",
    this.specialization = StaffSpecializationTypes.general_physician,
  });

  int get age {
    final _now = DateTime.now();
    return DateTime(
      _now.year - birthdate!.year,
      _now.month - birthdate!.month,
      _now.day - birthdate!.day,
    ).year;
  }

  factory StaffDataModel.fromMap(String id, Map<String, dynamic> map) {
    return StaffDataModel(
      id: id,
      firstName: map['firstName'] ?? "",
      middleName: map['middleName'] ?? "",
      lastName: map['lastName'] ?? "",
      gender: map['gender'] ?? 1,
      birthdate: DateTime.fromMillisecondsSinceEpoch(map['birthdate'] as int),
      phone: map['phone'] ?? "",
      email: map['email'] ?? "",
      address: map['address'] ?? "",
      photo: map['photo'] ?? "",
      specialization:
          StaffSpecializationTypes.values[map['specialization'] ?? 0],
    );
  }

  factory StaffDataModel.editData(StaffDataModel ref, String? address,
      StaffSpecializationTypes? specialization, String? photo) {
    return StaffDataModel(
      id: ref.id,
      firstName: ref.firstName,
      middleName: ref.middleName,
      lastName: ref.lastName,
      gender: ref.gender,
      birthdate: ref.birthdate,
      phone: ref.phone,
      email: ref.email,
      address: address ?? ref.address,
      photo: photo ?? ref.photo,
      specialization: specialization ?? ref.specialization,
    );
  }

  Map<String, dynamic> toMap() {
    late final String _searchKeywords;
    if (middleName.isNotEmpty) {
      _searchKeywords = "$firstName $middleName $lastName";
    } else {
      _searchKeywords = "$firstName $lastName";
    }

    return {
      'firstName': firstName,
      'middleName': middleName,
      'lastName': lastName,
      'phone': phone,
      'email': email,
      'address': address,
      'specialization': specialization.index,
      'gender': gender ?? 0,
      'birthdate': birthdate!.millisecondsSinceEpoch,
      'search': _searchKeywords.toLowerCase().split(' '),
      'photo': photo,
    };
  }
}
