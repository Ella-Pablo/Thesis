class NewsModel {
  String url;
  String title;
  String image;

  NewsModel({required this.url, required this.title, required this.image});

  @override
  String toString() {
    return "[$title, $url, $image]";
  }
}
