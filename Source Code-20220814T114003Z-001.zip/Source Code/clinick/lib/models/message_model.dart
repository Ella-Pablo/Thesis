import 'package:intl/intl.dart';

enum MessageBoxPosition {
  none,
  first,
  middle,
  last,
}

class MessageModel {
  String? id;
  DateTime time;
  bool seen;
  String content;
  bool isImage;
  int sender;
  DateTime group;
  MessageBoxPosition boxPosition;
  bool lastSeen;

  MessageModel({
    required this.sender,
    required this.time,
    required this.content,
    required this.isImage,
    required this.seen,
    required this.group,
    this.id,
    this.boxPosition = MessageBoxPosition.last,
    this.lastSeen = false,
  });

  factory MessageModel.fromSnapshot(String id, Map<String, dynamic> map) {
    return MessageModel(
      id: id,
      sender: map['sender'],
      time: DateTime.fromMillisecondsSinceEpoch(map['timesent']),
      content: map['content'],
      isImage: map['isimage'],
      seen: map['seen'],
      group: DateTime.fromMillisecondsSinceEpoch(map['timesent']),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'sender': sender,
      'timesent': time.millisecondsSinceEpoch,
      'content': content,
      'isimage': isImage,
      'seen': seen,
    };
  }

  String get dateString {
    final int _days = time.difference(DateTime.now()).abs().inDays;
    if (_days == 1) {
      return "Yesterday";
    } else if (_days > 1) {
      return DateFormat('MMM dd').format(time);
    }

    return DateFormat('hh:mm a').format(time);
  }
}
