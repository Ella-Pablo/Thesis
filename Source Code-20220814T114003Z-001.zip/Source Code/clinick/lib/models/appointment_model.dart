import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

enum AppointmentStatus {
  unknown,
  pending,
  paid,
  done,
}

class AppointmentModel {
  final String? id;
  final String? staffName;
  final String? staffUid;
  final String? userUid;
  final String? userName;

  final TimeOfDay? start;
  final TimeOfDay? end;
  final DateTime? date;

  final int? type; // ---> Refer sa app_config. Nandun lahat ng appointment types
  final AppointmentStatus? status;

  const AppointmentModel({
    this.id,
    this.userUid,
    this.staffUid,
    this.userName,
    this.staffName,
    this.status,
    this.type,
    this.start,
    this.end,
    this.date,
  });

  factory AppointmentModel.fromSnapshot(String id, Map<String, dynamic> data) {
    final double _start = data['start'];
    final double _end = data['end'];

    return AppointmentModel(
      id: id,
      userUid: data['userid'],
      userName: data['username'],
      staffUid: data['staffid'],
      staffName: data['staffname'],
      status: AppointmentStatus.values[data['status']],
      type: data['type'],
      date: DateTime.fromMillisecondsSinceEpoch(data['date']),
      start: TimeOfDay(hour: _start.truncate(), minute: (_start.remainder(1) * 100).round()),
      end: TimeOfDay(hour: _end.truncate(), minute: (_end.remainder(1) * 100).round()),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'userid': userUid,
      'username': userName ?? "",
      'staffid': staffUid,
      'staffname': staffName ?? "",
      'status': status?.index ?? 0,
      'type': type ?? 0,
      'date': date?.millisecondsSinceEpoch ?? -1,
      'start': start!.hour + (start!.minute / 100),
      'end': end!.hour + (end!.minute / 100),
    };
  }

  Map<String, dynamic> toMapAsDone() {
    return {
      'userid': userUid,
      'username': userName ?? "",
      'staffid': staffUid,
      'staffname': staffName ?? "",
      'status': AppointmentStatus.done.index,
      'type': type ?? 0,
      'date': date?.millisecondsSinceEpoch ?? -1,
      'start': start!.hour + (start!.minute / 100),
      'end': end!.hour + (end!.minute / 100),
    };
  }

  String get dateString => DateFormat('MMMM dd, yyyy').format(date!);
}

/* Gamitin yung flutter_local_notifications para ischedule yung 2 hours before na notification
  may method dun na pedeng kunin pending notif requests para madetermine kung hindi pa ba nalalagay yung
  scheduled notif.
*/
