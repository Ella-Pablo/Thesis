enum NotifChannelTypes {
  defaultNotif,
  messages,
  appointment,
  records,
}
