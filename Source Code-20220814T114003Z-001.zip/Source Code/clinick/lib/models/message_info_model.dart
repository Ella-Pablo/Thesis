import 'package:clinick/database/app_firebase.dart';
import 'package:intl/intl.dart';

enum UserType {
  patient,
  staff,
}

class MessageInfoModel {
  final String? id;
  final List<String> users;
  final List<String> names;
  final String lastContent;
  final int lastTimeSent;
  final int lastSender;
  final bool lastIsSeen;
  final bool staffToStaff;
  const MessageInfoModel({
    this.id,
    required this.users,
    required this.names,
    required this.lastContent,
    required this.lastTimeSent,
    required this.lastSender,
    required this.lastIsSeen,
    required this.staffToStaff,
  });

  factory MessageInfoModel.fromSnapshot(String id, Map<String, dynamic> map) {
    return MessageInfoModel(
      id: id,
      users: map['users'].cast<String>(),
      names: map['names'].cast<String>(),
      lastContent: map['lastcontent'] ?? "",
      lastTimeSent: map['lastsenttime'],
      lastSender: map['lastsender'],
      lastIsSeen: map['lastseen'] ?? false,
      staffToStaff: map['stafftostaff'] ?? true,
    );
  }

  factory MessageInfoModel.fromModel(String id, MessageInfoModel ref) {
    return MessageInfoModel(
      id: id,
      users: ref.users,
      names: ref.names,
      lastContent: ref.lastContent,
      lastTimeSent: ref.lastTimeSent,
      lastSender: ref.lastSender,
      lastIsSeen: ref.lastIsSeen,
      staffToStaff: ref.staffToStaff,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'users': users,
      'names': names,
      'lastcontent': lastContent,
      'lastsenttime': lastTimeSent,
      'lastsender': lastSender,
      'lastseen': lastIsSeen,
      'stafftostaff': staffToStaff,
    };
  }

  int get userIndex => users.indexWhere((element) => element == AppFirebase.uid());
  int get peerIndex {
    final int _index = users.indexWhere((element) => element == AppFirebase.uid());
    if (_index == 0) return 1;
    return 0;
  }

  String get dateString {
    if (lastTimeSent <= 0) return "";

    final DateTime _last = DateTime.fromMillisecondsSinceEpoch(lastTimeSent);
    final int _days = _last.difference(DateTime.now()).abs().inDays;
    if (_days == 1) {
      return "Yesterday";
    } else if (_days > 1) {
      return DateFormat('MMM dd').format(_last);
    }

    return DateFormat('hh:mm a').format(_last);
  }
}
