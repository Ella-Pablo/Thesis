import 'package:intl/intl.dart';

/// This contains all the data of user that came from firestore database (online)
class PatientDataModel {
  final String? firstName;
  final String middleName;
  final String? lastName;
  final int? gender;

  String get fullName => "$firstName ${middleName.isNotEmpty ? middleName + " " : ''}$lastName";
  final String? id;
  final String? email;
  final String? phone;
  final String address;
  final String bloodType;
  final String allergies;
  final String photo;

  final DateTime? birthdate;
  String get birthdateString => DateFormat('MMMM dd, yyyy').format(birthdate!);

  const PatientDataModel({
    required this.firstName,
    required this.lastName,
    required this.gender,
    required this.birthdate,
    required this.email,
    required this.phone,
    this.id,
    this.middleName = "",
    this.address = "",
    this.allergies = "",
    this.bloodType = "",
    this.photo = "",
  });

  int get age {
    DateTime currentDate = DateTime.now();
    int age = currentDate.year - birthdate!.year;
    int month1 = currentDate.month;
    int month2 = birthdate!.month;
    if (month2 > month1) {
      age--;
    } else if (month1 == month2) {
      int day1 = currentDate.day;
      int day2 = birthdate!.day;
      if (day2 > day1) {
        age--;
      }
    }
    return age;
  }

  factory PatientDataModel.fromMap(String id, Map<String, dynamic> map) {
    return PatientDataModel(
      id: id,
      firstName: map['firstName'] ?? "",
      middleName: map['middleName'] ?? "",
      lastName: map['lastName'] ?? "",
      gender: map['gender'] ?? 1,
      birthdate: DateTime.fromMillisecondsSinceEpoch(map['birthdate'] as int),
      phone: map['phone'] ?? "",
      address: map['address'] ?? "",
      bloodType: map['bloodType'] ?? "",
      allergies: map['allergies'] ?? "",
      email: map['email'] ?? "",
      photo: map['photo'] ?? "",
    );
  }

  factory PatientDataModel.editData(
      PatientDataModel ref, String? address, String? allergies, String? bloodType, String? photo) {
    return PatientDataModel(
      id: ref.id,
      firstName: ref.firstName,
      middleName: ref.middleName,
      lastName: ref.lastName,
      gender: ref.gender,
      birthdate: ref.birthdate,
      phone: ref.phone,
      email: ref.email,
      address: address ?? ref.address,
      photo: photo ?? ref.photo,
      allergies: allergies ?? ref.allergies,
      bloodType: bloodType ?? ref.bloodType,
    );
  }

  Map<String, dynamic> toMap() {
    late final String _searchKeywords;
    if (middleName.isNotEmpty) {
      _searchKeywords = "$firstName $middleName $lastName";
    } else {
      _searchKeywords = "$firstName $lastName";
    }
    return {
      'firstName': firstName,
      'middleName': middleName,
      'lastName': lastName,
      'phone': phone,
      'email': email,
      'address': address,
      'bloodType': bloodType,
      'allergies': allergies,
      'gender': gender ?? 0,
      'birthdate': birthdate!.millisecondsSinceEpoch,
      'search': _searchKeywords.toLowerCase().split(' '),
      'photo': photo,
    };
  }
}
