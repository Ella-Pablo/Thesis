import 'upload_item_model.dart';

class RecordItemModel {
  final String? id;
  final String userId;
  final String staffId;
  final String userName;
  final String staffName;
  final String url;
  final String fileName;
  final MedicalRecordsType type;
  final DateTime createdAt;

  const RecordItemModel({
    required this.userId,
    required this.staffId,
    required this.userName,
    required this.staffName,
    required this.url,
    required this.createdAt,
    required this.fileName,
    required this.type,
    this.id,
  });

  factory RecordItemModel.fromSnapshot(String id, Map<String, dynamic> map) {
    return RecordItemModel(
      id: id,
      userId: map['userid'],
      staffId: map['staffid'],
      userName: map['username'],
      staffName: map['staffname'],
      url: map['url'],
      createdAt: DateTime.fromMillisecondsSinceEpoch(map['createdat']),
      fileName: map['filename'],
      type: MedicalRecordsType.values[map['type']],
    );
  }
}
