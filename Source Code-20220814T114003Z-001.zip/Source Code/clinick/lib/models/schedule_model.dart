import 'package:flutter/material.dart';

import 'staff_data_model.dart';

class ScheduleModel {
  final String? id;
  final String staffName;
  final StaffSpecializationTypes specialization;

  final List<ScheduleItemModel> schedules;

  const ScheduleModel({
    this.id,
    required this.staffName,
    required this.specialization,
    required this.schedules,
  });

  factory ScheduleModel.fromSnapshot(String id, Map<String, dynamic> data) {
    final List<dynamic> _rawListOfSched = data['schedules'];

    return ScheduleModel(
      id: id,
      staffName: data['staffname'],
      specialization: StaffSpecializationTypes.values[data['specialization'] ?? 0],
      schedules: List<ScheduleItemModel>.generate(
        7,
        (index) => ScheduleItemModel.fromData(
          index,
          _rawListOfSched[index],
        ),
      ),
    );
  }

  Map<String, dynamic> toMap([bool schedulesOnly = false]) {
    if (schedulesOnly) {
      return {
        'schedules': schedules.map((e) => e.toString()).toList(),
      };
    }
    return {
      'staffname': staffName,
      'specialization': specialization.index,
      'schedules': schedules.map((e) => e.toString()).toList(),
    };
  }
}

class ScheduleItemModel {
  final int day;
  final TimeOfDay? start;
  final TimeOfDay? end;

  const ScheduleItemModel({required this.day, required this.start, required this.end});

  factory ScheduleItemModel.fromData(int day, String date) {
    if (date.isEmpty) {
      return ScheduleItemModel(
        day: day,
        start: null,
        end: null,
      );
    }
    final double _start = double.tryParse(date.split(';')[0]) ?? 8.0;
    final double _end = double.tryParse(date.split(';')[1]) ?? 16.0;
    return ScheduleItemModel(
      day: day,
      start: TimeOfDay(hour: _start.truncate(), minute: (_start.remainder(1) * 100).round()),
      end: TimeOfDay(hour: _end.truncate(), minute: (_end.remainder(1) * 100).round()),
    );
  }

  @override
  String toString() {
    if (start == null || end == null) {
      return "";
    }
    return "${start!.hour}.${start!.minute};${end!.hour}.${end!.minute}";
  }

  bool get isNoSchedule => start == null || end == null;

  String get name {
    if (day == 0) {
      return "Monday";
    } else if (day == 1) {
      return "Tuesday";
    } else if (day == 2) {
      return "Wednesday";
    } else if (day == 3) {
      return "Thursday";
    } else if (day == 4) {
      return "Friday";
    } else if (day == 5) {
      return "Saturday";
    } else if (day == 6) {
      return "Sunday";
    }

    return "";
  }
}
