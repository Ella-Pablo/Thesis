import 'package:clinick/models/news_model.dart';
import 'package:clinick/repository/source_api_error.dart';
import 'package:html/dom.dart';

class SourceModelHtml {
  Document? document;
  bool isFromCache;
  SourceApiErrorCodes? errorCode;

  SourceModelHtml({
    required this.document,
    this.isFromCache = false,
    this.errorCode,
  });
}

class SourceModelNews {
  List<NewsModel>? list;
  bool isFromCache;
  SourceApiErrorCodes? errorCode;

  SourceModelNews({
    required this.list,
    this.isFromCache = false,
    this.errorCode,
  });
}
