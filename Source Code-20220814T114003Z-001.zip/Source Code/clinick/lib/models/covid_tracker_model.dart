class CovidTrackerModel {
  final String? id;
  final String userUid;
  final String userName;
  final DateTime start;
  final DateTime end;

  const CovidTrackerModel({
    this.id,
    required this.userUid,
    required this.userName,
    required this.start,
    required this.end,
  });

  factory CovidTrackerModel.fromSnapshot(String id, Map<String, dynamic> map) {
    return CovidTrackerModel(
      id: id,
      userName: map['username'],
      userUid: map['userid'],
      start: DateTime.fromMillisecondsSinceEpoch(map['start']),
      end: DateTime.fromMillisecondsSinceEpoch(map['end']),
    );
  }
}
