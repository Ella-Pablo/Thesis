class CovidGroupModel {
  final String id;
  final String staffUid;
  final String userName;
  final String userUid;
  final DateTime createdAt;

  const CovidGroupModel({
    required this.id,
    required this.staffUid,
    required this.userName,
    required this.userUid,
    required this.createdAt,
  });

  factory CovidGroupModel.fromSnapshot(String id, Map<String, dynamic> map) {
    return CovidGroupModel(
      id: id,
      staffUid: map['staffid'],
      userName: map['username'],
      userUid: map['userid'],
      createdAt: DateTime.fromMillisecondsSinceEpoch(map['createdat']),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'staffid': staffUid,
      'userid': userUid,
      'username': userName,
      'createdat': createdAt.millisecondsSinceEpoch,
    };
  }
}
