import 'package:intl/intl.dart';

class TrackerModel {
  final String? id;
  final String? userUid;
  final String? name;
  final String? purpose;
  final String? quantity;
  final DateTime? start;
  final DateTime? end;
  final bool? morning;
  final bool? afternoon;
  final bool? evening;
  final bool? bedtime;

  TrackerModel({
    this.id,
    this.userUid,
    this.name,
    this.purpose,
    this.quantity,
    this.start,
    this.end,
    this.morning,
    this.afternoon,
    this.evening,
    this.bedtime,
  });

  factory TrackerModel.fromSnapshot(String id, Map<String, dynamic> map) {
    final List<dynamic> _sched = map['taken'];

    return TrackerModel(
      id: id,
      userUid: map['userid'],
      name: map['name'],
      purpose: map['purpose'],
      quantity: map['quantity'],
      start: DateTime.fromMillisecondsSinceEpoch(map['start']),
      end: map['end'] <= 0 ? null : DateTime.fromMillisecondsSinceEpoch(map['end']),
      morning: _sched[0],
      afternoon: _sched[1],
      evening: _sched[2],
      bedtime: _sched[3],
    );
  }

  Map<String, dynamic> toMap() {
    final List<bool> _sched = [
      morning ?? false,
      afternoon ?? false,
      evening ?? false,
      bedtime ?? false,
    ];
    return {
      "userid": userUid,
      "name": name,
      "purpose": purpose,
      "quantity": quantity,
      "start": start?.millisecondsSinceEpoch ?? DateTime.now().millisecondsSinceEpoch,
      "end": end?.millisecondsSinceEpoch ?? 0,
      "taken": _sched,
    };
  }

  String get dateString {
    if (end == null) return "Maintenance";
    return DateFormat('MMM dd, yyyy').format(start!) + " - " + DateFormat('MMM dd, yyyy').format(end!);
  }
}
