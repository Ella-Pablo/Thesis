enum UploadItemStatus {
  idle,
  uploading,
  done,
  failed,
}

enum MedicalRecordsType {
  general,
  laboratory,
  radiology,
}
