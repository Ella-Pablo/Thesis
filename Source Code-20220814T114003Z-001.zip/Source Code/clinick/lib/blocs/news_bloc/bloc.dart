import 'package:clinick/blocs/base/view_event.dart';
import 'package:clinick/blocs/base/view_state.dart';
import 'package:clinick/models/source_model.dart';
import 'package:clinick/repository/news_api.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class NewsBloc extends Bloc<ViewEvent, ViewState> {
  NewsBloc() : super(ViewStateInitial());

  @override
  Stream<ViewState> mapEventToState(ViewEvent event) async* {
    if (event is NewsEventRequest) {
      if (state is ViewStateInProgress) return;
      yield ViewStateInProgress();
    }

    final SourceModelNews _source = await NewsAPI.getNews();

    if (_source.errorCode != null) {
      yield NewsStateSuccess(
        isFailure: true,
      );
      return;
    }

    yield NewsStateSuccess(
      list: _source.list,
    );
  }
}
