import 'package:flutter_bloc/flutter_bloc.dart';

class PhoneStateCubit extends Cubit<bool> {
  PhoneStateCubit() : super(false);

  void change(bool newState) {
    if (state != newState) {
      emit(newState);
    }
  }
}
