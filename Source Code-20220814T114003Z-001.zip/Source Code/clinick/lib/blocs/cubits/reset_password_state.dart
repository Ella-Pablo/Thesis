import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

abstract class ResetPasswordState extends Equatable {
  const ResetPasswordState();

  @override
  List<Object> get props => [];
}

class ResetPasswordSentState extends ResetPasswordState {}

class ResetPasswordSendingState extends ResetPasswordState {}

class ResetPasswordInitialState extends ResetPasswordState {}

class ResetPasswordStateCubit extends Cubit<ResetPasswordState> {
  ResetPasswordStateCubit() : super(ResetPasswordInitialState());

  void changeToSending() => emit(ResetPasswordSendingState());
  void changeToSent() => emit(ResetPasswordSentState());
  void changeToInitial() => emit(ResetPasswordInitialState());
}
