import 'package:equatable/equatable.dart';

abstract class ViewEvent extends Equatable {
  const ViewEvent();

  @override
  List<Object> get props => [];
}

class NewsEventRequest extends ViewEvent {}

class NewsEventRefresh extends ViewEvent {}
