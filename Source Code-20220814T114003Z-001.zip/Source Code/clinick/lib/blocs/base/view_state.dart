import 'package:clinick/models/news_model.dart';
import 'package:equatable/equatable.dart';

abstract class ViewState extends Equatable {
  const ViewState();

  @override
  List<Object> get props => [];
}

class ViewStateInitial extends ViewState {}

class ViewStateInProgress extends ViewState {}

class NewsStateSuccess extends ViewState {
  final List<NewsModel>? list;
  final bool isFailure;

  NewsStateSuccess({this.list, this.isFailure = false});

  @override
  List<Object> get props => [list!, isFailure];
}
