import 'package:clinick/models/message_info_model.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:shared_preferences/shared_preferences.dart';

class UserTypeCubit extends Cubit<UserType> {
  UserTypeCubit({required this.initialType}) : super(initialType);
  final UserType initialType;

  void change(UserType newState) async {
    if (state != newState) {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      prefs.setInt('usertype', newState.index);
      emit(newState);
    }
  }
}
