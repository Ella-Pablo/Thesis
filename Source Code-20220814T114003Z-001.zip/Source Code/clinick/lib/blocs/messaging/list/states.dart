import 'package:clinick/models/message_info_model.dart';
import 'package:equatable/equatable.dart';

abstract class MessageInfoState extends Equatable {
  const MessageInfoState();

  @override
  List<Object> get props => [];
}

class MessageInfoStateEmpty extends MessageInfoState {}

class MessageInfoStateInProgress extends MessageInfoState {}

class MessageInfoStateSuccess extends MessageInfoState {
  final List<MessageInfoModel> conversations;
  final bool refresher;
  final int newMessages;
  const MessageInfoStateSuccess({
    required this.conversations,
    required this.refresher,
    required this.newMessages,
  });

  @override
  List<Object> get props => [conversations, refresher, newMessages];
}

class MessageInfoStateFailed extends MessageInfoState {}
