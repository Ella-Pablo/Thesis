import 'package:equatable/equatable.dart';

abstract class MessageInfoEvent extends Equatable {
  const MessageInfoEvent();

  @override
  List<Object> get props => [];
}

class MessageInfoEventRequest extends MessageInfoEvent {}

class MessageInfoEventSearch extends MessageInfoEvent {
  final String keywords;
  const MessageInfoEventSearch({required this.keywords});
}
