import 'dart:async';

import 'package:clinick/database/app_firebase.dart';
import 'package:clinick/models/message_info_model.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'events.dart';
import 'states.dart';

class MessageInfoBloc extends Bloc<MessageInfoEvent, MessageInfoState> {
  MessageInfoBloc() : super(MessageInfoStateInProgress());

  StreamSubscription? subscription;
  List<MessageInfoModel> conversations = [];
  bool refresher = true;
  int newMessagesCount = 0;

  @override
  Stream<MessageInfoState> mapEventToState(MessageInfoEvent event) async* {
    if (event is MessageInfoEventSearch) {
      if (conversations.isEmpty) return;

      if (event.keywords.isEmpty) {
        yield MessageInfoStateSuccess(
          conversations: conversations,
          refresher: refresher,
          newMessages: newMessagesCount,
        );

        return;
      }

      final _filteredList = conversations.where((e) {
        return e.names[e.peerIndex].toLowerCase().replaceAll('dr. ', '').contains(event.keywords.toLowerCase());
      }).toList();

      yield MessageInfoStateSuccess(
        conversations: _filteredList,
        refresher: refresher,
        newMessages: newMessagesCount,
      );
    } else if (event is MessageInfoEventRequest) {
      yield MessageInfoStateInProgress();
      await Future.delayed(Duration(seconds: 1));

      subscription?.cancel();
      subscription = AppFirebase.firestore
          .collection('conversations')
          .where("users", arrayContains: AppFirebase.uid())
          .where("lastsenttime", isNotEqualTo: 0)
          .orderBy('lastsenttime', descending: true)
          .snapshots()
          .listen(
        (dataEvent) {
          try {
            conversations.clear();
            newMessagesCount = 0;

            for (var item in dataEvent.docs) {
              final MessageInfoModel _model = MessageInfoModel.fromSnapshot(item.id, item.data());
              if (_model.lastIsSeen == false && _model.lastSender != _model.userIndex && newMessagesCount < 9)
                newMessagesCount++;
              conversations.add(_model);
            }

            if (conversations.isEmpty) {
              emit(
                MessageInfoStateEmpty(),
              );
              return;
            }

            refresher = !refresher;

            emit(MessageInfoStateSuccess(
              conversations: conversations,
              refresher: refresher,
              newMessages: newMessagesCount,
            ));
          } catch (ex) {
            //print(ex);
            emit(
              MessageInfoStateFailed(),
            );
          }
        },
      );
    }
  }

  @override
  Future<void> close() {
    subscription?.cancel();
    return super.close();
  }
}
