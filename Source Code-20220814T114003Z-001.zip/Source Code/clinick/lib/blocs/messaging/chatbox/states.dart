import 'package:clinick/models/message_model.dart';
import 'package:equatable/equatable.dart';

abstract class MessageState extends Equatable {
  const MessageState();

  @override
  List<Object> get props => [];
}

class MessageStateEmpty extends MessageState {}

class MessageStateInProgress extends MessageState {}

class MessageStateSuccess extends MessageState {
  final List<MessageModel> messages;
  final bool refresher;
  const MessageStateSuccess({
    required this.messages,
    required this.refresher,
  });

  @override
  List<Object> get props => [messages, refresher];
}

class MessageStateFailed extends MessageState {}
