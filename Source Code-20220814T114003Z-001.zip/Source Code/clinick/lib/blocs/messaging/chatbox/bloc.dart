import 'dart:async';

import 'package:clinick/database/app_firebase.dart';
import 'package:clinick/models/message_model.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'events.dart';
import 'states.dart';

class MessageBloc extends Bloc<MessageEvent, MessageState> {
  MessageBloc() : super(MessageStateInProgress());

  StreamSubscription? subscription;
  List<MessageModel> messages = [];
  bool refresher = true;
  bool isLoadingMore = false;
  bool canLoadMore = true;

  @override
  Stream<MessageState> mapEventToState(MessageEvent event) async* {
    if (event is MessageEventRequest) {
      yield MessageStateInProgress();
      await Future.delayed(Duration(seconds: 1));

      messages.clear();
      subscription?.cancel();
      subscription = AppFirebase.firestore
          .collection('conversations')
          .doc(event.convoId)
          .collection('messages')
          .orderBy('timesent', descending: true)
          .limit(20)
          .snapshots()
          .listen(
        (snapshot) {
          try {
            for (var item in snapshot.docChanges.reversed) {
              if (item.type == DocumentChangeType.added) {
                final MessageModel _currMsg = MessageModel.fromSnapshot(
                  item.doc.id,
                  item.doc.data()!,
                );
                if (messages.isNotEmpty) {
                  MessageModel _prevMsg = messages.last;
                  if (_prevMsg.time.difference(_currMsg.time).abs().inSeconds <= 300) {
                    _currMsg.group = _prevMsg.group;
                    if (_prevMsg.sender == _currMsg.sender) {
                      _prevMsg.boxPosition = MessageBoxPosition.first;

                      if (messages.length > 1) {
                        MessageModel _secondPrevMsg = messages[messages.length - 2];
                        if (_secondPrevMsg.group == _prevMsg.group) {
                          if (_prevMsg.sender == _secondPrevMsg.sender) {
                            _prevMsg.boxPosition = MessageBoxPosition.middle;
                          } else {
                            _prevMsg.boxPosition = MessageBoxPosition.first;
                          }
                        }
                      }
                    } else {
                      _currMsg.boxPosition = MessageBoxPosition.none;
                    }
                  } else {
                    _currMsg.boxPosition = MessageBoxPosition.none;
                  }
                }
                messages.add(_currMsg);
              } else if (item.type == DocumentChangeType.modified) {
                MessageModel _msg = messages.firstWhere((e) => e.id == item.doc.id);
                _msg.seen = item.doc.data()?['seen'] ?? _msg.seen;
              }
            }

            if (messages.isEmpty) {
              emit(
                MessageStateEmpty(),
              );
              return;
            }

            try {
              messages.firstWhere((element) => element.lastSeen == true).lastSeen = false;
            } catch (ex) {}
            try {
              messages.lastWhere((element) => element.seen == true && element.sender == event.userIndex).lastSeen =
                  true;
            } catch (ex) {}

            refresher = !refresher;

            emit(MessageStateSuccess(
              messages: messages,
              refresher: refresher,
            ));
          } catch (ex) {
            emit(
              MessageStateFailed(),
            );
          }
        },
      );
    }
  }

  void loadMore(String convoId) async {
    if (!canLoadMore || convoId.isEmpty) return;
    if (messages.length >= 20 && !isLoadingMore) {
      isLoadingMore = true;

      DocumentSnapshot _docRef = await AppFirebase.firestore
          .collection('conversations')
          .doc(convoId)
          .collection('messages')
          .doc(messages.first.id!)
          .get();

      QuerySnapshot _previousData = await AppFirebase.firestore
          .collection('conversations')
          .doc(convoId)
          .collection('messages')
          .orderBy('timesent', descending: true)
          .startAfterDocument(_docRef)
          .limit(20)
          .get();

      if (_previousData.size > 0) {
        final List<MessageModel> _finalList = [];

        for (var item in _previousData.docChanges.reversed) {
          if (item.type == DocumentChangeType.added) {
            final MessageModel _currMsg = MessageModel.fromSnapshot(
              item.doc.id,
              item.doc.data()!,
            );

            if (_finalList.isNotEmpty) {
              MessageModel _prevMsg = _finalList.last;
              if (_prevMsg.time.difference(_currMsg.time).abs().inSeconds <= 300) {
                _currMsg.group = _prevMsg.group;
                if (_prevMsg.sender == _currMsg.sender) {
                  _prevMsg.boxPosition = MessageBoxPosition.first;

                  if (_finalList.length > 1) {
                    MessageModel _secondPrevMsg = _finalList[_finalList.length - 2];
                    if (_secondPrevMsg.group == _prevMsg.group) {
                      if (_prevMsg.sender == _secondPrevMsg.sender) {
                        _prevMsg.boxPosition = MessageBoxPosition.middle;
                      } else {
                        _prevMsg.boxPosition = MessageBoxPosition.first;
                      }
                    }
                  }
                } else {
                  _currMsg.boxPosition = MessageBoxPosition.none;
                }
              } else {
                _currMsg.boxPosition = MessageBoxPosition.none;
              }
            }
            _finalList.add(_currMsg);
          }
        }

        if (_finalList.length < 20) {
          canLoadMore = false;
        }

        messages.insertAll(0, _finalList);

        refresher = !refresher;

        emit(MessageStateSuccess(
          messages: messages,
          refresher: refresher,
        ));
      }
      isLoadingMore = false;
    }
  }

  @override
  Future<void> close() {
    subscription?.cancel();
    return super.close();
  }
}
