import 'package:cached_network_image/cached_network_image.dart';
import 'package:clinick/config/color.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:line_icons/line_icons.dart';

class MessageImageViewer extends StatelessWidget {
  const MessageImageViewer({required this.url});
  final String url;

  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle(
        statusBarBrightness: Brightness.light,
        statusBarIconBrightness: Brightness.light,
      ),
      child: Scaffold(
        backgroundColor: Colors.black,
        body: SafeArea(
          child: SizedBox.expand(
            child: Stack(
              children: [
                Positioned.fill(
                  child: InteractiveViewer(
                    child: Center(
                      child: Hero(
                        tag: url,
                        child: CachedNetworkImage(
                          imageUrl: url,
                          fit: BoxFit.fitWidth,
                          filterQuality: FilterQuality.low,
                          placeholder: (_, __) => const CircularProgressIndicator(
                            valueColor: AlwaysStoppedAnimation(
                              ThemeColor.accent,
                            ),
                          ),
                          errorWidget: (_, __, ___) => Center(
                            child: Icon(
                              Icons.error,
                              color: ThemeColor.secondary,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                Positioned(
                  top: 20.0,
                  right: 20.0,
                  width: 27.0,
                  height: 27.0,
                  child: Center(
                    child: IconButton(
                      icon: Icon(LineIcons.times),
                      color: Colors.white,
                      splashRadius: 24.0,
                      padding: EdgeInsets.zero,
                      onPressed: () => Navigator.of(context).pop(),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
