import 'package:cached_network_image/cached_network_image.dart';
import 'package:clinick/config/color.dart';
import 'package:clinick/database/msg_firebase.dart';
import 'package:clinick/models/message_model.dart';
import 'package:clinick/views/chat_box/image_viewer.dart';
import 'package:flutter/material.dart';

class MessageBox extends StatelessWidget {
  const MessageBox({
    required this.model,
    required this.userIndex,
    required this.otherImageUrl,
    required this.convoId,
  });
  final MessageModel model;
  final int userIndex;
  final String otherImageUrl;
  final String convoId;

  Widget fromYouMessage(BuildContext context, double w) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.end,
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        Container(
          constraints: BoxConstraints(maxWidth: w - w * 0.28),
          decoration: BoxDecoration(
            color: model.isImage ? ThemeColor.background : ThemeColor.accent,
            borderRadius: model.isImage ? BorderRadius.circular(20.0) : getBorderRadius(true),
            border: model.isImage
                ? Border.all(
                    width: 1.0,
                    color: Color.fromARGB(255, 245, 245, 245),
                  )
                : null,
          ),
          padding: model.isImage ? null : const EdgeInsets.symmetric(horizontal: 13.0, vertical: 10.0),
          margin: model.boxPosition == MessageBoxPosition.first
              ? const EdgeInsets.only(top: 5.0, bottom: 2.0)
              : const EdgeInsets.symmetric(vertical: 2.0),
          clipBehavior: model.isImage ? Clip.antiAlias : Clip.none,
          child: model.isImage
              ? ClipRRect(borderRadius: BorderRadius.circular(20.0), child: imageBox(context))
              : Text(
                  model.content,
                  style: TextStyle(
                    fontSize: 15.0,
                    color: ThemeColor.background,
                  ),
                ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final double w = MediaQuery.of(context).size.width;
    if (model.sender == userIndex) {
      // Your Message
      if (model.lastSeen) {
        return Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            fromYouMessage(context, w),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Text(
                  "Last seen " + model.dateString,
                  style: const TextStyle(
                    fontSize: 10.0,
                    color: ThemeColor.secondary,
                  ),
                ),
                const SizedBox(width: 5.0),
                Container(
                  height: 12.0,
                  width: 12.0,
                  decoration: BoxDecoration(
                    color: ThemeColor.foreground,
                    shape: BoxShape.circle,
                  ),
                  clipBehavior: Clip.antiAlias,
                  child: CachedNetworkImage(
                    imageUrl: otherImageUrl,
                    fit: BoxFit.fill,
                    memCacheHeight: 120,
                    memCacheWidth: 120,
                    placeholder: (_, __) => const SizedBox(),
                    errorWidget: (_, __, ___) => const SizedBox(),
                  ),
                ),
              ],
            )
          ],
        );
      }
      return fromYouMessage(context, w);
    } else {
      // Peer's Message
      if (!model.seen) MsgFirebase.updateMessageSeenStatus(convoId, model.id!);

      return Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          model.boxPosition == MessageBoxPosition.last || model.boxPosition == MessageBoxPosition.none
              ? Container(
                  height: 30.0,
                  width: 30.0,
                  decoration: BoxDecoration(
                    color: ThemeColor.foreground,
                    shape: BoxShape.circle,
                  ),
                  clipBehavior: Clip.antiAlias,
                  child: CachedNetworkImage(
                    imageUrl: otherImageUrl,
                    fit: BoxFit.fill,
                    memCacheHeight: 120,
                    memCacheWidth: 120,
                    placeholder: (_, __) => const SizedBox(),
                    errorWidget: (_, __, ___) => const SizedBox(),
                  ),
                )
              : const SizedBox(
                  width: 30.0,
                  height: 30.0,
                ),
          const SizedBox(width: 5.0),
          Container(
            constraints: BoxConstraints(maxWidth: w - w * 0.28),
            decoration: BoxDecoration(
              color: model.isImage ? ThemeColor.background : Color.fromARGB(255, 245, 245, 245),
              borderRadius: model.isImage ? BorderRadius.circular(20.0) : getBorderRadius(false),
              border: model.isImage
                  ? Border.all(
                      width: 1.0,
                      color: Color.fromARGB(255, 245, 245, 245),
                    )
                  : null,
            ),
            padding: model.isImage ? null : const EdgeInsets.symmetric(horizontal: 13.0, vertical: 10.0),
            margin: model.boxPosition == MessageBoxPosition.first
                ? const EdgeInsets.only(top: 5.0, bottom: 2.0)
                : const EdgeInsets.symmetric(vertical: 2.0),
            clipBehavior: model.isImage ? Clip.antiAlias : Clip.none,
            child: model.isImage
                ? ClipRRect(borderRadius: BorderRadius.circular(20.0), child: imageBox(context))
                : Text(
                    model.content,
                    style: TextStyle(
                      fontSize: 15.0,
                      color: ThemeColor.primary,
                    ),
                  ),
          ),
          Expanded(child: const SizedBox(width: 80.0)),
        ],
      );
    }
  }

  Widget imageBox(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).requestFocus(FocusNode());
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) {
              return MessageImageViewer(url: model.content);
            },
          ),
        );
      },
      child: Hero(
        tag: model.content,
        child: CachedNetworkImage(
          imageUrl: model.content,
          fit: BoxFit.fitHeight,
          filterQuality: FilterQuality.low,
          placeholder: (_, __) => Container(
            color: Colors.white,
            width: 120,
            height: 120,
            child: Center(
              child: const CircularProgressIndicator(
                valueColor: AlwaysStoppedAnimation(
                  ThemeColor.accent,
                ),
              ),
            ),
          ),
          errorWidget: (_, __, ___) => Container(
            color: Colors.white,
            width: 120,
            height: 120,
            child: Center(
              child: Icon(
                Icons.error,
                color: ThemeColor.secondary,
              ),
            ),
          ),
        ),
      ),
    );
  }

  BorderRadius getBorderRadius(bool fromYou) {
    if (model.boxPosition == MessageBoxPosition.none) {
      return BorderRadius.only(
        topLeft: Radius.circular(20.0),
        topRight: Radius.circular(20.0),
        bottomLeft: Radius.circular(20.0),
        bottomRight: Radius.circular(20.0),
      );
    }

    if (fromYou) {
      if (model.boxPosition == MessageBoxPosition.first) {
        return BorderRadius.only(
          topLeft: Radius.circular(20.0),
          topRight: Radius.circular(20.0),
          bottomLeft: Radius.circular(20.0),
          bottomRight: Radius.circular(5.0),
        );
      } else if (model.boxPosition == MessageBoxPosition.last) {
        return BorderRadius.only(
          topLeft: Radius.circular(20.0),
          topRight: Radius.circular(5.0),
          bottomLeft: Radius.circular(20.0),
          bottomRight: Radius.circular(20.0),
        );
      }
      return BorderRadius.only(
        topLeft: Radius.circular(20.0),
        topRight: Radius.circular(5.0),
        bottomLeft: Radius.circular(20.0),
        bottomRight: Radius.circular(5.0),
      );
    } else {
      if (model.boxPosition == MessageBoxPosition.first) {
        return BorderRadius.only(
          topLeft: Radius.circular(20.0),
          topRight: Radius.circular(20.0),
          bottomLeft: Radius.circular(5.0),
          bottomRight: Radius.circular(20.0),
        );
      } else if (model.boxPosition == MessageBoxPosition.last) {
        return BorderRadius.only(
          topLeft: Radius.circular(5.0),
          topRight: Radius.circular(20.0),
          bottomRight: Radius.circular(20.0),
          bottomLeft: Radius.circular(20.0),
        );
      }
      return BorderRadius.only(
        topLeft: Radius.circular(5.0),
        topRight: Radius.circular(20.0),
        bottomLeft: Radius.circular(5.0),
        bottomRight: Radius.circular(20.0),
      );
    }
  }
}
