import 'dart:io';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:clinick/blocs/messaging/chatbox/bloc.dart';
import 'package:clinick/blocs/messaging/chatbox/events.dart';
import 'package:clinick/blocs/messaging/chatbox/states.dart';
import 'package:clinick/config/app_config.dart';
import 'package:clinick/config/color.dart';
import 'package:clinick/database/app_firebase.dart';
import 'package:clinick/database/msg_firebase.dart';
import 'package:clinick/models/message_info_model.dart';
import 'package:clinick/models/message_model.dart';
import 'package:clinick/staff/pages/appointment_maker.dart';
import 'package:clinick/staff/pages/record_adder/blocs/bloc.dart';
import 'package:clinick/staff/pages/record_adder/view.dart';
import 'package:clinick/widgets/state_view_template.dart';
import 'package:clinick/widgets/toast.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:grouped_list/grouped_list.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:line_icons/line_icons.dart';

import 'message_tile_templates.dart';

class ChatBox extends StatefulWidget {
  const ChatBox({
    required this.infoModel,
    required this.peerImage,
    required this.peerToken,
    required this.showToolbar,
  });
  final MessageInfoModel infoModel;
  final String peerImage;
  final String peerToken;
  final bool showToolbar;

  @override
  _ChatBoxState createState() => _ChatBoxState();
}

class _ChatBoxState extends State<ChatBox> {
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();
  late final ScrollController scrollController;
  late final TextEditingController txtController;
  String input = "";
  bool isLoadingMore = false;

  @override
  void initState() {
    txtController = TextEditingController();
    scrollController = ScrollController();
    scrollController.addListener(scrollListener);

    BlocProvider.of<MessageBloc>(context).add(MessageEventRequest(
      convoId: widget.infoModel.id!,
      userIndex: widget.infoModel.userIndex,
    ));
    super.initState();
  }

  @override
  void dispose() {
    scrollController.removeListener(scrollListener);
    scrollController.dispose();
    txtController.dispose();
    super.dispose();
  }

  void scrollListener() {
    final currentScroll = scrollController.position.pixels;
    final maxScroll = scrollController.position.maxScrollExtent;
    final scrollThreshold = 20.0;

    if (currentScroll >= maxScroll - scrollThreshold && !isLoadingMore) {
      isLoadingMore = true;
      BlocProvider.of<MessageBloc>(context).loadMore(widget.infoModel.id!);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0.0,
        leading: const SizedBox(),
        leadingWidth: 0.0,
        elevation: 1.0,
        title: Row(
          children: [
            const SizedBox(width: 10.0),
            IconButton(
              icon: const Icon(
                LineIcons.arrowLeft,
                color: ThemeColor.primary,
              ),
              splashRadius: 24.0,
              padding: const EdgeInsets.all(8.0),
              onPressed: () => Navigator.of(context).pop(),
            ),
            const SizedBox(width: 5.0),
            Container(
              height: 40.0,
              width: 40.0,
              decoration: BoxDecoration(
                color: ThemeColor.foreground,
                shape: BoxShape.circle,
              ),
              clipBehavior: Clip.antiAlias,
              child: CachedNetworkImage(
                imageUrl: widget.peerImage,
                fit: BoxFit.fill,
                memCacheHeight: 120,
                memCacheWidth: 120,
                placeholder: (_, __) => const SizedBox(),
                errorWidget: (_, __, ___) => const SizedBox(),
              ),
            ),
            const SizedBox(width: 10.0),
            Expanded(
              child: Text(
                widget.infoModel.names[widget.infoModel.peerIndex],
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  fontSize: 16.0,
                  fontWeight: FontWeight.bold,
                  color: ThemeColor.primary,
                ),
              ),
            ),
            if (widget.showToolbar)
              IconButton(
                tooltip: 'Add Medical Records',
                onPressed: () => onAddMedicalRecord(
                  widget.infoModel.users[widget.infoModel.peerIndex],
                  widget.infoModel.names[widget.infoModel.peerIndex],
                ),
                splashRadius: 24.0,
                icon: Icon(LineIcons.medicalFile),
                color: ThemeColor.accent,
              ),
            if (widget.showToolbar)
              IconButton(
                tooltip: 'Add An Appointment',
                onPressed: () {
                  FocusScope.of(context).requestFocus(FocusNode());
                  Navigator.push(
                    context,
                    CupertinoPageRoute(
                      builder: (context) {
                        return AppointmentMaker(
                          userUid: widget.infoModel.users[widget.infoModel.peerIndex],
                          userName: widget.infoModel.names[widget.infoModel.peerIndex],
                        );
                      },
                    ),
                  );
                },
                splashRadius: 24.0,
                icon: Icon(LineIcons.calendarPlus),
                color: ThemeColor.accent,
              ),
            SizedBox(width: widget.showToolbar ? 10.0 : 25.0),
          ],
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: BlocBuilder<MessageBloc, MessageState>(
              builder: (context, state) {
                if (state is MessageStateSuccess) {
                  isLoadingMore = false;
                  if (state.messages.isNotEmpty) {
                    return GroupedListView<MessageModel, DateTime>(
                      padding: const EdgeInsets.all(10.0),
                      physics: const BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics()),
                      reverse: true,
                      controller: scrollController,
                      order: GroupedListOrder.DESC,
                      elements: state.messages,
                      groupBy: (element) => element.group,
                      itemComparator: (element1, element2) => element1.time.compareTo(element2.time),
                      groupHeaderBuilder: (element) {
                        late final String _headertitle;

                        if (element.group.difference(DateTime.now()).abs().inDays == 0) {
                          _headertitle = DateFormat('hh:mm a').format(element.group);
                        } else {
                          _headertitle = DateFormat('MMM dd, hh:mm a').format(element.group);
                        }

                        return Container(
                          width: double.maxFinite,
                          height: 25.0,
                          alignment: Alignment.center,
                          margin: const EdgeInsets.only(bottom: 10.0, top: 30.0),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 3.0),
                            child: Text(
                              _headertitle,
                              style: const TextStyle(
                                fontSize: 12.0,
                                color: ThemeColor.secondary,
                              ),
                            ),
                          ),
                        );
                      },
                      itemBuilder: (context, element) {
                        return MessageBox(
                          model: element,
                          userIndex: widget.infoModel.userIndex,
                          otherImageUrl: widget.peerImage,
                          convoId: widget.infoModel.id!,
                        );
                      },
                    );
                  }
                } else if (state is MessageStateInProgress) {
                  return const Center(
                    child: const CircularProgressIndicator(
                      valueColor: AlwaysStoppedAnimation(ThemeColor.accent),
                    ),
                  );
                } else if (state is MessageStateFailed) {
                  return const Center(
                    child: const StateView(
                      title: "Sorry for the trouble!",
                      message:
                          "We encountered an error while trying to fetch your conversation list. Please try again.",
                      assetPath: AppConfig.asset_emptyImage,
                    ),
                  );
                }

                return Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 40.0),
                  child: SingleChildScrollView(
                    physics: const BouncingScrollPhysics(parent: const AlwaysScrollableScrollPhysics()),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(height: 50.0),
                        Text(
                          'Say Hi!',
                          style: const TextStyle(
                            fontSize: 35.0,
                            color: ThemeColor.accent,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Text(
                          'Please be polite at all times. Thank you!',
                          style: const TextStyle(
                            fontSize: 17.0,
                            color: ThemeColor.secondary,
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
          SizedBox(
            width: double.maxFinite,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(7.0, 7.0, 7.0, 10.0),
              child: Row(
                children: [
                  const SizedBox(width: 15.0),
                  Flexible(
                    child: Container(
                      decoration: BoxDecoration(
                        color: Color.fromARGB(255, 245, 245, 245),
                        borderRadius: BorderRadius.circular(15.0),
                      ),
                      constraints: BoxConstraints(
                        maxHeight: 100.0,
                      ),
                      padding: const EdgeInsets.symmetric(horizontal: 10.0, vertical: 10.0),
                      child: TextField(
                        controller: txtController,
                        onSubmitted: sendMessage,
                        scrollPhysics: const BouncingScrollPhysics(),
                        decoration: InputDecoration.collapsed(hintText: "Send a Message"),
                        style: const TextStyle(
                          fontSize: 16,
                          color: ThemeColor.primary,
                        ),
                        maxLines: null,
                        cursorColor: ThemeColor.accent,
                      ),
                    ),
                  ),
                  const SizedBox(width: 5.0),
                  IconButton(
                    onPressed: () => sendImage(),
                    icon: Icon(LineIcons.image),
                    color: ThemeColor.accent,
                    iconSize: 24.0,
                    splashRadius: 24.0,
                  ),
                  IconButton(
                    onPressed: () => sendMessage(txtController.text),
                    icon: Icon(LineIcons.paperPlane),
                    color: ThemeColor.accent,
                    iconSize: 24.0,
                    splashRadius: 24.0,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  void sendImage() async {
    try {
      final ImagePicker picker = ImagePicker();
      final pickedFile = await picker.getImage(
        source: ImageSource.gallery,
        maxHeight: 2000,
        maxWidth: 1500,
      );

      if (pickedFile != null) {
        toastGeneral("Sending Image...");
        final File _file = File(pickedFile.path);

        String _ext = ".png";
        if (pickedFile.path.toLowerCase().contains('.jpg')) _ext = ".jpg";

        TaskSnapshot _snapshot =
            await AppFirebase.storage.ref().child('messages_imgs').child('${DateTime.now()}.$_ext').putFile(_file);

        if (_snapshot.state == TaskState.success) {
          final String _url = await _snapshot.ref.getDownloadURL();
          final String _name = widget.infoModel.names[widget.infoModel.userIndex];

          MsgFirebase.sendMessage(
            widget.infoModel.id!,
            widget.infoModel.userIndex,
            _name,
            _url,
            true,
            widget.peerToken,
          );
        } else {
          toastError("Unable to upload your image. Please try again.");
        }
      }
    } catch (ex) {
      toastError("Unable to upload your image. Please try again.");
    }
  }

  void sendMessage(String input) async {
    if (input.isEmpty) return;
    txtController.clear();

    final String _name = widget.infoModel.names[widget.infoModel.userIndex];
    await MsgFirebase.sendMessage(
      widget.infoModel.id!,
      widget.infoModel.userIndex,
      _name,
      input,
      false,
      widget.peerToken,
    );
  }

  void onAddMedicalRecord(String userid, String username) {
    FocusScope.of(context).requestFocus(FocusNode());
    if (userid.isEmpty) {
      toastError("Unable to get this patient's id. Please try to refresh the page or contact the administrator.");
      return;
    }
    Navigator.push(
      context,
      CupertinoPageRoute(
        builder: (context) {
          return BlocProvider(
            create: (_) => RecordAdderBloc(),
            child: RecordAdder(
              userId: userid,
              userName: username,
            ),
          );
        },
      ),
    );
  }
}
