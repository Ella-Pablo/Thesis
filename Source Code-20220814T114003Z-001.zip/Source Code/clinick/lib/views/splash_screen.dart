import 'package:clinick/config/color.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class PageSplashScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final double _screenWidth = MediaQuery.of(context).size.width;
    precacheImage(AssetImage('assets/images/logo_banner.png'), context);

    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle(
        statusBarBrightness: Brightness.dark,
        statusBarIconBrightness: Brightness.dark,
      ),
      child: Scaffold(
        body: SafeArea(
          child: Column(
            children: [
              const SizedBox(height: 70),
              Image.asset(
                'assets/images/logo_banner.png',
                fit: BoxFit.fill,
                width: _screenWidth * 0.65,
              ),
              const SizedBox(height: 50),
              const Spacer(),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SizedBox(
                    height: 24.0,
                    width: 24.0,
                    child: const CircularProgressIndicator(
                      valueColor: AlwaysStoppedAnimation(ThemeColor.accent),
                    ),
                  ),
                  const SizedBox(width: 20.0),
                  Text('Fetching your data...'),
                ],
              ),
              const SizedBox(height: 40.0),
              Container(
                height: 40.0,
                color: ThemeColor.accent,
                alignment: Alignment.center,
                child: Text(
                  'Copyright © CLinicK. All rights reserved.',
                  style: TextStyle(
                    fontSize: 12.0,
                    color: ThemeColor.buttonTextColor,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
