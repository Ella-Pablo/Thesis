import 'package:clinick/config/color.dart';
import 'package:flutter/material.dart';
import 'package:line_icons/line_icons.dart';
import 'package:pretty_qr_code/pretty_qr_code.dart';
import 'dart:convert';

class PageQRCode extends StatelessWidget {
  const PageQRCode({required this.qrData});

  final Map<String, String> qrData;

  @override
  Widget build(BuildContext context) {
    precacheImage(AssetImage('assets/images/logo_banner_filled.jpg'), context);

    return Scaffold(
      body: SafeArea(
        child: SizedBox.expand(
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 30.0),
            child: Column(
              children: [
                const SizedBox(height: 15.0),
                Align(
                  alignment: Alignment.topRight,
                  child: SizedBox(
                    width: 24.0,
                    height: 24.0,
                    child: IconButton(
                      icon: const Icon(
                        LineIcons.times,
                        color: ThemeColor.primary,
                      ),
                      splashRadius: 24.0,
                      padding: EdgeInsets.zero,
                      onPressed: () => Navigator.of(context).pop(),
                    ),
                  ),
                ),
                const SizedBox(height: 10.0),
                Image.asset(
                  'assets/images/logo_banner.png',
                  fit: BoxFit.fill,
                  width: 250,
                ),
                const SizedBox(height: 30.0),
                SizedBox(
                  width: 230.0,
                  child: Material(
                    elevation: 5.0,
                    borderRadius: BorderRadius.circular(12.0),
                    color: ThemeColor.background,
                    shadowColor: ThemeColor.shadow.withOpacity(0.35),
                    child: Padding(
                      padding: const EdgeInsets.all(15.0),
                      child: Center(
                        child: PrettyQr(
                          data: jsonEncode(qrData),
                          image: AssetImage('assets/images/logo_banner_filled.jpg'),
                          roundEdges: true,
                          size: 200.0,
                          typeNumber: 5,
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 50.0),
                Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    'Help Us Fight Covid-19',
                    style: TextStyle(
                      color: ThemeColor.accent,
                      fontSize: 15.0,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
                const SizedBox(height: 10.0),
                Text(
                  '         Use this QR-Code when entering or leaving the premises of our clinic. This will help us hasten and accurately track COVID-19 patients.',
                  textAlign: TextAlign.justify,
                  style: TextStyle(
                    color: ThemeColor.secondary,
                    fontSize: 15.0,
                  ),
                ),
                const SizedBox(height: 5.0),
                Text(
                  "         We will notify you if you've been exposed to people with COVID-19 through this application. We encourage you to regularly check your dashboard or homepage for updates.",
                  textAlign: TextAlign.justify,
                  style: TextStyle(
                    color: ThemeColor.secondary,
                    fontSize: 15.0,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
