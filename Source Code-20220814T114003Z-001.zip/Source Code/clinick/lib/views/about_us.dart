import 'package:clinick/config/color.dart';
import 'package:flutter/material.dart';
import 'package:line_icons/line_icons.dart';
import 'package:url_launcher/url_launcher.dart';

class PageAboutUs extends StatelessWidget {
  const PageAboutUs();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          padding: const EdgeInsets.all(15.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  IconButton(
                    icon: const Icon(
                      LineIcons.arrowLeft,
                      color: ThemeColor.primary,
                    ),
                    splashRadius: 24.0,
                    padding: const EdgeInsets.all(8.0),
                    onPressed: () => Navigator.of(context).pop(),
                  ),
                  const SizedBox(width: 15.0),
                  const Text(
                    'About Us',
                    style: const TextStyle(
                      fontSize: 17.0,
                      fontWeight: FontWeight.bold,
                      color: ThemeColor.primary,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10.0),
              Material(
                elevation: 5.0,
                borderRadius: BorderRadius.circular(8.0),
                color: ThemeColor.background,
                shadowColor: ThemeColor.shadow.withOpacity(0.35),
                clipBehavior: Clip.antiAlias,
                child: Image.asset(
                  'assets/images/about_cover.png',
                  fit: BoxFit.fill,
                  height: 200.0,
                  width: double.maxFinite,
                ),
              ),
              const SizedBox(height: 30.0),
              Material(
                elevation: 5.0,
                borderRadius: BorderRadius.circular(8.0),
                color: ThemeColor.background,
                shadowColor: ThemeColor.shadow.withOpacity(0.35),
                child: Padding(
                  padding: const EdgeInsets.all(15.0),
                  child: Column(
                    children: [
                      /*Image.asset(
                        'assets/images/logo_banner_clinic.png',
                        fit: BoxFit.contain,
                        width: 250,
                      ),*/
                      const Text(
                        "Reysie Ann Pablo Dental Clinic",
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          color: ThemeColor.accent,
                          fontWeight: FontWeight.bold,
                          fontSize: 18.0,
                        ),
                      ),
                      const SizedBox(height: 20.0),
                      const Text(
                        "       Our goal is to go above and beyond for our patients by providing great dental care while also developing trusting relationships with them. We love what we do, and we want our patients to know that they'll get the greatest dental care available.",
                        textAlign: TextAlign.justify,
                        style: const TextStyle(
                          color: ThemeColor.secondary,
                          fontSize: 16.0,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 30.0),
              Material(
                elevation: 5.0,
                borderRadius: BorderRadius.circular(8.0),
                color: ThemeColor.background,
                shadowColor: ThemeColor.shadow.withOpacity(0.35),
                child: Padding(
                  padding: const EdgeInsets.all(15.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          const Icon(
                            LineIcons.mapMarker,
                            color: ThemeColor.accent,
                          ),
                          const SizedBox(width: 5.0),
                          const Text(
                            'Location',
                            style: const TextStyle(
                              fontSize: 14.0,
                              color: ThemeColor.accent,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          const Spacer(),
                          GestureDetector(
                            child: Icon(
                              LineIcons.alternateExternalLink,
                              color: ThemeColor.accent,
                              size: 19.0,
                            ),
                            onTap: () =>
                                launch("https://goo.gl/maps/GDJXpNWftaoEvxYp7"),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10.0),
                      const Text(
                        '18 P. Gabriel St., Navotas, Metro Manila, 1485',
                        style: const TextStyle(color: ThemeColor.secondary),
                      ),
                      const SizedBox(height: 30.0),
                      Row(
                        children: [
                          const Icon(
                            LineIcons.phone,
                            color: ThemeColor.accent,
                          ),
                          const SizedBox(width: 5.0),
                          const Text(
                            'Contact Numbers',
                            style: const TextStyle(
                              fontSize: 14.0,
                              color: ThemeColor.accent,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10.0),
                      const Text(
                        'Mobile: (+63) 922 873 9744',
                        style: const TextStyle(color: ThemeColor.secondary),
                      ),
                      const Text(
                        'Tel: (02) 8703 7533',
                        style: const TextStyle(color: ThemeColor.secondary),
                      ),
                      const SizedBox(height: 30.0),
                      Row(
                        children: [
                          const Icon(
                            LineIcons.businessTime,
                            color: ThemeColor.accent,
                          ),
                          const SizedBox(width: 5.0),
                          const Text(
                            'Operating Hours',
                            style: const TextStyle(
                              fontSize: 14.0,
                              color: ThemeColor.accent,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10.0),
                      const Text(
                        'Wednesday, Friday, Sunday',
                        style: const TextStyle(color: ThemeColor.secondary),
                      ),
                      const Text(
                        'By Appointment Only',
                        style: const TextStyle(color: ThemeColor.secondary),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 20.0),
            ],
          ),
        ),
      ),
    );
  }
}
