import 'package:clinick/config/color.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:line_icons/line_icons.dart';

class PageInfoReader extends StatelessWidget {
  const PageInfoReader({required this.title, required this.message});

  final String title;
  final String message;

  @override
  Widget build(BuildContext context) {
    final double _screenWidth = MediaQuery.of(context).size.width;
    precacheImage(AssetImage('assets/images/logo_banner.png'), context);

    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle(
        statusBarBrightness: Brightness.dark,
        statusBarIconBrightness: Brightness.dark,
      ),
      child: Scaffold(
        body: SafeArea(
            child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(15.0, 0.0, 15.0, 15.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Align(
                alignment: Alignment.centerRight,
                child: IconButton(
                  icon: const Icon(LineIcons.times),
                  splashRadius: 24.0,
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                ),
              ),
              Center(
                child: Image.asset(
                  'assets/images/logo_banner.png',
                  fit: BoxFit.fill,
                  width: _screenWidth * 0.65,
                ),
              ),
              const SizedBox(height: 30),
              Center(
                child: Text(
                  title.toUpperCase(),
                  style: TextStyle(
                    fontSize: 20.0,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              const SizedBox(height: 30.0),
              Text(
                message,
                textAlign: TextAlign.justify,
                style: const TextStyle(
                  color: ThemeColor.secondary2,
                ),
              ),
              const SizedBox(height: 30.0),
            ],
          ),
        )),
      ),
    );
  }
}
