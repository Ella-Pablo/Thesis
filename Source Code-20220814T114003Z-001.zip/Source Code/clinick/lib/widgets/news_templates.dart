import 'package:cached_network_image/cached_network_image.dart';
import 'package:clinick/config/color.dart';
import 'package:clinick/models/news_model.dart';
import 'package:flutter/material.dart';
import 'package:line_icons/line_icons.dart';
import 'package:url_launcher/url_launcher.dart';

class NewsListItem extends StatelessWidget {
  const NewsListItem({required this.model});
  final NewsModel model;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 100,
      margin: const EdgeInsets.symmetric(vertical: 5.0),
      child: Material(
        elevation: 5.0,
        borderRadius: BorderRadius.circular(12.0),
        color: ThemeColor.background,
        shadowColor: ThemeColor.shadow.withOpacity(0.35),
        child: InkWell(
          borderRadius: BorderRadius.circular(12.0),
          onTap: () => launch(model.url),
          child: Padding(
            padding: const EdgeInsets.all(10.0),
            child: Row(
              children: [
                CachedNetworkImage(
                  imageUrl: model.image,
                  width: 100,
                  fit: BoxFit.fill,
                  filterQuality: FilterQuality.low,
                  memCacheWidth: 150,
                  maxWidthDiskCache: 150,
                  errorWidget: (_, __, ___) {
                    return Container(
                      color: ThemeColor.foreground,
                      width: 100.0,
                      child: Center(
                        child: const Icon(
                          LineIcons.exclamationTriangle,
                          color: ThemeColor.secondary,
                        ),
                      ),
                    );
                  },
                  placeholder: (_, __) => Container(color: ThemeColor.foreground, width: 100.0),
                ),
                const SizedBox(
                  width: 15.0,
                ),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        model.title,
                        maxLines: 4,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: ThemeColor.primary,
                          fontSize: 14.0,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class NewsListItemShimmer extends StatelessWidget {
  const NewsListItemShimmer();

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 100,
      margin: const EdgeInsets.symmetric(vertical: 5.0),
      child: Material(
        elevation: 12.0,
        borderRadius: BorderRadius.circular(12.0),
        color: ThemeColor.background,
        shadowColor: ThemeColor.shadow.withOpacity(0.35),
        child: Padding(
          padding: const EdgeInsets.all(10.0),
          child: Row(
            children: [
              Container(
                width: 100,
                color: ThemeColor.foreground,
              ),
              const SizedBox(width: 15.0),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      height: 15,
                      color: ThemeColor.foreground,
                    ),
                    const SizedBox(height: 3.0),
                    Container(
                      height: 15,
                      width: 100.0,
                      color: ThemeColor.foreground,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class NewsListFailure extends StatelessWidget {
  const NewsListFailure({required this.tryAgain});
  final Function tryAgain;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 460,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Image.asset(
            'assets/images/illustration_error.png',
            fit: BoxFit.fill,
            height: 150,
            width: 200,
          ),
          const SizedBox(height: 15.0),
          const Text(
            'Oops! Sorry for the trouble',
            style: const TextStyle(
              fontSize: 17.0,
              fontWeight: FontWeight.w500,
              color: ThemeColor.secondary2,
            ),
          ),
          const SizedBox(height: 5.0),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 30.0),
            child: const Text(
              'An unexpected error has occured while getting the data from the server. Please try to reload using the button below.',
              textAlign: TextAlign.justify,
              style: const TextStyle(
                fontSize: 13.0,
                color: ThemeColor.secondary,
              ),
            ),
          ),
          const SizedBox(height: 15.0),
          MaterialButton(
            onPressed: () => tryAgain(),
            child: const Text("Try Again"),
            textColor: ThemeColor.buttonTextColor,
            color: ThemeColor.accent,
          ),
        ],
      ),
    );
  }
}
