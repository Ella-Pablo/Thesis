import 'package:clinick/config/color.dart';
import 'package:flutter/material.dart';

class StateView extends StatelessWidget {
  const StateView({
    required this.title,
    required this.message,
    required this.assetPath,
    this.imageSize,
  });

  final String title;
  final String message;
  final String assetPath;
  final Size? imageSize;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Image.asset(
          assetPath,
          fit: BoxFit.fill,
          width: imageSize?.width ?? null,
          height: imageSize?.height ?? null,
        ),
        const SizedBox(height: 10.0),
        Text(
          title,
          style: const TextStyle(
            fontSize: 17.0,
            fontWeight: FontWeight.w600,
            color: ThemeColor.secondary2,
          ),
        ),
        const SizedBox(height: 5.0),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 30.0),
          child: Text(
            message,
            textAlign: TextAlign.center,
            style: const TextStyle(
              fontSize: 14,
              color: ThemeColor.secondary,
            ),
          ),
        ),
      ],
    );
  }
}
