import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';

/// Show a toast message with white background and default length to short.
void toastGeneral(String message, {bool clearPendingToast = false}) {
  if (clearPendingToast) Fluttertoast?.cancel();
  Fluttertoast.showToast(
    msg: message,
    gravity: ToastGravity.BOTTOM,
  );
}

/// Show a toast message with red background and default length to short.
void toastError(String message, {bool clearPendingToast = false}) {
  if (clearPendingToast) Fluttertoast?.cancel();
  Fluttertoast.showToast(
    msg: message,
    gravity: ToastGravity.BOTTOM,
    toastLength: Toast.LENGTH_SHORT,
    backgroundColor: Colors.red,
    textColor: Colors.white,
  );
}
