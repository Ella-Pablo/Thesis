import 'package:cached_network_image/cached_network_image.dart';
import 'package:clinick/blocs/messaging/chatbox/bloc.dart';
import 'package:clinick/config/app_config.dart';
import 'package:clinick/config/color.dart';
import 'package:clinick/database/app_firebase.dart';
import 'package:clinick/models/message_info_model.dart';
import 'package:clinick/views/chat_box/view.dart';
import 'package:clinick/widgets/toast.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class MessageInfoItem extends StatefulWidget {
  MessageInfoItem({required this.model, required this.showToolbar, this.checkIfStaffToStaff = false});
  final MessageInfoModel model;
  final bool showToolbar;
  final bool checkIfStaffToStaff;

  @override
  _MessageInfoItemState createState() => _MessageInfoItemState();
}

class _MessageInfoItemState extends State<MessageInfoItem> {
  String peerImageUrl = "";

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 15.0, vertical: 5.0),
      child: Material(
        elevation: 5.0,
        borderRadius: BorderRadius.circular(8.0),
        color: ThemeColor.background,
        shadowColor: ThemeColor.shadow.withOpacity(0.35),
        child: InkWell(
          onTap: () => onOpenConvo(context),
          borderRadius: BorderRadius.circular(8.0),
          child: Padding(
            padding: const EdgeInsets.all(10.0),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                FutureBuilder<String>(
                  initialData: "",
                  future: getProfileImage(widget.model.users[widget.model.peerIndex]),
                  builder: (_, snapshot) {
                    if (snapshot.hasData) {
                      if (snapshot.data!.isNotEmpty) {
                        return Container(
                          height: 55.0,
                          width: 55.0,
                          decoration: BoxDecoration(
                            color: ThemeColor.foreground,
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: ThemeColor.foreground,
                              width: 2.0,
                            ),
                            image: DecorationImage(
                              image: CachedNetworkImageProvider(
                                snapshot.data!,
                                maxHeight: 100,
                                maxWidth: 100,
                              ),
                              fit: BoxFit.fill,
                            ),
                          ),
                        );
                      }
                    }
                    return Container(
                      height: 55.0,
                      width: 55.0,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: ThemeColor.background2,
                        image: DecorationImage(
                          image: AssetImage(AppConfig.asset_noImage),
                          fit: BoxFit.cover,
                        ),
                      ),
                    );
                  },
                ),
                const SizedBox(width: 10.0),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const SizedBox(height: 5.0),
                      Text(
                        widget.model.names[widget.model.peerIndex],
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: ThemeColor.secondary2,
                          fontSize: 15.0,
                          fontWeight: !widget.model.lastIsSeen && widget.model.lastSender != widget.model.userIndex
                              ? FontWeight.bold
                              : FontWeight.normal,
                        ),
                      ),
                      const SizedBox(height: 3.0),
                      Text(
                        "${widget.model.lastSender == widget.model.userIndex ? 'You: ' : ''}${widget.model.lastContent}",
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontSize: 14.0,
                          color: ThemeColor.secondary,
                          fontWeight: !widget.model.lastIsSeen && widget.model.lastSender != widget.model.userIndex
                              ? FontWeight.bold
                              : FontWeight.normal,
                        ),
                      ),
                      const SizedBox(height: 3.0),
                      Align(
                        alignment: Alignment.centerRight,
                        child: Text(
                          widget.model.dateString,
                          style: const TextStyle(
                            fontSize: 12.0,
                            color: ThemeColor.accent,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void onOpenConvo(BuildContext context) async {
    toastGeneral("Opening Conversation...");

    String _peerToken = "";
    DocumentSnapshot _snapshot =
        await AppFirebase.firestore.collection('fcmtokens').doc(widget.model.users[widget.model.peerIndex]).get();

    if (_snapshot.exists) {
      _peerToken = _snapshot.data()?['token'] ?? "";
    }

    bool _showToolbar = widget.showToolbar;

    if (widget.checkIfStaffToStaff) {
      if (widget.model.staffToStaff) _showToolbar = false;
    }

    Navigator.push(
      context,
      CupertinoPageRoute(
        builder: (context) {
          return BlocProvider(
            create: (_) => MessageBloc(),
            child: ChatBox(
              infoModel: widget.model,
              peerImage: peerImageUrl,
              peerToken: _peerToken,
              showToolbar: _showToolbar,
            ),
          );
        },
      ),
    );
  }

  Future<String> getProfileImage(String id) async {
    if (id.isEmpty) return "";
    //try {
    peerImageUrl = await AppFirebase.storage
        .ref()
        .child('profile_imgs')
        .child(id + ".jpg")
        .getDownloadURL()
        .onError((error, stackTrace) => "");
    return peerImageUrl;
    //} catch (ex) {}
    //return "";
  }
}
