import 'package:clinick/config/color.dart';
import 'package:flutter/material.dart';

class OverlayLoader extends StatelessWidget {
  const OverlayLoader({
    required this.isBusy,
    required this.child,
    this.backgroundColor = Colors.white,
    this.color = ThemeColor.accent,
  });
  final bool isBusy;
  final Widget child;
  final Color color;
  final Color backgroundColor;

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Positioned.fill(
          child: child,
        ),
        if (isBusy)
          Positioned.fill(
            child: Container(
              color: backgroundColor.withOpacity(0.5),
              child: Center(
                child: CircularProgressIndicator(
                  valueColor: AlwaysStoppedAnimation(color),
                ),
              ),
            ),
          ),
      ],
    );
  }
}
