import 'package:clinick/config/color.dart';
import 'package:flutter/material.dart';

class InfoTextHeader extends StatelessWidget {
  const InfoTextHeader({required this.title, this.textColor = ThemeColor.secondary2, required this.icon});

  final String title;
  final Color textColor;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Icon(
          icon,
          color: ThemeColor.secondary2,
        ),
        const SizedBox(width: 5.0),
        Text(
          title,
          style: TextStyle(
            color: textColor,
            fontSize: 16.0,
            fontWeight: FontWeight.w500,
          ),
        ),
      ],
    );
  }
}

class InfoTextMessage extends StatelessWidget {
  const InfoTextMessage({required this.message});

  final String message;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 40.0),
      child: Text(
        message,
        maxLines: 3,
        overflow: TextOverflow.ellipsis,
        style: const TextStyle(
          fontSize: 16.0,
          color: ThemeColor.secondary,
        ),
      ),
    );
  }
}
