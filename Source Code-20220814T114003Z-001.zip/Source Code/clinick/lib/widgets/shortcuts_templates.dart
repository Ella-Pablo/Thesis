import 'package:clinick/config/color.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class ShortcutItem extends StatelessWidget {
  const ShortcutItem({
    required this.title,
    required this.icon,
    required this.builder,
    this.tooltip,
    this.isCupertino = true,
    this.isAccent = false,
  });
  final String title;
  final IconData icon;
  final Widget? builder;
  final bool isCupertino;
  final String? tooltip;
  final bool isAccent;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: isAccent ? ThemeColor.accent : ThemeColor.background,
      elevation: 8.0,
      shadowColor: ThemeColor.shadow.withOpacity(0.35),
      borderRadius: BorderRadius.circular(15.0),
      child: InkWell(
        borderRadius: BorderRadius.circular(15.0),
        onTap: () {
          if (builder != null) {
            Navigator.push(
              context,
              isCupertino ? CupertinoPageRoute(builder: (_) => builder!) : MaterialPageRoute(builder: (_) => builder!),
            );
          }
        },
        child: Tooltip(
          message: tooltip ?? title,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                icon,
                color: isAccent ? ThemeColor.background : ThemeColor.accent,
                size: 40.0,
              ),
              const SizedBox(height: 8.0),
              Text(
                title,
                style: TextStyle(
                  fontSize: 11.0,
                  color: isAccent ? ThemeColor.background2 : ThemeColor.secondary,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class ShortcutItemBig extends StatelessWidget {
  const ShortcutItemBig(
      {required this.title, required this.icon, required this.builder, this.tooltip, this.isCupertino = true});
  final String title;
  final IconData icon;
  final Widget? builder;
  final bool isCupertino;
  final String? tooltip;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: ThemeColor.background,
      elevation: 8.0,
      shadowColor: ThemeColor.shadow.withOpacity(0.35),
      borderRadius: BorderRadius.circular(15.0),
      child: InkWell(
        borderRadius: BorderRadius.circular(15.0),
        onTap: () {
          if (builder != null) {
            Navigator.push(
              context,
              isCupertino ? CupertinoPageRoute(builder: (_) => builder!) : MaterialPageRoute(builder: (_) => builder!),
            );
          }
        },
        child: Tooltip(
          message: tooltip ?? title,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                icon,
                color: ThemeColor.accent,
                size: 60.0,
              ),
              const SizedBox(height: 8.0),
              Text(
                title,
                style: const TextStyle(
                  fontSize: 13.0,
                  color: ThemeColor.secondary,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
