import 'package:clinick/config/color.dart';
import 'package:flutter/material.dart';
import 'package:line_icons/line_icons.dart';

class CriticalDialogTemplate extends StatelessWidget {
  final String message;
  const CriticalDialogTemplate({required this.message});

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text('Are you sure do you want to continue?'),
      titleTextStyle: const TextStyle(
        color: ThemeColor.secondary2,
        fontSize: 16.0,
        fontWeight: FontWeight.w500,
      ),
      titlePadding: const EdgeInsets.fromLTRB(20.0, 20.0, 20.0, 0.0),
      content: Text(message),
      contentTextStyle: const TextStyle(
        color: ThemeColor.secondary,
        fontSize: 14.0,
      ),
      contentPadding: const EdgeInsets.fromLTRB(20.0, 10.0, 20.0, 20.0),
      actions: [
        MaterialButton(
          onPressed: () => Navigator.of(context).pop(false),
          child: Text('Cancel'),
        ),
        MaterialButton(
          onPressed: () => Navigator.of(context).pop(true),
          child: Text('Proceed'),
          textColor: ThemeColor.accent,
        ),
      ],
    );
  }
}

class SearchPickerDialogTemplate extends StatelessWidget {
  const SearchPickerDialogTemplate();

  @override
  Widget build(BuildContext context) {
    return Dialog(
      child: Container(
        height: 150.0,
        padding: const EdgeInsets.all(15.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "What are you looking for?",
              style: const TextStyle(
                fontSize: 15.0,
                color: ThemeColor.primary,
              ),
            ),
            const SizedBox(height: 10.0),
            Expanded(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  IconButton(
                    tooltip: "Search a Patient",
                    icon: Icon(LineIcons.users),
                    iconSize: 75.0,
                    splashRadius: 50.0,
                    color: ThemeColor.accent,
                    onPressed: () => Navigator.of(context).pop(0),
                  ),
                  VerticalDivider(
                    width: 25.0,
                    indent: 20.0,
                    endIndent: 20.0,
                  ),
                  IconButton(
                    tooltip: "Find fellow Doctor",
                    icon: Icon(LineIcons.nurse),
                    iconSize: 75.0,
                    splashRadius: 50.0,
                    color: ThemeColor.accent,
                    onPressed: () => Navigator.of(context).pop(1),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class NotifyDialogTemplate extends StatelessWidget {
  final String message;
  const NotifyDialogTemplate({required this.message});

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text('Are you sure do you want to continue?'),
      titleTextStyle: const TextStyle(
        color: ThemeColor.secondary2,
        fontSize: 16.0,
        fontWeight: FontWeight.w500,
      ),
      titlePadding: const EdgeInsets.fromLTRB(20.0, 20.0, 20.0, 0.0),
      content: Text(message),
      contentTextStyle: const TextStyle(
        color: ThemeColor.secondary,
        fontSize: 14.0,
      ),
      contentPadding: const EdgeInsets.fromLTRB(20.0, 10.0, 20.0, 20.0),
      actions: [
        MaterialButton(
          onPressed: () => Navigator.of(context).pop(false),
          child: Text('Cancel'),
        ),
        MaterialButton(
          onPressed: () => Navigator.of(context).pop(true),
          child: Text('Proceed'),
          textColor: Colors.blueAccent,
        ),
      ],
    );
  }
}
