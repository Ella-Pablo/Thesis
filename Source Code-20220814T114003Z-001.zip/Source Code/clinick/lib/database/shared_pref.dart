import 'package:clinick/database/app_firebase.dart';
import 'package:clinick/models/message_info_model.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SharedPrefs {
  SharedPrefs._();
  static SharedPrefs _instance = SharedPrefs._();
  static SharedPrefs get instance => _instance;

  SharedPreferences? prefs;

  Future<void> getInstance() async {
    if (prefs == null) {
      prefs = await SharedPreferences.getInstance();
    }
  }

  Future<UserType> getUserType() async {
    await getInstance();

    UserType _userType = UserType.patient;
    if (prefs!.containsKey('usertype')) {
      _userType = UserType.values[prefs!.getInt("usertype") ?? 0];
    } else {
      saveUserType(_userType);
    }

    return _userType;
  }

  void saveUserType(UserType userType) {
    getInstance();
    prefs?.setInt('usertype', userType.index);
  }

  void saveUserId() {
    getInstance();
    prefs?.setString('userid', AppFirebase.uid());
  }

  Future<String> getUserId() async {
    await getInstance();

    return prefs?.getString('userid') ?? "";
  }

  void saveRememberPatient(List<String> list) {
    getInstance();
    prefs?.setStringList("rem_patients", list);
  }

  Future<List<String>> getRememberPatient() async {
    await getInstance();

    return prefs?.getStringList('rem_patients') ?? [];
  }

  void saveRememberStaff(List<String> list) {
    getInstance();
    prefs?.setStringList("rem_staff", list);
  }

  Future<List<String>> getRememberStaff() async {
    await getInstance();

    return prefs?.getStringList('rem_staff') ?? [];
  }

  void saveInitialRun() {
    getInstance();
    prefs?.setBool("initial_run", true);
  }

  Future<bool> getInitialRun() async {
    await getInstance();

    return prefs?.getBool('initial_run') ?? false;
  }

  void saveInitialSearch() {
    getInstance();
    prefs?.setBool("initial_search", true);
  }

  Future<bool> getInitialSearch() async {
    await getInstance();

    return prefs?.getBool('initial_search') ?? false;
  }
}
