import 'package:background_fetch/background_fetch.dart';
import 'package:clinick/models/appointment_model.dart';
import 'package:clinick/models/staff_data_model.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:clinick/config/app_config.dart';
import 'package:clinick/models/patient_data_model.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

import 'shared_pref.dart';

/// Static class that contains all the functions and methods related to the operation on firebase
class AppFirebase {
  // * Firebase Products Instances:
  static final auth = FirebaseAuth.instance;
  static final FirebaseFirestore firestore = FirebaseFirestore.instance;
  static final FirebaseStorage storage = FirebaseStorage.instance;
  static final FirebaseMessaging messaging = FirebaseMessaging.instance;

  static PatientDataModel? patientData;
  static StaffDataModel? staffData;

  static String? fcmToken;

  static String uid() => auth.currentUser!.uid;

  static Future<bool> getPatientData([bool forceSource = false]) async {
    final String uid = auth.currentUser!.uid;
    bool _isSuccess = false;
    if (forceSource) {
      await firestore.collection(AppConfig.table_patientData).doc(uid).get(GetOptions(source: Source.server)).then(
        (data) {
          if (data.exists) {
            if (data.data()!.entries.length <= 1) {
              _isSuccess = false;
            } else {
              patientData = PatientDataModel.fromMap(data.id, data.data()!);
              _isSuccess = true;
            }
          }
        },
      );
      SharedPrefs.instance.saveUserId();
      await updateToken();
    } else {
      try {
        await firestore.collection(AppConfig.table_patientData).doc(uid).get(GetOptions(source: Source.cache)).then(
          (data) {
            if (data.exists) {
              if (data.data()!.entries.length <= 1) {
                _isSuccess = false;
              } else {
                patientData = PatientDataModel.fromMap(data.id, data.data()!);
                _isSuccess = true;
              }
            }
          },
        );
        await Future.delayed(Duration(seconds: 1));
      } catch (ex) {
        await firestore.collection(AppConfig.table_patientData).doc(uid).get(GetOptions(source: Source.server)).then(
          (data) {
            if (data.exists) {
              if (data.data()!.entries.length <= 1) {
                _isSuccess = false;
              } else {
                patientData = PatientDataModel.fromMap(data.id, data.data()!);
                _isSuccess = true;
              }
            }
          },
        );
        SharedPrefs.instance.saveUserId();
        await updateToken();
      }
    }
    return _isSuccess;
  }

  static Future<bool> getStaffData([bool forceSource = false]) async {
    final String uid = auth.currentUser!.uid;
    bool _isSuccess = false;

    if (forceSource) {
      await firestore.collection(AppConfig.table_staffdata).doc(uid).get(GetOptions(source: Source.server)).then(
        (data) {
          if (data.exists) {
            if (data.data()!.entries.length <= 1) {
              _isSuccess = false;
            } else {
              staffData = StaffDataModel.fromMap(data.id, data.data()!);
              _isSuccess = true;
            }
          }
        },
      );
      SharedPrefs.instance.saveUserId();
      await updateToken();
    } else {
      try {
        await firestore.collection(AppConfig.table_staffdata).doc(uid).get(GetOptions(source: Source.cache)).then(
          (data) {
            if (data.exists) {
              if (data.data()!.entries.length <= 1) {
                _isSuccess = false;
              } else {
                staffData = StaffDataModel.fromMap(data.id, data.data()!);
                _isSuccess = true;
              }
            }
          },
        );
        await Future.delayed(Duration(seconds: 1));
      } catch (ex) {
        await firestore.collection(AppConfig.table_staffdata).doc(uid).get(GetOptions(source: Source.server)).then(
          (data) {
            if (data.exists) {
              if (data.data()!.entries.length <= 1) {
                _isSuccess = false;
              } else {
                staffData = StaffDataModel.fromMap(data.id, data.data()!);
                _isSuccess = true;
              }
            }
          },
        );
        SharedPrefs.instance.saveUserId();
        await updateToken();
      }
    }
    return _isSuccess;
  }

  static Future<void> addUpdatePatientData(PatientDataModel data) async {
    await firestore.collection(AppConfig.table_patientData).doc(auth.currentUser?.uid).set(
          data.toMap(),
          SetOptions(merge: true),
        );
  }

  static Future<void> addUpdatePatientDataByMap(Map<String, dynamic> data) async {
    await firestore.collection(AppConfig.table_patientData).doc(auth.currentUser?.uid).set(
          data,
          SetOptions(merge: true),
        );
  }

  static Future<void> addUpdateStaffData(StaffDataModel data) async {
    await firestore.collection(AppConfig.table_staffdata).doc(auth.currentUser?.uid).set(
          data.toMap(),
          SetOptions(merge: true),
        );
  }

  static Future<void> addUpdateStaffDataByMap(Map<String, dynamic> data) async {
    await firestore.collection(AppConfig.table_staffdata).doc(auth.currentUser?.uid).set(
          data,
          SetOptions(merge: true),
        );
  }

  static Future<void> signOut() async {
    await Future.delayed(Duration(seconds: 1));
    FlutterLocalNotificationsPlugin().cancelAll();

    await firestore.collection('fcmtokens').doc(uid()).delete();

    await firestore.terminate();
    await firestore.clearPersistence();

    await BackgroundFetch.stop();

    patientData = null;
    staffData = null;

    await auth.signOut(); // * Sign out from Firebase
  }

  static Future<void> moveAppointmentToDone(List<AppointmentModel> list) async {
    WriteBatch batch = firestore.batch();
    for (AppointmentModel model in list) {
      batch.set(firestore.collection('history').doc(model.id), model.toMapAsDone());
      batch.delete(firestore.collection('appointments').doc(model.id));
    }
    await batch.commit();
  }

  static Future<void> updateToken() async {
    fcmToken = await messaging
        .getToken(vapidKey: 'BKIUFgbOh791huBvbjWrE8BPqt6SIp2SEjgBBbuJrsziwv1vG13dBF7i4DPh5YXF3CLm-6y6gF7cu8S7O8Ww0_8')
        .onError((error, stackTrace) {});

    if (fcmToken != null) {
      if (fcmToken!.isNotEmpty) {
        await firestore.collection('fcmtokens').doc(uid()).set(
          {'token': fcmToken},
          SetOptions(
            merge: true,
          ),
        );
      }
    }
  }
}
