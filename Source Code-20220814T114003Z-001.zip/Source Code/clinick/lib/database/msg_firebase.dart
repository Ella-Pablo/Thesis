import 'dart:convert';

import 'package:clinick/database/app_firebase.dart';
import 'package:clinick/models/message_info_model.dart';
import 'package:clinick/models/message_model.dart';
import 'package:clinick/models/notification_channel_types.dart';
import 'package:clinick/widgets/toast.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:http/http.dart' as http;

class MsgFirebase {
  static Future<MessageInfoModel> checkCreateConvo(
    String peerId,
    String peerName,
    bool isDoctorToDoctor,
    bool fromPatient,
  ) async {
    QuerySnapshot _snapshot = await AppFirebase.firestore
        .collection('conversations')
        .where("users", isEqualTo: [AppFirebase.uid(), peerId]).get();

    if (_snapshot.docs.isNotEmpty) {
      return MessageInfoModel.fromSnapshot(_snapshot.docs.first.id, _snapshot.docs.first.data());
    }

    _snapshot = await AppFirebase.firestore
        .collection('conversations')
        .where("users", isEqualTo: [peerId, AppFirebase.uid()]).get();

    if (_snapshot.docs.isNotEmpty) {
      return MessageInfoModel.fromSnapshot(_snapshot.docs.first.id, _snapshot.docs.first.data());
    }

    final MessageInfoModel _infoModel = MessageInfoModel(
      users: [AppFirebase.uid(), peerId],
      names: [fromPatient ? AppFirebase.patientData!.fullName : AppFirebase.staffData!.fullName, peerName],
      lastContent: "",
      lastTimeSent: 0,
      lastSender: 0,
      lastIsSeen: true,
      staffToStaff: isDoctorToDoctor,
    );

    DocumentReference ref = await AppFirebase.firestore.collection('conversations').add(_infoModel.toMap());
    return MessageInfoModel.fromModel(ref.id, _infoModel);
  }

  static Future<void> sendMessage(
      String convoId, int userIndex, String userName, String input, bool isImage, String peerToken) async {
    try {
      final DateTime _now = DateTime.now();
      final MessageModel _newMessage = MessageModel(
        sender: userIndex,
        time: _now,
        content: input,
        isImage: isImage,
        seen: false,
        group: _now,
      );

      await AppFirebase.firestore
          .collection('conversations')
          .doc(convoId)
          .collection('messages')
          .add(_newMessage.toMap());

      await AppFirebase.firestore.collection('conversations').doc(convoId).update({
        'lastseen': false,
        'lastcontent': isImage ? "(Sent an image)" : input,
        'lastsender': userIndex,
        'lastsenttime': _now.millisecondsSinceEpoch,
      });

      if (peerToken.isNotEmpty) {
        final String _finalInput = input.length > 30 ? input.substring(0, 28) + '...' : input;
        await sendNotificationMessageToPeerUser(peerToken, _finalInput, isImage, userName);
      }
    } catch (ex) {
      toastError("Unable to send your message. Please try again.");
    }
  }

  static void updateMessageSeenStatus(String convoId, String messageId) async {
    try {
      await AppFirebase.firestore
          .collection('conversations')
          .doc(convoId)
          .collection('messages')
          .doc(messageId)
          .update({'seen': true});

      await AppFirebase.firestore.collection('conversations').doc(convoId).update({'lastseen': true});
    } catch (ex) {}
  }

  static Future<void> sendNotificationMessageToPeerUser(
    String peerToken,
    String content,
    bool isImage,
    String title,
  ) async {
    try {
      await http.post(
        Uri.parse('https://fcm.googleapis.com/fcm/send'),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
          'Authorization':
              'key=AAAAvj0KGb0:APA91bHeXw4ykW3TlZBTv0CMy-t6u9NeZw3AvaamLK2R0NXjeyFBCZDNAAnJwjJrOCZUiPR8hvQ6RTlxU5wCpfjfKXmVLAgW0yLe0gd49ejMbypNm93x6P9KYGPC8wVrSnkpPuahw2Bw',
        },
        body: jsonEncode(
          <String, dynamic>{
            'notification': <String, dynamic>{
              'body': isImage ? '(Sent an image)' : '$content',
              'title': '$title',
              "sound": "default",
              "tag": "message",
              "android_channel_id": "clinick_messages",
              'click_action': 'FLUTTER_NOTIFICATION_CLICK',
            },
            'data': <String, dynamic>{
              "notiftype": 1,
            },
            'to': peerToken,
          },
        ),
      );
    } catch (e) {
      //print(e);
    }
  }

  static Future<void> sendNotificationToUser(
    String token,
    String title,
    String content,
    NotifChannelTypes channelType,
  ) async {
    try {
      String _channel = "clinick_default";
      if (channelType == NotifChannelTypes.messages) {
        _channel = "clinick_messages";
      } else if (channelType == NotifChannelTypes.appointment) {
        _channel = "clinick_appointment";
      } else if (channelType == NotifChannelTypes.records) {
        _channel = "clinick_records";
      }

      await http.post(
        Uri.parse('https://fcm.googleapis.com/fcm/send'),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
          'Authorization':
              'key=AAAAvj0KGb0:APA91bHeXw4ykW3TlZBTv0CMy-t6u9NeZw3AvaamLK2R0NXjeyFBCZDNAAnJwjJrOCZUiPR8hvQ6RTlxU5wCpfjfKXmVLAgW0yLe0gd49ejMbypNm93x6P9KYGPC8wVrSnkpPuahw2Bw',
        },
        body: jsonEncode(
          <String, dynamic>{
            'notification': <String, dynamic>{
              'body': content,
              'title': '$title',
              "sound": "default",
              "android_channel_id": _channel,
              'click_action': 'FLUTTER_NOTIFICATION_CLICK',
            },
            'data': <String, dynamic>{
              "notiftype": channelType.index,
            },
            'to': token,
          },
        ),
      );
    } catch (e) {
      //print(e);
    }
  }
}
