import 'package:clinick/config/color.dart';
import 'package:flutter/material.dart';
import 'package:line_icons/line_icons.dart';

class PatientPageServices extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0.0,
        leading: const SizedBox(),
        leadingWidth: 0.0,
        elevation: 0.0,
        title: Row(
          children: [
            const SizedBox(width: 10.0),
            IconButton(
              icon: const Icon(
                LineIcons.arrowLeft,
                color: ThemeColor.primary,
              ),
              splashRadius: 24.0,
              padding: const EdgeInsets.all(8.0),
              onPressed: () => Navigator.of(context).pop(),
            ),
            const SizedBox(width: 15.0),
            const Text(
              'Services Offered',
              style: const TextStyle(
                fontSize: 17.0,
                fontWeight: FontWeight.bold,
                color: ThemeColor.primary,
              ),
            ),
          ],
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(15.0),
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          child: Column(
            children: [
              Material(
                elevation: 5.0,
                borderRadius: BorderRadius.circular(15.0),
                color: ThemeColor.background,
                shadowColor: ThemeColor.shadow.withOpacity(0.35),
                child: Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: Column(
                    children: [
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Icon(
                            LineIcons.infoCircle,
                            size: 20.0,
                            color: ThemeColor.accent,
                          ),
                          const SizedBox(width: 5.0),
                          Expanded(
                            child: Text(
                              'Please take note that the availability of these services may change from time to time. Please inquire with the corresponding specialists.',
                              textAlign: TextAlign.justify,
                              style: const TextStyle(
                                fontSize: 12.0,
                                color: ThemeColor.secondary,
                              ),
                            ),
                          ),
                          const SizedBox(width: 5.0),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 20.0),
              Image.asset(
                "assets/images/services_1.jpg",
                fit: BoxFit.fitWidth,
              ),
              const SizedBox(height: 10.0),
              Image.asset(
                "assets/images/services_2.jpg",
                fit: BoxFit.fitWidth,
              ),
              const SizedBox(height: 20.0),
            ],
          ),
        ),
      ),
    );
  }
}
