import 'package:equatable/equatable.dart';

abstract class ScheduleListEvent extends Equatable {
  const ScheduleListEvent();

  @override
  List<Object> get props => [];
}

class ScheduleListEventRequest extends ScheduleListEvent {
  const ScheduleListEventRequest({required this.date, required this.specialization, required this.isFilterOnly});
  final int date;
  final int specialization;
  final bool isFilterOnly;
}
