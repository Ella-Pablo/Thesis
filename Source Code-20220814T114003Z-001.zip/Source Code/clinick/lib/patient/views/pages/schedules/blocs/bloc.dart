import 'dart:async';
import 'package:clinick/database/app_firebase.dart';
import 'package:clinick/models/schedule_model.dart';
import 'package:clinick/patient/views/pages/schedules/blocs/events.dart';
import 'package:clinick/patient/views/pages/schedules/blocs/states.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class ScheduleListBloc extends Bloc<ScheduleListEvent, ScheduleListState> {
  ScheduleListBloc() : super(ScheduleListStateInProgress());

  List<ScheduleModel> schedules = [];

  @override
  Stream<ScheduleListState> mapEventToState(ScheduleListEvent event) async* {
    try {
      if (event is ScheduleListEventRequest) {
        yield ScheduleListStateInProgress();
        await Future.delayed(Duration(seconds: 1));

        if (!event.isFilterOnly) {
          QuerySnapshot _data = await AppFirebase.firestore.collection('schedules').get();

          if (_data.docs.isEmpty) {
            yield ScheduleListStateEmpty();
            return;
          }

          schedules.clear();
          schedules.addAll(_data.docs.map((e) => ScheduleModel.fromSnapshot(e.id, e.data())));
        }

        if (event.specialization == -1) {
          final List<ScheduleModel> _filteredList = [];
          _filteredList.addAll(schedules.where((e) => e.schedules[event.date].isNoSchedule == false).toList());

          yield ScheduleListStateSuccess(
            schedules: _filteredList,
          );
        } else {
          final List<ScheduleModel> _filteredList = [];
          final List<ScheduleModel> _filteredList1 = [];
          _filteredList.addAll(schedules.where((e) => e.specialization.index == event.specialization));
          _filteredList1.addAll(_filteredList.where((e) => e.schedules[event.date].isNoSchedule == false));

          yield ScheduleListStateSuccess(
            schedules: _filteredList1,
          );
        }
      }
    } catch (ex) {
      //print(ex);
      yield ScheduleListStateFailed();
    }
  }
}
