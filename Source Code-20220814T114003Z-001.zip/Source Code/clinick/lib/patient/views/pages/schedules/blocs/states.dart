import 'package:clinick/models/schedule_model.dart';
import 'package:equatable/equatable.dart';

abstract class ScheduleListState extends Equatable {
  const ScheduleListState();

  @override
  List<Object> get props => [];
}

class ScheduleListStateEmpty extends ScheduleListState {}

class ScheduleListStateInProgress extends ScheduleListState {}

class ScheduleListStateSuccess extends ScheduleListState {
  final List<ScheduleModel> schedules;
  const ScheduleListStateSuccess({required this.schedules});

  @override
  List<Object> get props => [schedules];
}

class ScheduleListStateFailed extends ScheduleListState {}
