import 'package:clinick/config/app_config.dart';
import 'package:clinick/config/color.dart';
import 'package:clinick/models/schedule_model.dart';
import 'package:clinick/models/staff_data_model.dart';
import 'package:clinick/patient/views/pages/schedules/blocs/bloc.dart';
import 'package:clinick/patient/views/pages/schedules/blocs/events.dart';
import 'package:clinick/patient/views/pages/schedules/blocs/states.dart';
import 'package:clinick/widgets/state_view_template.dart';
import 'package:expandable/expandable.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:line_icons/line_icons.dart';
import 'package:table_calendar/table_calendar.dart';

class PatientPageSchedules extends StatefulWidget {
  @override
  _PatientPageSchedulesState createState() => _PatientPageSchedulesState();
}

class _PatientPageSchedulesState extends State<PatientPageSchedules> {
  final List<int> specializationList = [];
  final ValueNotifier<int> selectedSpecialization = ValueNotifier(-1);
  final ValueNotifier<DateTime?> selectedDay = ValueNotifier(DateTime.now());
  int selectedWeekday = DateTime.now().weekday - 1;

  @override
  void initState() {
    specializationList.add(-1);
    specializationList.addAll(StaffSpecializationTypes.values.map((e) => e.index).toList());
    BlocProvider.of<ScheduleListBloc>(context).add(
      ScheduleListEventRequest(
        date: selectedWeekday,
        specialization: -1,
        isFilterOnly: false,
      ),
    );

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0.0,
        leading: const SizedBox(),
        leadingWidth: 0.0,
        elevation: 0.0,
        title: Row(
          children: [
            const SizedBox(width: 10.0),
            IconButton(
              icon: const Icon(
                LineIcons.arrowLeft,
                color: ThemeColor.primary,
              ),
              splashRadius: 24.0,
              padding: const EdgeInsets.all(8.0),
              onPressed: () => Navigator.of(context).pop(),
            ),
            const SizedBox(width: 15.0),
            const Text(
              'Medical Staff Schedule',
              style: const TextStyle(
                fontSize: 17.0,
                fontWeight: FontWeight.bold,
                color: ThemeColor.primary,
              ),
            ),
          ],
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 15.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ExpandablePanel(
              header: Padding(
                padding: const EdgeInsets.fromLTRB(8.0, 10.0, 8.0, 8.0),
                child: Row(
                  children: [
                    Icon(
                      LineIcons.filter,
                      size: 20.0,
                      color: ThemeColor.accent,
                    ),
                    const SizedBox(width: 10.0),
                    Text(
                      "Filter & Options",
                      style: const TextStyle(
                        color: ThemeColor.primary,
                        fontSize: 16.0,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
              collapsed: const SizedBox(),
              expanded: Column(
                children: [
                  ValueListenableBuilder<DateTime?>(
                    valueListenable: selectedDay,
                    builder: (_, value, __) {
                      return TableCalendar(
                        focusedDay: value ?? DateTime.now(),
                        firstDay: DateTime.now(),
                        lastDay: DateTime(DateTime.now().year, DateTime.now().month, DateTime.now().day + 7),
                        startingDayOfWeek: StartingDayOfWeek.values[DateTime.now().weekday - 1],
                        pageJumpingEnabled: false,
                        availableGestures: AvailableGestures.none,
                        headerStyle: HeaderStyle(
                          titleCentered: true,
                          titleTextStyle: const TextStyle(fontSize: 15.0),
                          formatButtonVisible: false,
                          leftChevronVisible: false,
                          rightChevronVisible: false,
                        ),
                        calendarFormat: CalendarFormat.week,
                        calendarStyle: CalendarStyle(
                          todayDecoration: BoxDecoration(
                            color: ThemeColor.accent.withOpacity(0.5),
                            shape: BoxShape.circle,
                          ),
                          selectedDecoration: BoxDecoration(
                            color: ThemeColor.accent,
                            shape: BoxShape.circle,
                          ),
                          selectedTextStyle: const TextStyle(color: ThemeColor.buttonTextColor),
                        ),
                        selectedDayPredicate: (day) {
                          return isSameDay(value, day);
                        },
                        onDaySelected: (iSelectedDay, _) {
                          selectedDay.value = iSelectedDay;
                          onDateChanged(iSelectedDay.weekday - 1);
                        },
                      );
                    },
                  ),
                  const SizedBox(height: 10.0),
                  Text(
                    "Filter by Specialization",
                    style: const TextStyle(
                      fontSize: 14.0,
                      fontWeight: FontWeight.w500,
                      color: ThemeColor.primary,
                    ),
                  ),
                  const SizedBox(height: 5.0),
                  SizedBox(
                    height: 45.0,
                    child: ValueListenableBuilder<int>(
                      valueListenable: selectedSpecialization,
                      builder: (_, value, __) {
                        return ListView.separated(
                          physics: const BouncingScrollPhysics(),
                          scrollDirection: Axis.horizontal,
                          itemCount: specializationList.length,
                          separatorBuilder: (context, index) {
                            return const SizedBox(width: 5.0);
                          },
                          itemBuilder: (context, index) {
                            if (specializationList[index] == -1) {
                              return FilterChip(
                                label: Text('All'),
                                onSelected: (_) => onFilterSelected(specializationList[index]),
                                pressElevation: 0.0,
                                backgroundColor:
                                    value == specializationList[index] ? ThemeColor.accent : ThemeColor.foreground,
                                labelStyle: TextStyle(
                                  fontSize: 11.0,
                                  color: value == specializationList[index]
                                      ? ThemeColor.buttonTextColor
                                      : ThemeColor.primary,
                                ),
                                showCheckmark: false,
                              );
                            }
                            return FilterChip(
                              label: Text(StaffSpecializationTypes.values[specializationList[index]].asString),
                              onSelected: (_) => onFilterSelected(specializationList[index]),
                              pressElevation: 0.0,
                              backgroundColor:
                                  value == specializationList[index] ? ThemeColor.accent : ThemeColor.foreground,
                              labelStyle: TextStyle(
                                fontSize: 11.0,
                                color: value == specializationList[index]
                                    ? ThemeColor.buttonTextColor
                                    : ThemeColor.primary,
                              ),
                              showCheckmark: false,
                            );
                          },
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20.0),
            Material(
              elevation: 5.0,
              borderRadius: BorderRadius.circular(15.0),
              color: ThemeColor.background,
              shadowColor: ThemeColor.shadow.withOpacity(0.35),
              child: Padding(
                padding: const EdgeInsets.fromLTRB(10.0, 15.0, 15.0, 15.0),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Icon(
                      LineIcons.infoCircle,
                      size: 20.0,
                      color: ThemeColor.accent,
                    ),
                    const SizedBox(width: 5.0),
                    const Expanded(
                      child: const Text(
                        'Schedules of doctors and technicians can change without prior notice. Please click the name of the doctor or technician and message them for confirmation of schedule.',
                        textAlign: TextAlign.justify,
                        style: const TextStyle(
                          fontSize: 12.0,
                          color: ThemeColor.secondary,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20.0),
            Expanded(
              child: BlocBuilder<ScheduleListBloc, ScheduleListState>(
                builder: (context, state) {
                  if (state is ScheduleListStateSuccess) {
                    if (state.schedules.isEmpty) {
                      final double w = MediaQuery.of(context).size.width;
                      return SingleChildScrollView(
                        physics: const BouncingScrollPhysics(parent: const AlwaysScrollableScrollPhysics()),
                        child: Column(
                          children: [
                            StateView(
                              title: 'Nothing to see here!',
                              message:
                                  "It seems that we don't have anyone yet to accomodate your needs. Please try again later.",
                              assetPath: AppConfig.asset_emptyImage,
                              imageSize: Size(w * 0.55, w * 0.45),
                            ),
                          ],
                        ),
                      );
                    }

                    return ListView.builder(
                      itemCount: state.schedules.length,
                      physics: const BouncingScrollPhysics(parent: const AlwaysScrollableScrollPhysics()),
                      itemBuilder: (context, index) {
                        final ScheduleModel _model = state.schedules[index];

                        return Padding(
                          padding: const EdgeInsets.symmetric(vertical: 5.0),
                          child: Material(
                            elevation: 5.0,
                            borderRadius: BorderRadius.circular(8.0),
                            color: ThemeColor.background,
                            shadowColor: ThemeColor.shadow.withOpacity(0.35),
                            child: Padding(
                              padding: const EdgeInsets.all(15.0),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    _model.staffName,
                                    style: const TextStyle(
                                      fontSize: 15.0,
                                      color: ThemeColor.primary,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                  const SizedBox(height: 3.0),
                                  Row(
                                    children: [
                                      Text(
                                        _model.specialization.asString,
                                        style: const TextStyle(
                                          fontSize: 14.0,
                                          color: ThemeColor.secondary,
                                        ),
                                      ),
                                      Expanded(
                                        child: Text(
                                          "${_model.schedules[selectedWeekday].start!.format(context)} to ${_model.schedules[selectedWeekday].end!.format(context)}",
                                          textAlign: TextAlign.right,
                                          style: const TextStyle(
                                            fontSize: 12.0,
                                            color: ThemeColor.accent,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ),
                        );
                      },
                    );
                  } else if (state is ScheduleListStateFailed) {
                    final double w = MediaQuery.of(context).size.width;
                    return SingleChildScrollView(
                      physics: const BouncingScrollPhysics(parent: const AlwaysScrollableScrollPhysics()),
                      child: Column(
                        children: [
                          StateView(
                            title: 'Sorry for the trouble!',
                            message:
                                "We encountered an error while trying to fetch our medical staff's schedules. Please try again.",
                            assetPath: AppConfig.asset_failedImage,
                            imageSize: Size(w * 0.55, w * 0.45),
                          )
                        ],
                      ),
                    );
                  } else if (state is ScheduleListStateEmpty) {
                    final double w = MediaQuery.of(context).size.width;
                    return SingleChildScrollView(
                      physics: const BouncingScrollPhysics(parent: const AlwaysScrollableScrollPhysics()),
                      child: Column(
                        children: [
                          StateView(
                            title: 'Nothing to see here!',
                            message: "It seems that we don't have anything to show you yet. Please try again later.",
                            assetPath: AppConfig.asset_emptyImage,
                            imageSize: Size(w * 0.55, w * 0.45),
                          )
                        ],
                      ),
                    );
                  } else if (state is ScheduleListStateInProgress) {
                    return const Center(
                      child: const CircularProgressIndicator(
                        valueColor: AlwaysStoppedAnimation(
                          ThemeColor.accent,
                        ),
                      ),
                    );
                  }
                  return const SizedBox();
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  void onFilterSelected(int index) {
    selectedSpecialization.value = index;
    BlocProvider.of<ScheduleListBloc>(context).add(
      ScheduleListEventRequest(
        date: selectedWeekday,
        specialization: index,
        isFilterOnly: true,
      ),
    );
  }

  void onDateChanged(int day) {
    selectedWeekday = day;
    BlocProvider.of<ScheduleListBloc>(context).add(
      ScheduleListEventRequest(
        date: day,
        specialization: selectedSpecialization.value,
        isFilterOnly: true,
      ),
    );
  }
}
