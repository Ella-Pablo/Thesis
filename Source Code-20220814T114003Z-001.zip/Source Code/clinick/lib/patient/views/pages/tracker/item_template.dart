import 'package:clinick/config/color.dart';
import 'package:clinick/models/tracker_model.dart';
import 'package:flutter/material.dart';

class ItemTrackerTemplate extends StatelessWidget {
  const ItemTrackerTemplate({required this.model});
  final TrackerModel model;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5.0),
      child: Material(
        elevation: 5.0,
        borderRadius: BorderRadius.circular(8.0),
        color: ThemeColor.background,
        shadowColor: ThemeColor.shadow.withOpacity(0.35),
        child: Padding(
          padding: const EdgeInsets.all(15.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(
                      model.name ?? "Unnamed Medication",
                      style: const TextStyle(
                        fontSize: 15.0,
                        fontWeight: FontWeight.bold,
                        color: ThemeColor.accent,
                      ),
                    ),
                  ),
                  Text(
                    model.quantity ?? "",
                    style: const TextStyle(
                      fontSize: 13.0,
                      color: ThemeColor.accent,
                    ),
                  ),
                ],
              ),
              Text(
                "You take this for ${model.purpose}",
                style: const TextStyle(
                  fontSize: 14.0,
                  color: ThemeColor.secondary,
                ),
              ),
              const SizedBox(height: 5.0),
              Table(
                border: TableBorder.all(color: ThemeColor.primary, width: 1.0),
                children: [
                  TableRow(
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(5.0),
                        child: Text(
                          "Morning",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 13.0,
                            color: model.morning! ? ThemeColor.accent : ThemeColor.secondary,
                            fontWeight: model.morning! ? FontWeight.w600 : FontWeight.normal,
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(5.0),
                        child: Text(
                          "Afternoon",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 13.0,
                            color: model.afternoon! ? ThemeColor.accent : ThemeColor.secondary,
                            fontWeight: model.afternoon! ? FontWeight.w600 : FontWeight.normal,
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(5.0),
                        child: Text(
                          "Evening",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 13.0,
                            color: model.evening! ? ThemeColor.accent : ThemeColor.secondary,
                            fontWeight: model.evening! ? FontWeight.w600 : FontWeight.normal,
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(5.0),
                        child: Text(
                          "BedTime",
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 13.0,
                            color: model.bedtime! ? ThemeColor.accent : ThemeColor.secondary,
                            fontWeight: model.bedtime! ? FontWeight.w600 : FontWeight.normal,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 15.0),
              Row(
                children: [
                  const Spacer(),
                  Text(
                    model.dateString,
                    style: const TextStyle(
                      fontSize: 12.0,
                      color: ThemeColor.secondary,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
