import 'package:clinick/config/color.dart';
import 'package:clinick/database/app_firebase.dart';
import 'package:clinick/models/tracker_model.dart';
import 'package:clinick/repository/notifications.dart';
import 'package:clinick/widgets/toast.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:line_icons/line_icons.dart';

class PatientPageTrackerMaker extends StatefulWidget {
  @override
  _PatientPageTrackerMakerState createState() => _PatientPageTrackerMakerState();
}

class _PatientPageTrackerMakerState extends State<PatientPageTrackerMaker> {
  final ValueNotifier<List<bool>> selectedTime = ValueNotifier([false, false, false, false]);
  final ValueNotifier<bool> isBusy = ValueNotifier(false);
  late final TextEditingController startTextController;
  late final TextEditingController endTextController;
  DateTime selectedStartTime = DateTime.now();
  DateTime? selectedEndTime;
  String name = "";
  String purpose = "";
  String quantity = "";

  @override
  void initState() {
    startTextController = TextEditingController(
      text: DateFormat('MMMM dd, yyyy').format(selectedStartTime),
    );
    endTextController = TextEditingController();

    super.initState();
  }

  @override
  void dispose() {
    selectedTime.dispose();
    startTextController.dispose();
    endTextController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<bool>(
      valueListenable: isBusy,
      builder: (_, state, __) {
        return Stack(
          children: [
            Positioned.fill(
              child: Scaffold(
                appBar: AppBar(
                  titleSpacing: 0.0,
                  leading: const SizedBox(),
                  leadingWidth: 0.0,
                  elevation: 0.0,
                  title: Row(
                    children: [
                      const SizedBox(width: 10.0),
                      IconButton(
                        icon: const Icon(
                          LineIcons.arrowLeft,
                          color: ThemeColor.primary,
                        ),
                        splashRadius: 24.0,
                        padding: const EdgeInsets.all(8.0),
                        onPressed: () => Navigator.of(context).pop(),
                      ),
                      const SizedBox(width: 15.0),
                      const Text(
                        'Add a Medication',
                        style: const TextStyle(
                          fontSize: 17.0,
                          fontWeight: FontWeight.bold,
                          color: ThemeColor.primary,
                        ),
                      ),
                      const Spacer(),
                      IconButton(
                        tooltip: 'Add Medication to List',
                        icon: Icon(LineIcons.calendarPlus),
                        color: ThemeColor.accent,
                        splashRadius: 24.0,
                        onPressed: () => onSaveTracker(),
                      ),
                      const SizedBox(width: 5.0),
                    ],
                  ),
                ),
                body: SingleChildScrollView(
                  padding: const EdgeInsets.all(15.0),
                  physics: const BouncingScrollPhysics(),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'What medicine do you need to take?',
                        style: TextStyle(
                          color: ThemeColor.primary,
                        ),
                      ),
                      const SizedBox(height: 5.0),
                      // INPUT FIELD: First Name
                      SizedBox(
                        height: 45.0,
                        child: TextField(
                          decoration: InputDecoration(
                            fillColor: ThemeColor.background,
                            filled: true,
                            contentPadding: const EdgeInsets.symmetric(horizontal: 15.0, vertical: 10.0),
                            hintText: 'e.g. Aspirin, Biogesic',
                            hintStyle: TextStyle(
                              color: ThemeColor.inputHint,
                              fontSize: 14.0,
                            ),
                            enabledBorder: UnderlineInputBorder(
                              borderSide: BorderSide(
                                color: ThemeColor.secondary,
                                width: 1.0,
                              ),
                            ),
                            focusedBorder: UnderlineInputBorder(
                              borderSide: BorderSide(
                                color: ThemeColor.accent,
                                width: 1.0,
                              ),
                            ),
                          ),
                          style: const TextStyle(fontSize: 15.0),
                          keyboardType: TextInputType.text,
                          onChanged: (text) => name = text,
                        ),
                      ),

                      const SizedBox(height: 30.0),

                      Text(
                        'What is the dosage for this medicine?',
                        style: TextStyle(
                          color: ThemeColor.primary,
                        ),
                      ),
                      const SizedBox(height: 5.0),
                      // INPUT FIELD: First Name
                      SizedBox(
                        height: 45.0,
                        child: TextField(
                          decoration: InputDecoration(
                            fillColor: ThemeColor.background,
                            filled: true,
                            contentPadding: const EdgeInsets.symmetric(horizontal: 15.0, vertical: 10.0),
                            hintText: 'e.g. 55 mg, 1 tablet, 2 capsules',
                            hintStyle: TextStyle(
                              color: ThemeColor.inputHint,
                              fontSize: 14.0,
                            ),
                            enabledBorder: UnderlineInputBorder(
                              borderSide: BorderSide(
                                color: ThemeColor.secondary,
                                width: 1.0,
                              ),
                            ),
                            focusedBorder: UnderlineInputBorder(
                              borderSide: BorderSide(
                                color: ThemeColor.accent,
                                width: 1.0,
                              ),
                            ),
                          ),
                          style: const TextStyle(fontSize: 15.0),
                          keyboardType: TextInputType.text,
                          onChanged: (text) => quantity = text,
                        ),
                      ),

                      const SizedBox(height: 30.0),

                      Text(
                        'Why do you take this medicine?',
                        style: TextStyle(
                          color: ThemeColor.primary,
                        ),
                      ),
                      const SizedBox(height: 5.0),
                      // INPUT FIELD: First Name
                      SizedBox(
                        height: 45.0,
                        child: TextField(
                          decoration: InputDecoration(
                            fillColor: ThemeColor.background,
                            filled: true,
                            contentPadding: const EdgeInsets.symmetric(horizontal: 15.0, vertical: 10.0),
                            hintText: 'e.g. heart, asthma',
                            hintStyle: TextStyle(
                              color: ThemeColor.inputHint,
                              fontSize: 14.0,
                            ),
                            enabledBorder: UnderlineInputBorder(
                              borderSide: BorderSide(
                                color: ThemeColor.secondary,
                                width: 1.0,
                              ),
                            ),
                            focusedBorder: UnderlineInputBorder(
                              borderSide: BorderSide(
                                color: ThemeColor.accent,
                                width: 1.0,
                              ),
                            ),
                          ),
                          style: const TextStyle(fontSize: 15.0),
                          keyboardType: TextInputType.text,
                          onChanged: (text) => purpose = text,
                        ),
                      ),

                      const SizedBox(height: 30.0),

                      Text(
                        'How frequent do you need to take this medicine? Kindly check the box that applies.',
                        style: TextStyle(
                          color: ThemeColor.primary,
                        ),
                      ),
                      const SizedBox(height: 15.0),
                      SizedBox(
                        width: double.maxFinite,
                        height: 115.0,
                        child: ValueListenableBuilder<List<bool>>(
                          valueListenable: selectedTime,
                          builder: (_, value, __) {
                            return Table(
                              border: TableBorder.all(
                                width: 1.0,
                                color: ThemeColor.secondary2,
                              ),
                              children: [
                                TableRow(
                                  children: [
                                    Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: Text(
                                        'Morning (8:00 AM)',
                                        textAlign: TextAlign.center,
                                        style: const TextStyle(fontWeight: FontWeight.w600),
                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: Text(
                                        'Afternoon (1:00 PM)',
                                        textAlign: TextAlign.center,
                                        style: const TextStyle(fontWeight: FontWeight.w600),
                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: Text(
                                        'Evening  (6:00 PM)',
                                        textAlign: TextAlign.center,
                                        style: const TextStyle(fontWeight: FontWeight.w600),
                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: Text(
                                        'BedTime (9:00 PM)',
                                        textAlign: TextAlign.center,
                                        style: const TextStyle(fontWeight: FontWeight.w600),
                                      ),
                                    ),
                                  ],
                                ),
                                TableRow(
                                  children: [
                                    Center(
                                      child: Checkbox(
                                        value: selectedTime.value[0],
                                        onChanged: (newValue) {
                                          selectedTime.value = [
                                            newValue ?? false,
                                            selectedTime.value[1],
                                            selectedTime.value[2],
                                            selectedTime.value[3],
                                          ];
                                        },
                                        activeColor: ThemeColor.accent,
                                      ),
                                    ),
                                    Center(
                                      child: Checkbox(
                                        value: selectedTime.value[1],
                                        onChanged: (newValue) {
                                          selectedTime.value = [
                                            selectedTime.value[0],
                                            newValue ?? false,
                                            selectedTime.value[2],
                                            selectedTime.value[3],
                                          ];
                                        },
                                        activeColor: ThemeColor.accent,
                                      ),
                                    ),
                                    Center(
                                      child: Checkbox(
                                        value: selectedTime.value[2],
                                        onChanged: (newValue) {
                                          selectedTime.value = [
                                            selectedTime.value[0],
                                            selectedTime.value[1],
                                            newValue ?? false,
                                            selectedTime.value[3],
                                          ];
                                        },
                                        activeColor: ThemeColor.accent,
                                      ),
                                    ),
                                    Center(
                                      child: Checkbox(
                                        value: selectedTime.value[3],
                                        onChanged: (newValue) {
                                          selectedTime.value = [
                                            selectedTime.value[0],
                                            selectedTime.value[1],
                                            selectedTime.value[2],
                                            newValue ?? false,
                                          ];
                                        },
                                        activeColor: ThemeColor.accent,
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            );
                          },
                        ),
                      ),

                      const SizedBox(height: 10.0),

                      Text(
                        'When do you start to take this medicine?',
                        style: TextStyle(
                          color: ThemeColor.primary,
                        ),
                      ),
                      const SizedBox(height: 5.0),
                      // INPUT FIELD: Start Time

                      SizedBox(
                          height: 45.0,
                          child: TextField(
                            decoration: InputDecoration(
                              fillColor: ThemeColor.background,
                              filled: true,
                              contentPadding: const EdgeInsets.symmetric(horizontal: 15.0, vertical: 10.0),
                              enabledBorder: UnderlineInputBorder(
                                borderSide: BorderSide(
                                  color: ThemeColor.secondary,
                                  width: 1.0,
                                ),
                              ),
                              focusedBorder: UnderlineInputBorder(
                                borderSide: BorderSide(
                                  color: ThemeColor.accent,
                                  width: 1.0,
                                ),
                              ),
                              suffixIcon: Padding(
                                padding: const EdgeInsets.only(bottom: 1.0),
                                child: Material(
                                  color: ThemeColor.background,
                                  child: IconButton(
                                    icon: Icon(LineIcons.calendar),
                                    color: ThemeColor.accent,
                                    splashRadius: 24.0,
                                    onPressed: () => onStartTimePicked(),
                                  ),
                                ),
                              ),
                            ),
                            controller: startTextController,
                            style: const TextStyle(fontSize: 15.0),
                            readOnly: true,
                          )),

                      const SizedBox(height: 30.0),

                      Text(
                        'If this is a maintenance medicine, kindly disregard the field below (leave the field empty).',
                        style: TextStyle(
                          color: ThemeColor.primary,
                        ),
                      ),
                      const SizedBox(height: 5.0),
                      // INPUT FIELD: End Time
                      SizedBox(
                        height: 45.0,
                        child: TextField(
                          decoration: InputDecoration(
                            fillColor: ThemeColor.background,
                            filled: true,
                            contentPadding: const EdgeInsets.symmetric(horizontal: 15.0, vertical: 10.0),
                            enabledBorder: UnderlineInputBorder(
                              borderSide: BorderSide(
                                color: ThemeColor.secondary,
                                width: 1.0,
                              ),
                            ),
                            focusedBorder: UnderlineInputBorder(
                              borderSide: BorderSide(
                                color: ThemeColor.accent,
                                width: 1.0,
                              ),
                            ),
                            suffixIcon: Padding(
                              padding: const EdgeInsets.only(bottom: 1.0),
                              child: Material(
                                color: ThemeColor.background,
                                child: IconButton(
                                  icon: Icon(LineIcons.calendar),
                                  color: ThemeColor.accent,
                                  splashRadius: 24.0,
                                  onPressed: () => onEndTimePicked(),
                                ),
                              ),
                            ),
                          ),
                          controller: endTextController,
                          style: const TextStyle(fontSize: 15.0),
                          readOnly: true,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            if (state)
              Positioned.fill(
                child: Container(
                  color: Colors.white.withOpacity(0.5),
                  alignment: Alignment.center,
                  child: const CircularProgressIndicator(
                    valueColor: AlwaysStoppedAnimation(
                      ThemeColor.accent,
                    ),
                  ),
                ),
              ),
          ],
        );
      },
    );
  }

  void onStartTimePicked() async {
    final _pickedDate = await showDatePicker(
      context: context,
      initialDate: selectedStartTime,
      firstDate: DateTime(DateTime.now().year, DateTime.now().month),
      lastDate: DateTime(2050),
      builder: (BuildContext context, Widget? child) {
        return Theme(
          data: ThemeData.light().copyWith(
            primaryColor: ThemeColor.accent,
            accentColor: ThemeColor.accent,
            colorScheme: ColorScheme.light(
              primary: ThemeColor.accent,
            ),
            buttonTheme: ButtonThemeData(
              textTheme: ButtonTextTheme.primary,
            ),
          ),
          child: child!,
        );
      },
    );
    if (_pickedDate != null) {
      selectedStartTime = _pickedDate;
      startTextController.text = DateFormat('MMMM dd, yyyy').format(selectedStartTime);
    }
  }

  void onEndTimePicked() async {
    final _pickedDate = await showDatePicker(
      context: context,
      initialDate: DateTime(DateTime.now().year, DateTime.now().month, DateTime.now().day + 1),
      firstDate: DateTime(DateTime.now().year, DateTime.now().month, DateTime.now().day + 1),
      lastDate: DateTime(2050),
      builder: (BuildContext context, Widget? child) {
        return Theme(
          data: ThemeData.light().copyWith(
            primaryColor: ThemeColor.accent,
            accentColor: ThemeColor.accent,
            colorScheme: ColorScheme.light(
              primary: ThemeColor.accent,
            ),
            buttonTheme: ButtonThemeData(
              textTheme: ButtonTextTheme.primary,
            ),
          ),
          child: child!,
        );
      },
    );
    if (_pickedDate != null) {
      selectedEndTime = _pickedDate;
      endTextController.text = DateFormat('MMMM dd, yyyy').format(selectedEndTime!);
    }
  }

  void onSaveTracker() async {
    isBusy.value = true;
    await Future.delayed(Duration(seconds: 1));

    bool _hasError = false;

    if (name.isEmpty || purpose.isEmpty || quantity.isEmpty) {
      _hasError = true;
      toastError("Please fill up all the fields above.");
    } else if (selectedTime.value.contains(true) == false) {
      _hasError = true;
      toastError("Please select at least one item in the time table.");
    }

    if (_hasError) {
      await Future.delayed(Duration(seconds: 1));
      return;
    }

    try {
      final TrackerModel _model = TrackerModel(
        userUid: AppFirebase.uid(),
        name: name,
        purpose: purpose,
        quantity: quantity,
        start: selectedStartTime,
        end: selectedEndTime,
        morning: selectedTime.value[0],
        afternoon: selectedTime.value[1],
        evening: selectedTime.value[2],
        bedtime: selectedTime.value[3],
      );

      await AppFirebase.firestore.collection('trackers').add(_model.toMap());
      await LocalNotifs.registerTodayMedicationTracker();

      toastGeneral("Successfully added your medication.");
      await Future.delayed(Duration(seconds: 1));
      Navigator.of(context).pop();
    } catch (ex) {
      toastError("Unexpected error has occured while saving your changes. Please try again");
    }
    isBusy.value = false;
  }
}
