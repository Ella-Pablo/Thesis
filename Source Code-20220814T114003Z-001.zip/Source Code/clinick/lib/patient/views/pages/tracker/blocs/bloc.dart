import 'dart:async';

import 'package:clinick/database/app_firebase.dart';
import 'package:clinick/models/tracker_model.dart';
import 'package:clinick/patient/views/pages/tracker/blocs/events.dart';
import 'package:clinick/patient/views/pages/tracker/blocs/states.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class PatientTrackerBloc extends Bloc<PatientTrackerEvent, PatientTrackerState> {
  PatientTrackerBloc() : super(PatientTrackerStateInProgress());

  StreamSubscription? subscription;
  List<TrackerModel> trackers = [];
  bool refresher = true;

  @override
  Stream<PatientTrackerState> mapEventToState(PatientTrackerEvent event) async* {
    if (event is PatientTrackerEventRequest) {
      yield PatientTrackerStateInProgress();

      subscription?.cancel();
      subscription =
          AppFirebase.firestore.collection('trackers').where('userid', isEqualTo: AppFirebase.uid()).snapshots().listen(
        (dataEvent) {
          if (state is PatientTrackerStateEmpty) emit(PatientTrackerStateInProgress());

          try {
            if (dataEvent.docs.isEmpty) {
              emit(PatientTrackerStateEmpty());
              return;
            }

            trackers.clear();
            trackers.addAll(dataEvent.docs.map((e) => TrackerModel.fromSnapshot(e.id, e.data())));

            refresher = !refresher;

            emit(PatientTrackerStateSuccess(
              trackers: trackers,
              refresher: refresher,
            ));
          } catch (ex) {
            //print(ex);
            emit(PatientTrackerStateFailed());
          }
        },
      );
    }
  }

  @override
  Future<void> close() {
    subscription?.cancel();
    return super.close();
  }
}
