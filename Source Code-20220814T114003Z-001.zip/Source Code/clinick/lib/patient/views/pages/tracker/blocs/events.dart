import 'package:equatable/equatable.dart';

abstract class PatientTrackerEvent extends Equatable {
  const PatientTrackerEvent();

  @override
  List<Object> get props => [];
}

class PatientTrackerEventRequest extends PatientTrackerEvent {}
