import 'package:clinick/config/app_config.dart';
import 'package:clinick/config/color.dart';
import 'package:clinick/database/app_firebase.dart';
import 'package:clinick/models/tracker_model.dart';
import 'package:clinick/patient/views/pages/tracker/blocs/bloc.dart';
import 'package:clinick/patient/views/pages/tracker/blocs/events.dart';
import 'package:clinick/patient/views/pages/tracker/item_template.dart';
import 'package:clinick/patient/views/pages/tracker/tracker_maker.dart';
import 'package:clinick/widgets/dialog_templates.dart';
import 'package:clinick/widgets/state_view_template.dart';
import 'package:clinick/widgets/toast.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:line_icons/line_icons.dart';

import 'blocs/states.dart';

class PatientPageMedicationTracker extends StatefulWidget {
  @override
  _PatientPageMedicationTrackerState createState() => _PatientPageMedicationTrackerState();
}

class _PatientPageMedicationTrackerState extends State<PatientPageMedicationTracker> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0.0,
        leading: const SizedBox(),
        leadingWidth: 0.0,
        elevation: 0.0,
        title: Row(
          children: [
            const SizedBox(width: 10.0),
            IconButton(
              icon: const Icon(
                LineIcons.arrowLeft,
                color: ThemeColor.primary,
              ),
              splashRadius: 24.0,
              padding: const EdgeInsets.all(8.0),
              onPressed: () => Navigator.of(context).pop(),
            ),
            const SizedBox(width: 15.0),
            const Text(
              'Medication Tracker',
              style: const TextStyle(
                fontSize: 17.0,
                fontWeight: FontWeight.bold,
                color: ThemeColor.primary,
              ),
            ),
            const Spacer(),
            IconButton(
              tooltip: 'Refresh List',
              icon: Icon(LineIcons.syncIcon),
              color: ThemeColor.accent,
              splashRadius: 24.0,
              onPressed: () => BlocProvider.of<PatientTrackerBloc>(context).add(PatientTrackerEventRequest()),
            ),
            IconButton(
              tooltip: 'Add Medication',
              icon: Icon(LineIcons.medicalNotes),
              color: ThemeColor.accent,
              splashRadius: 24.0,
              onPressed: () => onAddTracker(),
            ),
            const SizedBox(width: 5.0),
          ],
        ),
      ),
      body: Column(
        children: [
          Material(
            elevation: 5.0,
            borderRadius: BorderRadius.only(bottomLeft: Radius.circular(15.0), bottomRight: Radius.circular(15.0)),
            color: ThemeColor.background,
            shadowColor: ThemeColor.shadow.withOpacity(0.35),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(20.0, 0.0, 15.0, 15.0),
              child: Row(
                children: [
                  const Icon(
                    LineIcons.infoCircle,
                    size: 20.0,
                    color: ThemeColor.accent,
                  ),
                  const SizedBox(width: 10.0),
                  const Expanded(
                    child: const Text(
                      "'Swipe to Left' to delete a medication tracker.",
                      textAlign: TextAlign.justify,
                      style: const TextStyle(
                        fontSize: 12.0,
                        color: ThemeColor.secondary,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 15.0),
          Expanded(
            child: BlocBuilder<PatientTrackerBloc, PatientTrackerState>(
              builder: (context, state) {
                if (state is PatientTrackerStateSuccess) {
                  return ListView.builder(
                    padding: const EdgeInsets.symmetric(horizontal: 15.0),
                    itemCount: state.trackers.length,
                    itemBuilder: (context, index) {
                      final TrackerModel _model = state.trackers[index];
                      return Dismissible(
                        key: Key(_model.id!),
                        direction: DismissDirection.endToStart,
                        confirmDismiss: (_) async {
                          if (_model.end != null) {
                            if (_model.end!.compareTo(DateTime.now()) >= 0) {
                              // Show alert before continuing
                              final bool? _result = await showDialog(
                                context: context,
                                builder: (_) {
                                  return CriticalDialogTemplate(
                                    message:
                                        "You are deleting an unfinished medication from your list. This action is not reversible.",
                                  );
                                },
                              );

                              if (_result != null) {
                                if (!_result) return false;
                              } else {
                                return false;
                              }
                            }
                          }
                          return true;
                        },
                        onDismissed: (_) async {
                          await AppFirebase.firestore.collection('trackers').doc(_model.id!).delete();
                          toastGeneral("Medication successfully deleted.");
                        },
                        child: ItemTrackerTemplate(model: _model),
                      );
                    },
                  );
                } else if (state is PatientTrackerStateFailed) {
                  return StateView(
                    title: "Sorry for the trouble!",
                    message:
                        "We encountered an error while trying to get your medications. Please try to restart the app.",
                    assetPath: AppConfig.asset_failedImage,
                  );
                } else if (state is PatientTrackerStateInProgress) {
                  return Center(
                    child: const CircularProgressIndicator(
                      valueColor: AlwaysStoppedAnimation(
                        ThemeColor.accent,
                      ),
                    ),
                  );
                }

                return StateView(
                  title: "Nothing to see here!",
                  message:
                      "Click the 'Add' icon button above to create a medication. We will notify you when it is time for you take it.",
                  assetPath: AppConfig.asset_emptyImage,
                );
              },
            ),
          ),
          const SizedBox(height: 15.0),
        ],
      ),
    );
  }

  void onAddTracker() {
    Navigator.push(
      context,
      CupertinoPageRoute(
        builder: (_) {
          return PatientPageTrackerMaker();
        },
      ),
    );
  }
}
