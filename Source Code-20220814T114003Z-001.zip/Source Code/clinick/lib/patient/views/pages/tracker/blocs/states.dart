import 'package:clinick/models/tracker_model.dart';
import 'package:equatable/equatable.dart';

abstract class PatientTrackerState extends Equatable {
  const PatientTrackerState();

  @override
  List<Object> get props => [];
}

class PatientTrackerStateEmpty extends PatientTrackerState {}

class PatientTrackerStateInProgress extends PatientTrackerState {}

class PatientTrackerStateSuccess extends PatientTrackerState {
  final List<TrackerModel> trackers;
  final bool refresher;
  const PatientTrackerStateSuccess({required this.trackers, required this.refresher});

  @override
  List<Object> get props => [trackers, refresher];
}

class PatientTrackerStateFailed extends PatientTrackerState {}
