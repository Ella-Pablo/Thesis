import 'package:clinick/blocs/cubits/busy_state.dart';
import 'package:clinick/config/color.dart';
import 'package:clinick/config/labels.dart';
import 'package:clinick/database/app_firebase.dart';
import 'package:clinick/widgets/overlay_loader.dart';
import 'package:clinick/widgets/toast.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class PatientPageVerification extends StatefulWidget {
  const PatientPageVerification();

  @override
  _PatientPageVerificationState createState() => _PatientPageVerificationState();
}

class _PatientPageVerificationState extends State<PatientPageVerification> {
  DateTime? lastSentVerification;

  @override
  Widget build(BuildContext context) {
    final double _screenWidth = MediaQuery.of(context).size.width;

    return Scaffold(
      body: SizedBox.expand(
        child: BlocBuilder<BusyStateCubit, bool>(
          builder: (_, showOverlay) {
            return OverlayLoader(
              isBusy: showOverlay,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 15.0),
                child: Column(
                  children: [
                    const SizedBox(height: 100.0),
                    Text(
                      "We can't wait to serve you at CLinicK",
                      style: TextStyle(
                        color: ThemeColor.accent,
                        fontWeight: FontWeight.bold,
                        fontSize: 35.0,
                      ),
                    ),
                    const SizedBox(height: 10.0),
                    Text(
                      "But it seems that your email is not yet verified.",
                      style: TextStyle(
                        color: ThemeColor.secondary.withAlpha(200),
                        fontSize: 17.0,
                      ),
                    ),
                    const Spacer(),
                    SizedBox(
                      height: 40.0,
                      width: _screenWidth,
                      child: MaterialButton(
                        color: ThemeColor.accent,
                        textColor: ThemeColor.buttonTextColor,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20.0),
                        ),
                        child: Text(
                          'I am already verified!',
                          style: TextStyle(fontSize: 15.0),
                        ),
                        onPressed: () => verifyAccount(),
                      ),
                    ),
                    const SizedBox(height: 15.0),
                    SizedBox(
                      height: 40.0,
                      width: _screenWidth,
                      child: MaterialButton(
                        color: ThemeColor.background,
                        textColor: ThemeColor.accent,
                        child: Text(
                          'Resend Email Verification',
                          style: TextStyle(fontSize: 15.0),
                        ),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20.0),
                        ),
                        onPressed: () => resendVerificationEmail(),
                      ),
                    ),
                    const SizedBox(height: 10.0),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        GestureDetector(
                          onTap: () => signOut(),
                          child: Text(
                            "Logout from CLinicK",
                            style: TextStyle(
                              color: ThemeColor.accent,
                              fontSize: 14.0,
                              decoration: TextDecoration.underline,
                            ),
                          ),
                        ),
                        const SizedBox(width: 8.0),
                      ],
                    ),
                    const SizedBox(height: 70.0),
                    Text(
                      'Copyright © CLinicK. All rights reserved.',
                      style: TextStyle(
                        fontSize: 11.0,
                        color: ThemeColor.secondary2,
                      ),
                    ),
                    const SizedBox(height: 10.0),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  void verifyAccount() async {
    BlocProvider.of<BusyStateCubit>(context).change(true);

    await Future.delayed(Duration(seconds: 2));
    await AppFirebase.auth.currentUser?.reload();

    if (AppFirebase.auth.currentUser!.emailVerified) {
      toastGeneral("Your email has been successfully verified.");
    } else {
      toastGeneral("Your email is not verified yet.");
    }

    BlocProvider.of<BusyStateCubit>(context).change(false);
  }

  void resendVerificationEmail() async {
    BlocProvider.of<BusyStateCubit>(context).change(true);

    int _remaining = -1;

    // * Get the seconds since we've sent the last verification email
    if (lastSentVerification != null) {
      _remaining = 120 - DateTime.now().difference(lastSentVerification!).inSeconds;
    }

    // * Check if 2 minutes passed since we've sent the last verification email, then resend
    if (_remaining >= 0) {
      toastGeneral("Please wait for $_remaining seconds before resending the verification email.");
    } else {
      try {
        toastGeneral("Sending new verification email...");
        await AppFirebase.auth.currentUser?.sendEmailVerification();
        toastGeneral("Sent!");
      } on FirebaseAuthException catch (ex) {
        final String _errorMessage = Labels.authExceptionCodesToString(ex.code);
        toastError(_errorMessage);
      }
    }
    BlocProvider.of<BusyStateCubit>(context).change(false);
  }

  void signOut() async {
    BlocProvider.of<BusyStateCubit>(context).change(true);

    toastGeneral("Signing out from Clinick...");
    await Future.delayed(Duration(seconds: 1));

    AppFirebase.signOut();
  }
}
