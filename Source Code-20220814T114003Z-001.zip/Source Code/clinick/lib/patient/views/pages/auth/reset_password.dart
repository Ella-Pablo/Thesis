import 'package:clinick/blocs/cubits/reset_password_state.dart';
import 'package:clinick/config/color.dart';
import 'package:clinick/config/labels.dart';
import 'package:clinick/database/app_firebase.dart';
import 'package:clinick/widgets/toast.dart';
import 'package:email_validator/email_validator.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:line_icons/line_icons.dart';

class PatientPageResetPassword extends StatefulWidget {
  const PatientPageResetPassword();

  @override
  _PatientPageResetPasswordState createState() => _PatientPageResetPasswordState();
}

class _PatientPageResetPasswordState extends State<PatientPageResetPassword> {
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();
  String email = "";

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async => false,
      child: AnnotatedRegion<SystemUiOverlayStyle>(
        value: SystemUiOverlayStyle(
          statusBarBrightness: Brightness.light,
          statusBarIconBrightness: Brightness.light,
        ),
        child: Scaffold(
          body: BlocBuilder<ResetPasswordStateCubit, ResetPasswordState>(
            builder: (_, state) {
              return Form(
                key: formKey,
                child: Stack(
                  children: [
                    Positioned(
                      left: 0,
                      right: 0,
                      top: 0,
                      height: 230,
                      child: Container(
                        color: ThemeColor.accent,
                      ),
                    ),
                    Positioned(
                      left: 15,
                      top: 40,
                      height: 40,
                      child: Material(
                        color: ThemeColor.accent,
                        child: InkWell(
                          onTap: () => Navigator.of(context).pop(),
                          child: Row(
                            children: [
                              const SizedBox(width: 5.0),
                              Icon(
                                LineIcons.arrowLeft,
                                color: ThemeColor.background,
                              ),
                              const SizedBox(width: 10.0),
                              Text(
                                'Go Back',
                                style: TextStyle(
                                  color: ThemeColor.background,
                                  fontSize: 15.0,
                                ),
                              ),
                              const SizedBox(width: 8.0),
                            ],
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      left: 15,
                      right: 15,
                      top: 135,
                      child: Card(
                        elevation: 10.0,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(15.0),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(20.0),
                          child: Column(
                            children: [
                              Row(
                                children: [
                                  Expanded(
                                    child: Divider(
                                      endIndent: 15.0,
                                      color: ThemeColor.secondary,
                                    ),
                                  ),
                                  Text(
                                    'Forgot Password',
                                    style: TextStyle(
                                      fontSize: 15.0,
                                      color: ThemeColor.secondary,
                                    ),
                                  ),
                                  Expanded(
                                    child: Divider(
                                      indent: 15.0,
                                      color: ThemeColor.secondary,
                                    ),
                                  ),
                                ],
                              ),

                              const SizedBox(height: 20.0),

                              Text(
                                "Enter your email address and we'll send you a link to reset your password.",
                                style: TextStyle(
                                  color: ThemeColor.secondary,
                                ),
                              ),

                              const Divider(
                                height: 50.0,
                                indent: 20.0,
                                endIndent: 20.0,
                              ),

                              // INPUT FIELD: Email Address
                              if (state is ResetPasswordInitialState)
                                SizedBox(
                                  height: 45.0,
                                  child: TextFormField(
                                    decoration: InputDecoration(
                                      fillColor: ThemeColor.background,
                                      filled: true,
                                      contentPadding: const EdgeInsets.symmetric(horizontal: 15.0, vertical: 10.0),
                                      hintText: 'Enter your email address',
                                      hintStyle: TextStyle(
                                        color: ThemeColor.inputHint,
                                        fontSize: 14.0,
                                      ),
                                      enabledBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                          width: 1.0,
                                          color: ThemeColor.inputBorder,
                                        ),
                                        borderRadius: BorderRadius.circular(15.0),
                                      ),
                                      focusedBorder: OutlineInputBorder(
                                        borderSide: BorderSide(
                                          width: 1.0,
                                          color: ThemeColor.accent,
                                        ),
                                        borderRadius: BorderRadius.circular(15.0),
                                      ),
                                    ),
                                    style: const TextStyle(fontSize: 15.0),
                                    keyboardType: TextInputType.emailAddress,
                                    onSaved: (text) => email = text ?? "",
                                  ),
                                ),

                              const SizedBox(height: 10.0),

                              if (state is ResetPasswordInitialState)
                                MaterialButton(
                                  onPressed: resetPassword,
                                  minWidth: double.maxFinite,
                                  height: 40.0,
                                  child: const Text('Send Password Reset Link'),
                                  textColor: ThemeColor.buttonTextColor,
                                  color: ThemeColor.accent,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(20.0),
                                  ),
                                ),

                              if (state is ResetPasswordSendingState)
                                const Center(
                                  child: const CircularProgressIndicator(
                                    valueColor: AlwaysStoppedAnimation(ThemeColor.accent),
                                  ),
                                ),

                              if (!(state is ResetPasswordInitialState)) const SizedBox(height: 57.0),

                              if (state is ResetPasswordSentState)
                                Text(
                                  'Password reset instruction has been sent to your email.',
                                  style: TextStyle(
                                    fontSize: 15.0,
                                    color: ThemeColor.secondary2,
                                  ),
                                ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        ),
      ),
    );
  }

  void resetPassword() async {
    FocusScope.of(context).requestFocus(FocusNode());

    formKey.currentState?.save();

    BlocProvider.of<ResetPasswordStateCubit>(context).changeToSending();
    await Future.delayed(Duration(milliseconds: 500));

    bool _hasError = false;
    // * Check if the field is empty then do not continue
    if (email.isEmpty) {
      toastError("Please enter the email address of your account to continue.");
      _hasError = true;
    }

    // * Validate Input Values
    if (!_hasError && !EmailValidator.validate(email)) {
      toastError("Please enter a valid email address.");
      _hasError = true;
    }

    if (_hasError) {
      await Future.delayed(Duration(seconds: 2));
      BlocProvider.of<ResetPasswordStateCubit>(context).changeToInitial();
      return;
    }

    try {
      toastGeneral('Sending password reset email...');
      await AppFirebase.auth.sendPasswordResetEmail(email: email);

      await Future.delayed(Duration(seconds: 1));
      BlocProvider.of<ResetPasswordStateCubit>(context).changeToSent();
    } on FirebaseAuthException catch (ex) {
      final String _errorMessage = Labels.authExceptionCodesToString(ex.code);
      toastError(_errorMessage, clearPendingToast: true);

      await Future.delayed(Duration(seconds: 1));
      BlocProvider.of<ResetPasswordStateCubit>(context).changeToInitial();
    } catch (ex) {
      final String _errorMessage = Labels.authExceptionCodesToString("app-error");
      toastError(_errorMessage, clearPendingToast: true);

      await Future.delayed(Duration(seconds: 1));
      BlocProvider.of<ResetPasswordStateCubit>(context).changeToInitial();
    }
  }
}
