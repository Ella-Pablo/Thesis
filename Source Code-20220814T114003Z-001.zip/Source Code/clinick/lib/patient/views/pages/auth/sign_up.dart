import 'package:clinick/blocs/cubits/sign_up_state.dart';
import 'package:clinick/config/app_config.dart';
import 'package:clinick/config/color.dart';
import 'package:clinick/config/labels.dart';
import 'package:clinick/database/app_firebase.dart';
import 'package:clinick/views/info_reader.dart';
import 'package:clinick/widgets/overlay_loader.dart';
import 'package:clinick/widgets/toast.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:email_validator/email_validator.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:line_icons/line_icons.dart';

class PatientPageSignUp extends StatefulWidget {
  const PatientPageSignUp();

  @override
  _PatientPageSignUpState createState() => _PatientPageSignUpState();
}

class _PatientPageSignUpState extends State<PatientPageSignUp> {
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();
  String email = "";
  String password = "";
  String confirmPassword = "";

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async => false,
      child: Scaffold(
        body: SafeArea(
          child: SizedBox.expand(
            child: BlocBuilder<SignUpStateCubit, bool>(
              builder: (_, showOverlay) {
                return OverlayLoader(
                  isBusy: showOverlay,
                  child: Form(
                    key: formKey,
                    child: SingleChildScrollView(
                      padding: const EdgeInsets.symmetric(horizontal: 20.0),
                      physics: const BouncingScrollPhysics(),
                      child: Column(
                        children: [
                          const SizedBox(height: 10.0),
                          Align(
                            alignment: Alignment.centerRight,
                            child: IconButton(
                              icon: const Icon(LineIcons.times),
                              splashRadius: 24.0,
                              onPressed: () => Navigator.of(context).pop(),
                            ),
                          ),
                          const SizedBox(height: 20.0),
                          Align(
                            alignment: Alignment.centerLeft,
                            child: Text(
                              'Sign Up',
                              style: TextStyle(
                                fontSize: 45.0,
                                color: ThemeColor.accent,
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                          ),
                          const SizedBox(height: 10.0),
                          Align(
                            alignment: Alignment.centerLeft,
                            child: Text(
                              'Clinic at One Click!',
                              style: TextStyle(
                                fontSize: 25.0,
                                color: ThemeColor.secondary.withAlpha(200),
                              ),
                            ),
                          ),
                          const SizedBox(height: 5.0),
                          Align(
                            alignment: Alignment.centerLeft,
                            child: Text(
                              'Join our growing community that promotes easy access to your medical needs.',
                              style: TextStyle(
                                fontSize: 15.0,
                                color: ThemeColor.secondary.withAlpha(200),
                              ),
                            ),
                          ),
                          const SizedBox(height: 50.0),
                          SizedBox(
                            height: 45.0,
                            child: TextFormField(
                              decoration: InputDecoration(
                                fillColor: ThemeColor.background,
                                filled: true,
                                contentPadding: const EdgeInsets.symmetric(horizontal: 15.0, vertical: 10.0),
                                hintText: 'Email Address',
                                hintStyle: TextStyle(
                                  color: ThemeColor.inputHint,
                                  fontSize: 14.0,
                                ),
                                enabledBorder: OutlineInputBorder(
                                  borderSide: BorderSide(
                                    width: 1.0,
                                    color: ThemeColor.inputBorder,
                                  ),
                                  borderRadius: BorderRadius.circular(15.0),
                                ),
                                focusedBorder: OutlineInputBorder(
                                  borderSide: BorderSide(
                                    width: 1.0,
                                    color: ThemeColor.accent,
                                  ),
                                  borderRadius: BorderRadius.circular(15.0),
                                ),
                              ),
                              style: const TextStyle(fontSize: 15.0),
                              keyboardType: TextInputType.emailAddress,
                              onSaved: (text) => email = text ?? "",
                            ),
                          ),
                          const SizedBox(height: 10.0),
                          SizedBox(
                            height: 45.0,
                            child: TextFormField(
                              decoration: InputDecoration(
                                fillColor: ThemeColor.background,
                                filled: true,
                                contentPadding: const EdgeInsets.symmetric(horizontal: 15.0, vertical: 10.0),
                                hintText: 'Password',
                                hintStyle: TextStyle(
                                  color: ThemeColor.inputHint,
                                  fontSize: 14.0,
                                ),
                                enabledBorder: OutlineInputBorder(
                                  borderSide: BorderSide(
                                    width: 1.0,
                                    color: ThemeColor.inputBorder,
                                  ),
                                  borderRadius: BorderRadius.circular(15.0),
                                ),
                                focusedBorder: OutlineInputBorder(
                                  borderSide: BorderSide(
                                    width: 1.0,
                                    color: ThemeColor.accent,
                                  ),
                                  borderRadius: BorderRadius.circular(15.0),
                                ),
                              ),
                              style: const TextStyle(fontSize: 15.0),
                              obscureText: true,
                              keyboardType: TextInputType.text,
                              onSaved: (text) => password = text ?? "",
                            ),
                          ),
                          const SizedBox(height: 10.0),
                          // INPUT FIELD: CONFIRM PASSWORD
                          SizedBox(
                            height: 45.0,
                            child: TextFormField(
                              decoration: InputDecoration(
                                fillColor: ThemeColor.background,
                                filled: true,
                                contentPadding: const EdgeInsets.symmetric(horizontal: 15.0, vertical: 10.0),
                                hintText: 'Confirm Password',
                                hintStyle: TextStyle(
                                  color: ThemeColor.inputHint,
                                  fontSize: 14.0,
                                ),
                                enabledBorder: OutlineInputBorder(
                                  borderSide: BorderSide(
                                    width: 1.0,
                                    color: ThemeColor.inputBorder,
                                  ),
                                  borderRadius: BorderRadius.circular(15.0),
                                ),
                                focusedBorder: OutlineInputBorder(
                                  borderSide: BorderSide(
                                    width: 1.0,
                                    color: ThemeColor.accent,
                                  ),
                                  borderRadius: BorderRadius.circular(15.0),
                                ),
                              ),
                              style: const TextStyle(fontSize: 15.0),
                              obscureText: true,
                              keyboardType: TextInputType.text,
                              onSaved: (text) => confirmPassword = text ?? "",
                            ),
                          ),

                          const SizedBox(height: 15.0),
                          SizedBox(
                            height: 40.0,
                            width: double.maxFinite,
                            child: RichText(
                              text: TextSpan(
                                text: "By 'clicking' the register button, you have read and agree to the ",
                                style: const TextStyle(color: ThemeColor.secondary),
                                children: [
                                  TextSpan(
                                    text: "terms and conditions.",
                                    style: const TextStyle(
                                      color: ThemeColor.secondary,
                                      decoration: TextDecoration.underline,
                                    ),
                                    recognizer: TapGestureRecognizer()
                                      ..onTap = () async {
                                        final String _msg =
                                            await DefaultAssetBundle.of(context).loadString('assets/text/terms.txt');
                                        Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                            builder: (context) {
                                              return PageInfoReader(title: 'Terms and Conditions', message: _msg);
                                            },
                                          ),
                                        );
                                      },
                                  ),
                                ],
                              ),
                            ),
                          ),
                          const SizedBox(height: 30.0),
                          MaterialButton(
                            onPressed: signUpUsingEmail,
                            height: 45.0,
                            minWidth: double.maxFinite,
                            child: const Text('REGISTER'),
                            textColor: ThemeColor.buttonTextColor,
                            color: ThemeColor.accent,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(20.0),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ),
      ),
    );
  }

  void signUpUsingEmail() async {
    FocusScope.of(context).requestFocus(FocusNode());
    BlocProvider.of<SignUpStateCubit>(context).change(true);

    await Future.delayed(Duration(milliseconds: 500));
    formKey.currentState?.save();

    bool _hasError = false;

    // * Check inputs for null, empty, and confirm password:
    if (email.isEmpty || password.isEmpty || confirmPassword.isEmpty) {
      toastError("Please complete all the required fields.");
      _hasError = true;
    } else if (password != confirmPassword) {
      toastError("The password you entered does not match. Please check it carefully.");
      _hasError = true;
    }

    // * Validate Input Values
    if (!_hasError && !EmailValidator.validate(email)) {
      toastError("Please enter a valid email address.");
      _hasError = true;
    }

    if (_hasError) {
      await Future.delayed(Duration(seconds: 2));
      BlocProvider.of<SignUpStateCubit>(context).change(false);
      return;
    }

    try {
      final UserCredential user = await AppFirebase.auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );

      await AppFirebase.firestore
          .collection(AppConfig.table_patientData)
          .doc(user.user!.uid)
          .set({'email': user.user!.email}, SetOptions(merge: true));

      await user.user?.sendEmailVerification();
      toastGeneral("Successfully registered. Please check your inbox for verification.");

      await Future.delayed(Duration(seconds: 1));
      Navigator.of(context).pop(); // * Automatically close sign up page

    } on FirebaseAuthException catch (ex) {
      final String _errorMessage = Labels.authExceptionCodesToString(ex.code);
      toastError(_errorMessage);
      BlocProvider.of<SignUpStateCubit>(context).change(false);
    } on PlatformException catch (ex) {
      final String _errorMessage = Labels.authExceptionCodesToString(ex.code);
      toastError(_errorMessage);
      BlocProvider.of<SignUpStateCubit>(context).change(false);
    } catch (ex) {
      final String _errorMessage = Labels.authExceptionCodesToString("app-error");
      toastError(_errorMessage);
      BlocProvider.of<SignUpStateCubit>(context).change(false);
    }
  }
}
