import 'package:equatable/equatable.dart';

abstract class SearchDoctorEvent extends Equatable {
  const SearchDoctorEvent();

  @override
  List<Object> get props => [];
}

class SearchDoctorEventRequest extends SearchDoctorEvent {
  const SearchDoctorEventRequest({required this.keywords, required this.isDoctorName});
  final String keywords;
  final bool isDoctorName;
}
