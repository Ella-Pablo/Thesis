import 'package:clinick/models/staff_data_model.dart';
import 'package:equatable/equatable.dart';

abstract class SearchDoctorState extends Equatable {
  const SearchDoctorState();

  @override
  List<Object> get props => [];
}

class SearchDoctorStateEmpty extends SearchDoctorState {}

class SearchDoctorStateInProgress extends SearchDoctorState {}

class SearchDoctorStateSuccess extends SearchDoctorState {
  final List<StaffDataModel> doctors;
  const SearchDoctorStateSuccess({required this.doctors});

  @override
  List<Object> get props => [doctors];
}

class SearchDoctorStateFailed extends SearchDoctorState {}
