import 'dart:async';

import 'package:clinick/config/app_config.dart';
import 'package:clinick/config/specialization.dart';
import 'package:clinick/database/app_firebase.dart';
import 'package:clinick/models/staff_data_model.dart';
import 'package:clinick/patient/views/pages/search/blocs/events.dart';
import 'package:clinick/patient/views/pages/search/blocs/states.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class SearchDoctorBloc extends Bloc<SearchDoctorEvent, SearchDoctorState> {
  SearchDoctorBloc() : super(SearchDoctorStateEmpty());

  @override
  Stream<SearchDoctorState> mapEventToState(SearchDoctorEvent event) async* {
    try {
      if (event is SearchDoctorEventRequest) {
        yield SearchDoctorStateInProgress();

        if (event.isDoctorName) {
          String _keyword = event.keywords.toLowerCase();
          _keyword = _keyword.replaceAll('dr.', '');

          QuerySnapshot _data = await AppFirebase.firestore
              .collection(AppConfig.table_staffdata)
              .where('search', arrayContainsAny: _keyword.split(' '))
              .limit(15)
              .get();

          if (_data.docs.isEmpty) {
            yield SearchDoctorStateEmpty();
            return;
          }

          final List<StaffDataModel> doctors = _data.docs.map((e) => StaffDataModel.fromMap(e.id, e.data())).toList();
          doctors.removeWhere((e) => e.id == AppFirebase.uid());

          if (doctors.isEmpty) {
            yield SearchDoctorStateEmpty();
            return;
          }

          yield SearchDoctorStateSuccess(
            doctors: doctors,
          );
        } else {
          List<int> _specializations = parseKeywords(event.keywords.split(' '));

          if (_specializations.isEmpty) {
            yield SearchDoctorStateEmpty();
            return;
          }

          QuerySnapshot _data = await AppFirebase.firestore
              .collection(AppConfig.table_staffdata)
              .where('specialization', whereIn: _specializations)
              .get();

          if (_data.docs.isEmpty) {
            yield SearchDoctorStateEmpty();
            return;
          }

          final List<StaffDataModel> doctors = _data.docs.map((e) => StaffDataModel.fromMap(e.id, e.data())).toList();

          yield SearchDoctorStateSuccess(
            doctors: doctors,
          );
        }
      }
    } catch (ex) {
      yield SearchDoctorStateFailed();
    }
  }

  List<int> parseKeywords(List<String> keywords) {
    Map<int, int> result = {};

    for (var keyword in keywords) {
      for (var entry in StaffSpecialization.instance.staffSpecialization.entries) {
        if (entry.value.contains(keyword.toLowerCase() + ',')) {
          if (result.containsKey(entry.key)) {
            result[entry.key] = result[entry.key]! + 1;
          } else {
            result[entry.key] = 1;
          }
        }
      }
    }

    if (result.isEmpty) return [];
    List<MapEntry<int, int>> _sortedList = result.entries.toList();
    _sortedList.sort((a, b) => b.value.compareTo(a.value));

    if (_sortedList.length > 5) {
      return _sortedList.map((e) => e.key).toList().getRange(0, 5).toList();
    } else {
      return _sortedList.map((e) => e.key).toList();
    }
  }
}
