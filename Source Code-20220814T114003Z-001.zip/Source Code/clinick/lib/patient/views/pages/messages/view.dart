import 'package:clinick/blocs/messaging/list/bloc.dart';
import 'package:clinick/blocs/messaging/list/events.dart';
import 'package:clinick/blocs/messaging/list/states.dart';
import 'package:clinick/config/app_config.dart';
import 'package:clinick/config/color.dart';
import 'package:clinick/widgets/message_info_templates.dart';
import 'package:clinick/widgets/state_view_template.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:line_icons/line_icons.dart';
import 'package:sliver_tools/sliver_tools.dart';

class PatientPageMessages extends StatefulWidget {
  @override
  _PatientPageMessagesState createState() => _PatientPageMessagesState();
}

class _PatientPageMessagesState extends State<PatientPageMessages> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leadingWidth: 0.0,
        leading: const SizedBox(),
        titleSpacing: 0.0,
        toolbarHeight: 150.0,
        elevation: 0.0,
        flexibleSpace: Material(
          elevation: 5.0,
          borderRadius: BorderRadius.circular(15.0),
          color: ThemeColor.background,
          shadowColor: ThemeColor.shadow.withOpacity(0.35),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(15.0, 35.0, 15.0, 15.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    IconButton(
                      icon: const Icon(
                        LineIcons.arrowLeft,
                        color: ThemeColor.primary,
                      ),
                      splashRadius: 24.0,
                      padding: const EdgeInsets.all(8.0),
                      onPressed: () => Navigator.of(context).pop(),
                    ),
                    Text(
                      "Messages",
                      style: const TextStyle(
                        fontSize: 35.0,
                        color: ThemeColor.accent,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
                Text(
                  "Confirm availability and formally ask for an appointment.",
                  style: const TextStyle(
                    fontSize: 15.0,
                    color: ThemeColor.secondary,
                  ),
                ),
                const SizedBox(height: 10.0),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Icon(
                      LineIcons.infoCircle,
                      size: 20.0,
                      color: ThemeColor.accent,
                    ),
                    const SizedBox(width: 5.0),
                    const Expanded(
                      child: const Text(
                        "Our medical staff will never ask for an external (outside-the-app) payment for any of the services we offered.",
                        textAlign: TextAlign.justify,
                        style: const TextStyle(
                          fontSize: 12.0,
                          color: ThemeColor.secondary,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
      body: CustomScrollView(
        physics: const BouncingScrollPhysics(),
        slivers: [
          const SliverToBoxAdapter(child: const SizedBox(height: 10.0)),
          SliverPinnedHeader(
            child: Container(
              color: ThemeColor.background,
              padding: const EdgeInsets.symmetric(vertical: 8.0),
              child: SizedBox(
                width: double.maxFinite,
                height: 55.0,
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 15.0),
                  child: Material(
                    elevation: 5.0,
                    borderRadius: BorderRadius.circular(25.0),
                    color: ThemeColor.background,
                    shadowColor: ThemeColor.shadow.withOpacity(0.35),
                    child: Padding(
                      padding: const EdgeInsets.all(5.0),
                      child: Center(
                        child: TextField(
                          decoration: const InputDecoration(
                            contentPadding: const EdgeInsets.fromLTRB(15.0, 10.5, 15.0, 10.0),
                            hintText: 'Search',
                            hintStyle: const TextStyle(
                              color: ThemeColor.inputHint,
                              fontSize: 16.0,
                            ),
                            enabledBorder: InputBorder.none,
                            focusedBorder: InputBorder.none,
                            prefixIcon: const Icon(
                              LineIcons.search,
                              color: ThemeColor.secondary2,
                            ),
                          ),
                          style: const TextStyle(
                            fontSize: 17.0,
                            color: ThemeColor.secondary,
                          ),
                          onChanged: (text) {
                            if (text.length > 0 && text.length < 4) return;
                            BlocProvider.of<MessageInfoBloc>(context).add(
                              MessageInfoEventSearch(keywords: text),
                            );
                          },
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
          BlocBuilder<MessageInfoBloc, MessageInfoState>(
            builder: (context, state) {
              if (state is MessageInfoStateSuccess) {
                return SliverList(
                  delegate: SliverChildBuilderDelegate(
                    (context, index) {
                      return MessageInfoItem(
                        model: state.conversations[index],
                        showToolbar: false,
                      );
                    },
                    childCount: state.conversations.length,
                  ),
                );
              } else if (state is MessageInfoStateInProgress) {
                return const SliverFillRemaining(
                  child: const Center(
                    child: const CircularProgressIndicator(
                      valueColor: AlwaysStoppedAnimation(ThemeColor.accent),
                    ),
                  ),
                );
              } else if (state is MessageInfoStateFailed) {
                return const SliverFillRemaining(
                  child: const Center(
                    child: const StateView(
                      title: "Sorry for the trouble!",
                      message:
                          "We encountered an error while trying to fetch your conversation list. Please try again.",
                      assetPath: AppConfig.asset_emptyImage,
                    ),
                  ),
                );
              }

              return const SliverFillRemaining(
                child: const Center(
                  child: const StateView(
                    title: "Nothing to see here!",
                    message: "Start messaging by clicking the message icon on your search result items.",
                    assetPath: AppConfig.asset_emptyImage,
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}
