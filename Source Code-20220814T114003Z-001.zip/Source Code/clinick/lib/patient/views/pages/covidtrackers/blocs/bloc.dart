import 'dart:async';
import 'package:clinick/database/app_firebase.dart';
import 'package:clinick/models/covid_tracker_model.dart';
import 'package:clinick/patient/views/pages/covidtrackers/blocs/events.dart';
import 'package:clinick/patient/views/pages/covidtrackers/blocs/states.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class CovidTrackerBloc extends Bloc<CovidTrackerEvent, CovidTrackerState> {
  CovidTrackerBloc() : super(CovidTrackerStateEmpty());

  List<CovidTrackerModel> visitTrackers = [];
  CovidTrackerModel? puiTracker;
  bool refresher = false;

  @override
  Stream<CovidTrackerState> mapEventToState(CovidTrackerEvent event) async* {
    try {
      if (event is CovidTrackerEventRequest) {
        yield CovidTrackerStateInProgress();
        await Future.delayed(Duration(seconds: 1));

        QuerySnapshot _visitData =
            await AppFirebase.firestore.collection('covidtrackers').where('userid', isEqualTo: AppFirebase.uid()).get();

        QuerySnapshot _puiData = await AppFirebase.firestore
            .collection('covidpui')
            .where('userid', isEqualTo: AppFirebase.uid())
            .limit(1)
            .get();

        if (_visitData.size <= 0) {
          yield CovidTrackerStateEmpty();
          return;
        }

        visitTrackers.clear();
        visitTrackers.addAll(_visitData.docs.map((e) => CovidTrackerModel.fromSnapshot(e.id, e.data())));
        visitTrackers.sort((a, b) => a.start.compareTo(b.start));

        puiTracker = null;
        if (_puiData.size > 0) {
          puiTracker = CovidTrackerModel.fromSnapshot(_puiData.docs.first.id, _puiData.docs.first.data());
        }

        refresher = !refresher;

        yield CovidTrackerStateSuccess(
          visitTrackers: visitTrackers,
          puiTracker: puiTracker,
          refresher: refresher,
        );
      }
    } catch (ex) {
      //print(ex);
      yield CovidTrackerStateFailed();
    }
  }
}
