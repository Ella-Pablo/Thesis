import 'package:equatable/equatable.dart';

abstract class CovidTrackerEvent extends Equatable {
  const CovidTrackerEvent();

  @override
  List<Object> get props => [];
}

class CovidTrackerEventRequest extends CovidTrackerEvent {}
