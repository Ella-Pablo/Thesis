import 'package:clinick/config/app_config.dart';
import 'package:clinick/config/color.dart';
import 'package:clinick/models/covid_tracker_model.dart';
import 'package:clinick/patient/views/pages/covidtrackers/blocs/bloc.dart';
import 'package:clinick/patient/views/pages/covidtrackers/blocs/states.dart';
import 'package:clinick/patient/views/pages/covidtrackers/covid_tracker_template.dart';
import 'package:clinick/widgets/state_view_template.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:intl/intl.dart';
import 'package:line_icons/line_icons.dart';

import 'blocs/events.dart';

class PatientPageCovidTracker extends StatefulWidget {
  @override
  _PatientPageCovidTrackerState createState() => _PatientPageCovidTrackerState();
}

class _PatientPageCovidTrackerState extends State<PatientPageCovidTracker> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0.0,
        leading: const SizedBox(),
        leadingWidth: 0.0,
        elevation: 0.0,
        title: Row(
          children: [
            const SizedBox(width: 10.0),
            IconButton(
              icon: const Icon(
                LineIcons.arrowLeft,
                color: ThemeColor.primary,
              ),
              splashRadius: 24.0,
              padding: const EdgeInsets.all(8.0),
              onPressed: () => Navigator.of(context).pop(),
            ),
            const SizedBox(width: 15.0),
            const Text(
              'Contact Tracing',
              style: const TextStyle(
                fontSize: 17.0,
                fontWeight: FontWeight.bold,
                color: ThemeColor.primary,
              ),
            ),
            const Spacer(),
            IconButton(
              tooltip: 'Refresh',
              icon: Icon(LineIcons.syncIcon),
              color: ThemeColor.accent,
              splashRadius: 24.0,
              onPressed: () => BlocProvider.of<CovidTrackerBloc>(context).add(CovidTrackerEventRequest()),
            ),
            const SizedBox(width: 5.0),
          ],
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 15.0),
        child: Column(
          children: [
            const SizedBox(height: 5.0),
            BlocBuilder<CovidTrackerBloc, CovidTrackerState>(
              builder: (context, state) {
                if (state is CovidTrackerStateSuccess) {
                  if (state.puiTracker != null) {
                    final CovidTrackerModel _model = state.puiTracker!;
                    return Material(
                      elevation: 5.0,
                      borderRadius: BorderRadius.circular(15.0),
                      color: ThemeColor.background,
                      shadowColor: ThemeColor.shadow.withOpacity(0.85),
                      child: Container(
                        width: double.maxFinite,
                        decoration: BoxDecoration(
                          color: ThemeColor.accent,
                          borderRadius: BorderRadius.circular(15.0),
                          gradient: const LinearGradient(
                            colors: [
                              Color.fromARGB(255, 186, 48, 48),
                              ThemeColor.accent,
                            ],
                            begin: Alignment.bottomRight,
                            end: Alignment.topLeft,
                          ),
                        ),
                        padding: const EdgeInsets.all(15.0),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Icon(
                              LineIcons.exclamationTriangle,
                              size: 40.0,
                              color: ThemeColor.background,
                            ),
                            const SizedBox(width: 10.0),
                            Expanded(
                              child: Text(
                                "Oh no! Someone tested positive during your stay in our clinic last ${DateFormat('MMMM dd, yyyy').format(_model.start)} (${DateFormat('hh:mm a').format(_model.start)} - ${DateFormat('hh:mm a').format(_model.end)}).",
                                textAlign: TextAlign.justify,
                                style: const TextStyle(
                                  color: ThemeColor.background,
                                  fontSize: 15.0,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  }
                }

                return Material(
                  elevation: 5.0,
                  borderRadius: BorderRadius.circular(15.0),
                  color: ThemeColor.background,
                  shadowColor: ThemeColor.shadow.withOpacity(0.35),
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(10.0, 15.0, 15.0, 15.0),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Icon(
                          LineIcons.infoCircle,
                          size: 20.0,
                          color: ThemeColor.accent,
                        ),
                        const SizedBox(width: 5.0),
                        const Expanded(
                          child: const Text(
                            'If you have been around someone who came out positive of COVID-19 during your stay in our clinic, you will be notified immediately here.',
                            textAlign: TextAlign.justify,
                            style: const TextStyle(
                              fontSize: 12.0,
                              color: ThemeColor.secondary,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
            const SizedBox(height: 20.0),
            Expanded(
              child: BlocBuilder<CovidTrackerBloc, CovidTrackerState>(
                builder: (context, state) {
                  if (state is CovidTrackerStateSuccess) {
                    if (state.visitTrackers.isNotEmpty) {
                      return ListView.separated(
                        physics: const BouncingScrollPhysics(parent: const AlwaysScrollableScrollPhysics()),
                        itemCount: state.visitTrackers.length,
                        separatorBuilder: (context, index) => const SizedBox(height: 10.0),
                        itemBuilder: (context, index) {
                          return CovidTrackerItemTemplate(
                            model: state.visitTrackers[index],
                          );
                        },
                      );
                    }
                  } else if (state is CovidTrackerStateFailed) {
                    final double w = MediaQuery.of(context).size.width;
                    return SingleChildScrollView(
                      physics: const BouncingScrollPhysics(parent: const AlwaysScrollableScrollPhysics()),
                      child: Column(
                        children: [
                          StateView(
                            title: 'Sorry for the trouble!',
                            message:
                                "We encountered an error while trying to fetch the data of your visits. We encourage you to contact our administrator immediately.",
                            assetPath: AppConfig.asset_failedImage,
                            imageSize: Size(w * 0.55, w * 0.45),
                          ),
                        ],
                      ),
                    );
                  } else if (state is CovidTrackerStateInProgress) {
                    return const Center(
                      child: const CircularProgressIndicator(
                        valueColor: AlwaysStoppedAnimation(
                          ThemeColor.accent,
                        ),
                      ),
                    );
                  }

                  final double w = MediaQuery.of(context).size.width;
                  return SingleChildScrollView(
                    physics: const BouncingScrollPhysics(parent: const AlwaysScrollableScrollPhysics()),
                    child: Column(
                      children: [
                        StateView(
                          title: 'Nothing to see here!',
                          message:
                              "You haven't visited our clinic yet. The time and duration of your visit will appear here.",
                          assetPath: AppConfig.asset_emptyImage,
                          imageSize: Size(w * 0.55, w * 0.45),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
