import 'package:clinick/models/covid_tracker_model.dart';
import 'package:equatable/equatable.dart';

abstract class CovidTrackerState extends Equatable {
  const CovidTrackerState();

  @override
  List<Object> get props => [];
}

class CovidTrackerStateEmpty extends CovidTrackerState {}

class CovidTrackerStateInProgress extends CovidTrackerState {}

class CovidTrackerStateSuccess extends CovidTrackerState {
  final List<CovidTrackerModel> visitTrackers;
  final CovidTrackerModel? puiTracker;
  final bool refresher;
  const CovidTrackerStateSuccess({required this.visitTrackers, required this.puiTracker, required this.refresher});

  @override
  List<Object> get props => [visitTrackers, puiTracker!, refresher];
}

class CovidTrackerStateFailed extends CovidTrackerState {}
