import 'dart:async';
import 'package:clinick/database/app_firebase.dart';
import 'package:clinick/models/record_item_model.dart';
import 'package:clinick/models/upload_item_model.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'events.dart';
import 'states.dart';

class RecordListBloc extends Bloc<RecordListEvent, RecordListState> {
  RecordListBloc() : super(RecordListStateInProgress());

  List<RecordItemModel> records = [];
  bool refresher = false;

  @override
  Stream<RecordListState> mapEventToState(RecordListEvent event) async* {
    try {
      MedicalRecordsType _type = MedicalRecordsType.general;
      if (event is RecordListEventRequest) {
        yield RecordListStateInProgress();
        await Future.delayed(Duration(seconds: 1));
        _type = event.type;
      }

      QuerySnapshot _snapshot = await AppFirebase.firestore
          .collection('records')
          .where('userid', isEqualTo: AppFirebase.uid())
          .where('type', isEqualTo: _type.index)
          .orderBy('createdat', descending: true)
          .get();
      if (_snapshot.docs.isEmpty) {
        yield RecordListStateEmpty();
        return;
      }

      records.clear();
      records.addAll(_snapshot.docs.map((e) => RecordItemModel.fromSnapshot(e.id, e.data())));

      refresher = !refresher;

      yield RecordListStateSuccess(
        records: records,
        refresher: refresher,
      );
    } catch (ex) {
      //print(ex);
      yield RecordListStateFailed();
    }
  }
}
