import 'dart:io';

import 'package:clinick/config/color.dart';
import 'package:clinick/database/app_firebase.dart';
import 'package:clinick/models/record_item_model.dart';
import 'package:clinick/models/upload_item_model.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:open_file/open_file.dart';
import 'package:path_provider/path_provider.dart';

class RecordItemTemplate extends StatefulWidget {
  const RecordItemTemplate({required this.model});
  final RecordItemModel model;

  @override
  _RecordItemTemplateState createState() => _RecordItemTemplateState();
}

class _RecordItemTemplateState extends State<RecordItemTemplate> {
  final ValueNotifier<double> progress = ValueNotifier(0.0);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5.0),
      child: Material(
        elevation: 12.0,
        borderRadius: BorderRadius.circular(15.0),
        color: ThemeColor.background,
        shadowColor: ThemeColor.shadow.withOpacity(0.35),
        child: InkWell(
          onTap: onOpenFile,
          borderRadius: BorderRadius.circular(15.0),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(15.0, 15.0, 15.0, 15.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  widget.model.fileName,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 14.0,
                    color: ThemeColor.accent,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 3.0),
                Text(
                  "From: ${widget.model.staffName}",
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 13.0,
                    color: ThemeColor.secondary,
                  ),
                ),
                const SizedBox(height: 3.0),
                Text(
                  "Created on: ${DateFormat('MMMM dd, yyyy').format(widget.model.createdAt)}",
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 13.0,
                    color: ThemeColor.secondary,
                  ),
                ),
                const SizedBox(height: 10.0),
                ValueListenableBuilder<double>(
                  valueListenable: progress,
                  builder: (_, value, __) {
                    return LinearProgressIndicator(
                      backgroundColor: ThemeColor.secondary,
                      value: value,
                    );
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void onOpenFile() async {
    Directory? appDocDir = await getExternalStorageDirectory();
    if (appDocDir == null) appDocDir = await getApplicationDocumentsDirectory();
    Directory("${appDocDir.path}/CLinicK").create();
    final File _localFile = File('${appDocDir.path}/CLinicK/${widget.model.fileName}');

    if (await _localFile.exists()) {
      progress.value = 100.0;
      OpenFile.open(_localFile.path);
      return;
    }

    late final String _folder;
    if (widget.model.type == MedicalRecordsType.laboratory) {
      _folder = "lab_records";
    } else if (widget.model.type == MedicalRecordsType.radiology) {
      _folder = "radiology_records";
    } else {
      _folder = "general_records";
    }

    DownloadTask _task = AppFirebase.storage
        .ref()
        .child(_folder)
        .child(widget.model.userId)
        .child(widget.model.fileName)
        .writeToFile(_localFile);
    _task.snapshotEvents.listen((snapshot) async {
      progress.value = snapshot.bytesTransferred / snapshot.totalBytes;
    }).onError((_) {});
  }
}
