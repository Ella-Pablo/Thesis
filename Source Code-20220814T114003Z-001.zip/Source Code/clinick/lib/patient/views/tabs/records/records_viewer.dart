import 'package:clinick/config/app_config.dart';
import 'package:clinick/config/color.dart';
import 'package:clinick/models/upload_item_model.dart';
import 'package:clinick/patient/views/tabs/records/blocs/bloc.dart';
import 'package:clinick/patient/views/tabs/records/blocs/events.dart';
import 'package:clinick/patient/views/tabs/records/record_item_template.dart';
import 'package:clinick/widgets/state_view_template.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:line_icons/line_icons.dart';

import 'blocs/states.dart';

class PatientPageRecordViewer extends StatefulWidget {
  const PatientPageRecordViewer({required this.type});
  final MedicalRecordsType type;
  @override
  _PatientPageRecordViewerState createState() => _PatientPageRecordViewerState();
}

class _PatientPageRecordViewerState extends State<PatientPageRecordViewer> {
  @override
  void initState() {
    BlocProvider.of<RecordListBloc>(context).add(RecordListEventRequest(type: widget.type));
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0.0,
        leading: const SizedBox(),
        leadingWidth: 0.0,
        elevation: 0.0,
        title: Row(
          children: [
            const SizedBox(width: 10.0),
            IconButton(
              icon: const Icon(
                LineIcons.arrowLeft,
                color: ThemeColor.primary,
              ),
              splashRadius: 24.0,
              padding: const EdgeInsets.all(8.0),
              onPressed: () => Navigator.of(context).pop(),
            ),
            const SizedBox(width: 15.0),
            Text(
              widget.type == MedicalRecordsType.laboratory
                  ? "Laboratory Results"
                  : widget.type == MedicalRecordsType.radiology
                      ? "Radiology Results"
                      : "General Records",
              style: const TextStyle(
                fontSize: 17.0,
                fontWeight: FontWeight.bold,
                color: ThemeColor.primary,
              ),
            ),
          ],
        ),
      ),
      body: SizedBox.expand(
        child: Column(
          children: [
            Material(
              elevation: 5.0,
              borderRadius: BorderRadius.only(bottomLeft: Radius.circular(15.0), bottomRight: Radius.circular(15.0)),
              color: ThemeColor.background,
              shadowColor: ThemeColor.shadow.withOpacity(0.35),
              child: Padding(
                padding: const EdgeInsets.fromLTRB(10.0, 0.0, 15.0, 15.0),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Icon(
                      LineIcons.infoCircle,
                      size: 20.0,
                      color: ThemeColor.accent,
                    ),
                    const SizedBox(width: 5.0),
                    const Expanded(
                      child: const Text(
                        'Click the file to begin the download process then click again to open the file.',
                        textAlign: TextAlign.justify,
                        style: const TextStyle(
                          fontSize: 12.0,
                          color: ThemeColor.secondary,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Expanded(
              child: BlocBuilder<RecordListBloc, RecordListState>(
                builder: (_, state) {
                  if (state is RecordListStateSuccess) {
                    return ListView.builder(
                      physics: const BouncingScrollPhysics(parent: const AlwaysScrollableScrollPhysics()),
                      padding: const EdgeInsets.all(15.0),
                      itemCount: state.records.length,
                      itemBuilder: (_, index) {
                        return RecordItemTemplate(
                          model: state.records[index],
                        );
                      },
                    );
                  } else if (state is RecordListStateFailed) {
                    return StateView(
                      title: "Sorry for the trouble!",
                      message: "Something went wrong while we are trying to get your records. Please try again.",
                      assetPath: AppConfig.asset_failedImage,
                    );
                  } else if (state is RecordListStateInProgress) {
                    return Center(
                      child: const CircularProgressIndicator(
                        valueColor: AlwaysStoppedAnimation(
                          ThemeColor.accent,
                        ),
                      ),
                    );
                  }

                  return StateView(
                    title: "Nothing to see here",
                    message: "All the files uploaded and tagged to you by your doctor(s) will appear here.",
                    assetPath: AppConfig.asset_emptyImage,
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
