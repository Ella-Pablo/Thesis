import 'package:clinick/models/record_item_model.dart';
import 'package:equatable/equatable.dart';

abstract class RecordListState extends Equatable {
  const RecordListState();

  @override
  List<Object> get props => [];
}

class RecordListStateEmpty extends RecordListState {}

class RecordListStateInProgress extends RecordListState {}

class RecordListStateSuccess extends RecordListState {
  final List<RecordItemModel> records;
  final bool refresher;
  const RecordListStateSuccess({required this.records, required this.refresher});

  @override
  List<Object> get props => [records, refresher];
}

class RecordListStateFailed extends RecordListState {}
