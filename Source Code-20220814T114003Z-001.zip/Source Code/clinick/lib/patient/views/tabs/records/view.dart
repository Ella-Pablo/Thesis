import 'package:clinick/config/color.dart';
import 'package:clinick/models/upload_item_model.dart';
import 'package:clinick/patient/views/tabs/records/blocs/bloc.dart';
import 'package:clinick/patient/views/tabs/records/records_viewer.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:line_icons/line_icons.dart';

class PatientTabRecords extends StatefulWidget {
  const PatientTabRecords();
  _PatientTabRecordsState createState() => _PatientTabRecordsState();
}

class _PatientTabRecordsState extends State<PatientTabRecords> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          padding: const EdgeInsets.all(15.0),
          child: Column(
            children: [
              const SizedBox(height: 20.0),
              SizedBox(
                width: double.maxFinite,
                child: Material(
                  elevation: 5.0,
                  borderRadius: BorderRadius.circular(15.0),
                  color: ThemeColor.background,
                  shadowColor: ThemeColor.shadow.withOpacity(0.35),
                  child: Padding(
                    padding: const EdgeInsets.all(15.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'You can access your test results, certifications, or any personal medical files here without physically going to our clinic.',
                          style: const TextStyle(
                            fontSize: 14.0,
                            color: ThemeColor.secondary,
                          ),
                        ),
                        const SizedBox(height: 20.0),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              width: 40.0,
                              height: 40.0,
                              decoration: const BoxDecoration(
                                shape: BoxShape.circle,
                                color: ThemeColor.accent,
                              ),
                              child: const Center(
                                child: const Text(
                                  '1',
                                  style: const TextStyle(
                                    fontSize: 18.0,
                                    color: ThemeColor.background,
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(width: 10.0),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const SizedBox(height: 5.0),
                                  const Text(
                                    "Select the type of record",
                                    style: const TextStyle(
                                      fontSize: 16.0,
                                      fontWeight: FontWeight.bold,
                                      color: ThemeColor.secondary2,
                                    ),
                                  ),
                                  const Text(
                                    "You can read the description of each folder below to determine the type of the record you want to view.",
                                    textAlign: TextAlign.justify,
                                    style: const TextStyle(
                                      fontSize: 13.0,
                                      color: ThemeColor.secondary,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 10.0),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              width: 40.0,
                              height: 40.0,
                              decoration: const BoxDecoration(
                                shape: BoxShape.circle,
                                color: ThemeColor.accent,
                              ),
                              child: const Center(
                                child: const Text(
                                  '2',
                                  style: const TextStyle(
                                    fontSize: 18.0,
                                    color: ThemeColor.background,
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(width: 10.0),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const SizedBox(height: 5.0),
                                  const Text(
                                    "Download the file",
                                    style: const TextStyle(
                                      fontSize: 16.0,
                                      fontWeight: FontWeight.bold,
                                      color: ThemeColor.secondary2,
                                    ),
                                  ),
                                  const Text(
                                    "Find the file by filtering the date, file name and/or the name of the doctor that issued the record.",
                                    textAlign: TextAlign.justify,
                                    style: const TextStyle(
                                      fontSize: 13.0,
                                      color: ThemeColor.secondary,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 10.0),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              width: 40.0,
                              height: 40.0,
                              decoration: const BoxDecoration(
                                shape: BoxShape.circle,
                                color: ThemeColor.accent,
                              ),
                              child: const Center(
                                child: const Text(
                                  '3',
                                  style: const TextStyle(
                                    fontSize: 18.0,
                                    color: ThemeColor.background,
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(width: 10.0),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const SizedBox(height: 5.0),
                                  const Text(
                                    "Access your record",
                                    style: const TextStyle(
                                      fontSize: 16.0,
                                      fontWeight: FontWeight.bold,
                                      color: ThemeColor.secondary2,
                                    ),
                                  ),
                                  const Text(
                                    "Open the file that you've downloaded using a PDF reader. Note that all files are in .pdf format.",
                                    textAlign: TextAlign.justify,
                                    style: const TextStyle(
                                      fontSize: 13.0,
                                      color: ThemeColor.secondary,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 20.0),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Icon(
                              LineIcons.infoCircle,
                              size: 20.0,
                              color: ThemeColor.accent,
                            ),
                            const SizedBox(width: 10.0),
                            Expanded(
                              child: const Text(
                                "If you have any question regarding your record, kindly contact your respective staff or doctor.",
                                style: const TextStyle(
                                  fontSize: 13.0,
                                  color: ThemeColor.secondary,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 30.0),
              SizedBox(
                width: double.maxFinite,
                height: 100.0,
                child: Material(
                  elevation: 5.0,
                  borderRadius: BorderRadius.circular(8.0),
                  color: ThemeColor.background,
                  shadowColor: ThemeColor.shadow.withOpacity(0.35),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(8.0),
                    onTap: () => openRecords(MedicalRecordsType.general),
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Icon(
                            LineIcons.medicalNotes,
                            size: 60.0,
                            color: ThemeColor.accent,
                          ),
                          const SizedBox(width: 10.0),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const SizedBox(height: 5.0),
                                const Text(
                                  'General Records',
                                  style: const TextStyle(
                                    fontWeight: FontWeight.bold,
                                    color: ThemeColor.accent,
                                    fontSize: 18.0,
                                  ),
                                ),
                                const SizedBox(height: 5.0),
                                const Text(
                                  'Consultation record, Medical certificates, Prescriptions',
                                  style: const TextStyle(
                                    color: ThemeColor.secondary,
                                    fontSize: 13.0,
                                  ),
                                ),
                                const Spacer(),
                                const Align(
                                  alignment: Alignment.centerRight,
                                  child: const Icon(
                                    LineIcons.arrowRight,
                                    color: ThemeColor.secondary,
                                    size: 20.0,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 20.0),
              SizedBox(
                width: double.maxFinite,
                height: 100.0,
                child: Material(
                  elevation: 5.0,
                  borderRadius: BorderRadius.circular(8.0),
                  color: ThemeColor.background,
                  shadowColor: ThemeColor.shadow.withOpacity(0.35),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(8.0),
                    onTap: () => openRecords(MedicalRecordsType.laboratory),
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Icon(
                            LineIcons.flask,
                            size: 60.0,
                            color: ThemeColor.accent,
                          ),
                          const SizedBox(width: 10.0),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const SizedBox(height: 5.0),
                                const Text(
                                  'Laboratory Results',
                                  style: const TextStyle(
                                    fontWeight: FontWeight.bold,
                                    color: ThemeColor.accent,
                                    fontSize: 18.0,
                                  ),
                                ),
                                const SizedBox(height: 5.0),
                                const Text(
                                  'Urinalysis, Fecalysis, Drug test, Rapid test, Swab test',
                                  style: const TextStyle(
                                    color: ThemeColor.secondary,
                                    fontSize: 13.0,
                                  ),
                                ),
                                const Spacer(),
                                const Align(
                                  alignment: Alignment.centerRight,
                                  child: const Icon(
                                    LineIcons.arrowRight,
                                    color: ThemeColor.secondary,
                                    size: 20.0,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 20.0),
              SizedBox(
                width: double.maxFinite,
                height: 100.0,
                child: Material(
                  elevation: 5.0,
                  borderRadius: BorderRadius.circular(8.0),
                  color: ThemeColor.background,
                  shadowColor: ThemeColor.shadow.withOpacity(0.35),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(8.0),
                    onTap: () => openRecords(MedicalRecordsType.radiology),
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Icon(
                            LineIcons.xRay,
                            size: 60.0,
                            color: ThemeColor.accent,
                          ),
                          const SizedBox(width: 10.0),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const SizedBox(height: 5.0),
                                const Text(
                                  'Radiology Results',
                                  style: const TextStyle(
                                    fontWeight: FontWeight.bold,
                                    color: ThemeColor.accent,
                                    fontSize: 18.0,
                                  ),
                                ),
                                const SizedBox(height: 5.0),
                                const Text(
                                  'X-Ray, ECG, Ultrasound images',
                                  style: const TextStyle(
                                    color: ThemeColor.secondary,
                                    fontSize: 13.0,
                                  ),
                                ),
                                const Spacer(),
                                const Align(
                                  alignment: Alignment.centerRight,
                                  child: const Icon(
                                    LineIcons.arrowRight,
                                    color: ThemeColor.secondary,
                                    size: 20.0,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 30.0),
            ],
          ),
        ),
      ),
    );
  }

  void openRecords(MedicalRecordsType type) {
    Navigator.push(
      context,
      CupertinoPageRoute(
        builder: (_) {
          return BlocProvider(
            create: (_) => RecordListBloc(),
            child: PatientPageRecordViewer(
              type: type,
            ),
          );
        },
      ),
    );
  }
}
