import 'package:clinick/models/upload_item_model.dart';
import 'package:equatable/equatable.dart';

abstract class RecordListEvent extends Equatable {
  const RecordListEvent();

  @override
  List<Object> get props => [];
}

class RecordListEventRequest extends RecordListEvent {
  final MedicalRecordsType type;
  const RecordListEventRequest({required this.type});
}
