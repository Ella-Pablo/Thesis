import 'package:clinick/config/app_config.dart';
import 'package:clinick/config/color.dart';
import 'package:clinick/database/app_firebase.dart';
import 'package:clinick/models/appointment_model.dart';
import 'package:clinick/patient/views/tabs/appointments/blocs/appointment_bloc/bloc.dart';
import 'package:clinick/patient/views/tabs/appointments/blocs/appointment_bloc/states.dart';
import 'package:clinick/patient/views/tabs/appointments/event_item_template.dart';
import 'package:clinick/repository/paypal/paypal_payment.dart';
import 'package:clinick/widgets/state_view_template.dart';
import 'package:clinick/widgets/toast.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:line_icons/line_icons.dart';

class PatientTabPayments extends StatefulWidget {
  @override
  _PatientTabPaymentsState createState() => _PatientTabPaymentsState();
}

class _PatientTabPaymentsState extends State<PatientTabPayments> {
  final String returnURL = 'return.example.com';
  final String cancelURL = 'cancel.example.com';
  final Map<dynamic, dynamic> defaultCurrency = {
    "symbol": "PHP ",
    "decimalDigits": 2,
    "symbolBeforeTheNumber": true,
    "currency": "PHP",
  };

  void requestPayment(AppointmentModel model) async {
    final List items = [
      {
        "name": AppConfig.appointment_type[model.type],
        "quantity": 1,
        "price": AppConfig.appointment_price[model.type]?.replaceAll("PHP ", "") ?? '0.0',
        "currency": defaultCurrency["currency"],
      },
    ];

    String totalAmount = AppConfig.appointment_price[model.type]?.replaceAll("PHP ", "") ?? '0.0';

    final Map<String, dynamic> _toPurchase = {
      "intent": "sale",
      "payer": {"payment_method": "paypal"},
      "transactions": [
        {
          "amount": {
            "total": totalAmount,
            "currency": defaultCurrency["currency"],
            "details": {"subtotal": totalAmount, "shipping": '0', "shipping_discount": "0"}
          },
          "description": "Payment for ${AppConfig.appointment_type[model.type]}",
          "payment_options": {"allowed_payment_method": "INSTANT_FUNDING_SOURCE"},
          "item_list": {
            "items": items,
          }
        }
      ],
      "redirect_urls": {"return_url": returnURL, "cancel_url": cancelURL}
    };

    Navigator.of(context)
        .push(
      CupertinoPageRoute(
        builder: (BuildContext context) => PaypalPayment(
          toPurchase: _toPurchase,
        ),
      ),
    )
        .then(
      (value) async {
        if (value != null) {
          if (value) {
            await onSuccessfulPayment(model.id!);
          }
        }
      },
    );
  }

  Future<void> onSuccessfulPayment(String id) async {
    await AppFirebase.firestore.collection('appointments').doc(id).set(
      {
        'status': AppointmentStatus.paid.index,
      },
      SetOptions(merge: true),
    );

    toastGeneral("Payment Successful");
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(15.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 10),
              Material(
                elevation: 5.0,
                borderRadius: BorderRadius.circular(15.0),
                color: ThemeColor.background,
                shadowColor: ThemeColor.shadow.withOpacity(0.35),
                child: Padding(
                  padding: const EdgeInsets.all(15.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Pending Payments',
                        style: const TextStyle(
                          color: ThemeColor.accent,
                          fontSize: 25.0,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 5),
                      Text(
                        "Appointments marked as pending are not yet registered to our system. You must settle the corresponding fee to finalize your schedule.",
                        textAlign: TextAlign.justify,
                        style: const TextStyle(
                          color: ThemeColor.secondary,
                          fontSize: 14.0,
                        ),
                      ),
                      const SizedBox(height: 15.0),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Icon(
                            LineIcons.infoCircle,
                            size: 20.0,
                            color: ThemeColor.accent,
                          ),
                          const SizedBox(width: 5.0),
                          const Expanded(
                            child: const Text(
                              'We utilize Paypal to process the transaction of our application. This means that any bank card can be used, or make a paypal account for more option.',
                              textAlign: TextAlign.justify,
                              style: const TextStyle(
                                fontSize: 12.0,
                                color: ThemeColor.secondary,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10.0),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 15.0),
              Material(
                elevation: 5.0,
                borderRadius: BorderRadius.circular(8.0),
                color: ThemeColor.background,
                shadowColor: ThemeColor.shadow.withOpacity(0.35),
                child: Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: Row(
                    children: [
                      const Icon(
                        LineIcons.handPointingUp,
                        size: 20.0,
                        color: ThemeColor.accent,
                      ),
                      const SizedBox(width: 5.0),
                      const Expanded(
                        child: const Text(
                          'Click the appointment you want to pay.',
                          style: const TextStyle(
                            fontSize: 13.0,
                            color: ThemeColor.secondary,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 15.0),
              Expanded(
                child: BlocBuilder<PatientAppointmentBloc, PatientAppointmentState>(
                  builder: (context, state) {
                    if (state is PatientAppointmentStateInProgress) {
                      return const Center(
                        child: const CircularProgressIndicator(
                          valueColor: AlwaysStoppedAnimation(
                            ThemeColor.accent,
                          ),
                        ),
                      );
                    } else if (state is PatientAppointmentStateFailed) {
                      final double w = MediaQuery.of(context).size.width;
                      return SingleChildScrollView(
                        physics: const BouncingScrollPhysics(parent: const AlwaysScrollableScrollPhysics()),
                        child: Column(
                          children: [
                            StateView(
                              title: 'Sorry for the trouble!',
                              message:
                                  "We encountered an error while trying to fetch your pending appointments. Try to restart the applicaiton.",
                              assetPath: AppConfig.asset_failedImage,
                              imageSize: Size(w * 0.55, w * 0.45),
                            )
                          ],
                        ),
                      );
                    } else if (state is PatientAppointmentStateSuccess) {
                      final List<AppointmentModel> _finalList =
                          state.appointments.where((e) => e.status == AppointmentStatus.pending).toList();
                      if (_finalList.isNotEmpty) {
                        return ListView.builder(
                          physics: const BouncingScrollPhysics(parent: const AlwaysScrollableScrollPhysics()),
                          itemCount: _finalList.length,
                          itemBuilder: (context, index) {
                            return PatientEventItemTemplate(
                              model: _finalList[index],
                              showPrice: true,
                              margin: const EdgeInsets.symmetric(vertical: 5.0),
                              onClick: () => requestPayment(_finalList[index]),
                            );
                          },
                        );
                      }
                    }

                    final double w = MediaQuery.of(context).size.width;
                    return SingleChildScrollView(
                      physics: const BouncingScrollPhysics(parent: const AlwaysScrollableScrollPhysics()),
                      child: Column(
                        children: [
                          StateView(
                            title: 'Nothing to see here!',
                            message: "go to homepage and find the best doctor for you and schedule an appointment.",
                            assetPath: AppConfig.asset_emptyImage,
                            imageSize: Size(w * 0.55, w * 0.45),
                          )
                        ],
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
