import 'package:clinick/config/app_config.dart';
import 'package:clinick/config/color.dart';
import 'package:clinick/models/appointment_model.dart';
import 'package:clinick/patient/views/tabs/appointments/blocs/history_bloc/bloc.dart';
import 'package:clinick/patient/views/tabs/appointments/blocs/history_bloc/states.dart';
import 'package:clinick/patient/views/tabs/appointments/event_item_template.dart';
import 'package:clinick/widgets/state_view_template.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class AppointmentHistory extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return BlocBuilder<PatientHistoryBloc, PatientHistoryState>(
      builder: (context, state) {
        if (state is PatientHistoryStateInProgress) {
          return const SizedBox(
            height: 120.0,
            child: Center(
              child: const CircularProgressIndicator(
                valueColor: AlwaysStoppedAnimation(ThemeColor.accent),
              ),
            ),
          );
        } else if (state is PatientHistoryStateSuccess) {
          if (state.history.isNotEmpty) {
            double _height = 335.0;
            if (state.history.length < 4) {
              _height = 85.0 * state.history.length;
            }

            return SizedBox(
              height: _height + 30,
              child: ListView.builder(
                physics: const NeverScrollableScrollPhysics(),
                padding: const EdgeInsets.all(15.0),
                itemCount: state.history.length > 4 ? 4 : state.history.length,
                itemBuilder: (_, index) {
                  final AppointmentModel _model = state.history[index];
                  return PatientEventItemTemplate(
                    model: _model,
                    margin: const EdgeInsets.symmetric(vertical: 5.0),
                  );
                },
              ),
            );
          }
        } else if (state is PatientHistoryStateFailed) {
          return failedView(context);
        }

        return emptyView(context);
      },
    );
  }

  Widget failedView(BuildContext context) {
    final double w = MediaQuery.of(context).size.width;
    return SliverToBoxAdapter(
      child: SizedBox(
        height: 250.0,
        child: StateView(
          title: 'Sorry for the inconvenience!',
          message: 'We encountered an error while trying to fetch your appointments. Try to restart the app.',
          assetPath: AppConfig.asset_failedImage,
          imageSize: Size(w * 0.55, w * 0.45),
        ),
      ),
    );
  }

  Widget emptyView(BuildContext context) {
    final double w = MediaQuery.of(context).size.width;
    return SliverToBoxAdapter(
      child: SizedBox(
        height: 250.0,
        child: StateView(
          title: 'Nothing to see here!',
          message: 'Your past appointments will appear her.',
          assetPath: AppConfig.asset_emptyImage,
          imageSize: Size(w * 0.55, w * 0.45),
        ),
      ),
    );
  }
}
