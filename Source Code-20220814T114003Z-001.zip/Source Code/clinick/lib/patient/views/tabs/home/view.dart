import 'package:badges/badges.dart';
import 'package:clinick/blocs/base/view_event.dart';
import 'package:clinick/blocs/base/view_state.dart';
import 'package:clinick/blocs/messaging/list/bloc.dart';
import 'package:clinick/blocs/messaging/list/events.dart';
import 'package:clinick/blocs/messaging/list/states.dart';
import 'package:clinick/blocs/news_bloc/bloc.dart';
import 'package:clinick/config/app_config.dart';
import 'package:clinick/config/color.dart';
import 'package:clinick/database/app_firebase.dart';
import 'package:clinick/database/shared_pref.dart';
import 'package:clinick/models/appointment_model.dart';
import 'package:clinick/patient/views/pages/covidtrackers/blocs/bloc.dart';
import 'package:clinick/patient/views/pages/covidtrackers/blocs/events.dart';
import 'package:clinick/patient/views/pages/covidtrackers/blocs/states.dart';
import 'package:clinick/patient/views/pages/covidtrackers/view.dart';
import 'package:clinick/patient/views/pages/messages/view.dart';
import 'package:clinick/patient/views/pages/profile/profile_state_cubit.dart';
import 'package:clinick/patient/views/pages/profile/editing_state_cubit.dart';
import 'package:clinick/patient/views/pages/profile/view.dart';
import 'package:clinick/patient/views/pages/schedules/blocs/bloc.dart';
import 'package:clinick/patient/views/pages/schedules/view.dart';
import 'package:clinick/patient/views/pages/search/blocs/bloc.dart';
import 'package:clinick/patient/views/pages/tracker/blocs/bloc.dart';
import 'package:clinick/patient/views/pages/tracker/blocs/events.dart';
import 'package:clinick/patient/views/pages/tracker/view.dart';
import 'package:clinick/patient/views/tabs/appointments/blocs/history_bloc/bloc.dart';
import 'package:clinick/patient/views/tabs/appointments/blocs/history_bloc/events.dart';
import 'package:clinick/repository/helpers.dart';
import 'package:clinick/views/qr_code.dart';
import 'package:clinick/patient/views/pages/search/view.dart';
import 'package:clinick/patient/views/pages/services.dart';
import 'package:clinick/patient/views/tabs/appointments/blocs/appointment_bloc/bloc.dart';
import 'package:clinick/patient/views/tabs/appointments/blocs/appointment_bloc/states.dart';
import 'package:clinick/patient/views/tabs/home/history.dart';
import 'package:clinick/views/about_us.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:intro_slider/intro_slider.dart';
import 'package:intro_slider/slide_object.dart';
import 'package:line_icons/line_icons.dart';

import '../../../../widgets/news_templates.dart';
import '../../../../widgets/shortcuts_templates.dart';

class PatientTabHome extends StatefulWidget {
  const PatientTabHome();

  @override
  _PatientTabHomeState createState() => _PatientTabHomeState();
}

class _PatientTabHomeState extends State<PatientTabHome> {
  TextEditingController _txtController = TextEditingController();
  bool isSearchByDoctorName = true;
  bool runTutorial = false;

  void checkIfRunTutorial() async {
    runTutorial = !await SharedPrefs.instance.getInitialRun();
    if (runTutorial) {
      runTutorial = false;
      await Future.delayed(const Duration(seconds: 2));
      Helpers.changeStatusBarTheme(ThemeMode.light);

      Navigator.push(
        context,
        CupertinoPageRoute(
          builder: (context) {
            return IntroSlider(
              slides: [
                Slide(
                  title: "Getting Started",
                  description: "Find the name of your doctor using the search box found at the Home Tab.",
                  centerWidget: Image.asset(
                    "assets/images/tut1.jpg",
                    fit: BoxFit.fill,
                    width: MediaQuery.of(context).size.width - 50,
                  ),
                  backgroundColor: ThemeColor.accent,
                ),
                Slide(
                  title: "Request Appointment",
                  description:
                      "Request an appointment from your doctor through messaging. A notification will pop up once an appointment has been created.",
                  centerWidget: Image.asset(
                    "assets/images/tut2.jpg",
                    fit: BoxFit.fill,
                    width: MediaQuery.of(context).size.width - 50,
                  ),
                  foregroundImageFit: BoxFit.fill,
                  backgroundColor: ThemeColor.accent,
                ),
                Slide(
                  title: "Online Payment",
                  description:
                      "To complete the process, you have to settle the amount through our online payment gateway.",
                  centerWidget: Image.asset(
                    "assets/images/tut3.jpg",
                    fit: BoxFit.fill,
                    width: MediaQuery.of(context).size.width - 50,
                  ),
                  backgroundColor: ThemeColor.accent,
                )
              ],
              onDonePress: () {
                Navigator.of(context).pop();
                Helpers.changeStatusBarTheme(ThemeMode.dark);
                SharedPrefs.instance.saveInitialRun();
              },
            );
          },
        ),
      );
    }
  }

  @override
  void initState() {
    Helpers.changeStatusBarTheme(ThemeMode.dark);
    BlocProvider.of<NewsBloc>(context).add(NewsEventRequest());
    BlocProvider.of<PatientHistoryBloc>(context).add(PatientHistoryEventRequest());
    BlocProvider.of<MessageInfoBloc>(context).add(MessageInfoEventRequest());
    BlocProvider.of<PatientTrackerBloc>(context).add(PatientTrackerEventRequest());
    BlocProvider.of<CovidTrackerBloc>(context).add(CovidTrackerEventRequest());
    checkIfRunTutorial();
    super.initState();
  }

  @override
  void dispose() {
    _txtController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 15.0),
              Row(
                children: [
                  const SizedBox(width: 15.0),
                  Container(
                    height: 40.0,
                    width: 40.0,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                          spreadRadius: 1.0,
                          blurRadius: 4.0,
                          color: ThemeColor.shadow.withOpacity(0.25),
                          offset: Offset(0, 0),
                        )
                      ],
                    ),
                    clipBehavior: Clip.antiAlias,
                    child: Material(
                      color: ThemeColor.background,
                      clipBehavior: Clip.antiAlias,
                      child: IconButton(
                        tooltip: "Edit Information or Logout",
                        onPressed: () {
                          Navigator.push(
                            context,
                            CupertinoPageRoute(
                              builder: (context) {
                                return MultiBlocProvider(
                                  providers: [
                                    BlocProvider(create: (_) => ProfileStateCubit()),
                                    BlocProvider(create: (_) => EditingStateCubit()),
                                  ],
                                  child: PatientPageProfile(),
                                );
                              },
                            ),
                          );
                        },
                        icon: const Icon(
                          LineIcons.user,
                          color: ThemeColor.secondary2,
                        ),
                      ),
                    ),
                  ),
                  const Spacer(),
                  const Text(
                    'CLinicK',
                    style: const TextStyle(
                      color: ThemeColor.accent,
                      fontWeight: FontWeight.w900,
                      fontSize: 23.0,
                    ),
                  ),
                  const Spacer(),
                  BlocBuilder<MessageInfoBloc, MessageInfoState>(
                    builder: (_, state) {
                      int _count = 0;
                      if (state is MessageInfoStateSuccess) {
                        _count = state.newMessages;
                      }
                      return Badge(
                        badgeColor: ThemeColor.accent,
                        shape: BadgeShape.circle,
                        position: BadgePosition.bottomStart(bottom: -4.0, start: -2.0),
                        badgeContent: Text(
                          '$_count',
                          style: const TextStyle(
                            fontSize: 8.0,
                            color: ThemeColor.background,
                          ),
                        ),
                        showBadge: _count > 0,
                        child: Container(
                          height: 40.0,
                          width: 40.0,
                          decoration: BoxDecoration(
                            color: ThemeColor.background,
                            shape: BoxShape.circle,
                            boxShadow: [
                              BoxShadow(
                                spreadRadius: 1.0,
                                blurRadius: 4.0,
                                color: ThemeColor.shadow.withOpacity(0.25),
                                offset: Offset(0, 0),
                              )
                            ],
                          ),
                          clipBehavior: Clip.antiAlias,
                          child: Material(
                            color: ThemeColor.background,
                            clipBehavior: Clip.antiAlias,
                            child: IconButton(
                              tooltip: "Messages",
                              onPressed: () {
                                Navigator.push(
                                  context,
                                  CupertinoPageRoute(
                                    builder: (_) {
                                      return BlocProvider.value(
                                        value: BlocProvider.of<MessageInfoBloc>(context),
                                        child: PatientPageMessages(),
                                      );
                                    },
                                  ),
                                );
                              },
                              icon: const Icon(
                                LineIcons.sms,
                                color: ThemeColor.secondary2,
                              ),
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                  const SizedBox(width: 15.0),
                ],
              ),
              const SizedBox(height: 40.0),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 17.0),
                child: const Text(
                  'Hello,',
                  style: const TextStyle(
                    color: ThemeColor.secondary2,
                    fontSize: 30.0,
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 15.0),
                child: Text(
                  '${AppFirebase.patientData!.firstName ?? ''}!',
                  style: const TextStyle(
                    color: ThemeColor.accent,
                    fontSize: 40.0,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
              const SizedBox(height: 20.0),
              SizedBox(
                width: double.maxFinite,
                height: 55.0,
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 15.0),
                  child: Material(
                    elevation: 12.0,
                    borderRadius: BorderRadius.circular(25.0),
                    color: ThemeColor.background,
                    shadowColor: ThemeColor.shadow.withOpacity(0.35),
                    child: Padding(
                      padding: const EdgeInsets.all(5.0),
                      child: Center(
                        child: TextField(
                          controller: _txtController,
                          decoration: const InputDecoration(
                            contentPadding: const EdgeInsets.fromLTRB(15.0, 11.0, 15.0, 10.0),
                            hintText: 'Find a Specialist',
                            hintStyle: const TextStyle(
                              color: ThemeColor.inputHint,
                              fontSize: 16.0,
                            ),
                            enabledBorder: InputBorder.none,
                            focusedBorder: InputBorder.none,
                            prefixIcon: const Icon(
                              LineIcons.search,
                              color: ThemeColor.secondary2,
                            ),
                          ),
                          style: const TextStyle(
                            fontSize: 17.0,
                            color: ThemeColor.secondary,
                          ),
                          onSubmitted: (text) {
                            FocusScope.of(context).requestFocus(FocusNode());
                            Navigator.push(
                              context,
                              CupertinoPageRoute(
                                builder: (context) {
                                  return BlocProvider(
                                      create: (_) => SearchDoctorBloc(),
                                      child: PatientPageSearch(
                                        initialKeyword: text,
                                        isSearchByDoctorName: isSearchByDoctorName,
                                      ));
                                },
                              ),
                            ).then((value) {
                              isSearchByDoctorName = value ?? false;
                              _txtController.clear();
                            });
                          },
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              notifBanner(),
              const Padding(
                padding: const EdgeInsets.symmetric(horizontal: 15.0),
                child: const Text(
                  'What do you need',
                  style: const TextStyle(
                    fontSize: 19.0,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
              const SizedBox(height: 10.0),
              shortcutGrid(),
              SizedBox(
                height: 24.0,
                child: Row(
                  children: [
                    const SizedBox(width: 15.0),
                    Text(
                      'Latest Medical News',
                      style: const TextStyle(
                        fontSize: 19.0,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    IconButton(
                      icon: const Icon(LineIcons.syncIcon),
                      padding: EdgeInsets.zero,
                      iconSize: 16.0,
                      splashRadius: 16.0,
                      color: ThemeColor.accent,
                      onPressed: () => BlocProvider.of<NewsBloc>(context).add(NewsEventRefresh()),
                    )
                  ],
                ),
              ),
              newsList(),
              newsListFooter(),
              const SizedBox(height: 20.0),
              SizedBox(
                height: 24.0,
                child: Row(
                  children: [
                    const SizedBox(width: 15.0),
                    Text(
                      'History',
                      style: const TextStyle(
                        fontSize: 19.0,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    IconButton(
                      icon: const Icon(LineIcons.syncIcon),
                      padding: EdgeInsets.zero,
                      iconSize: 16.0,
                      splashRadius: 16.0,
                      color: ThemeColor.accent,
                      onPressed: () => BlocProvider.of<PatientHistoryBloc>(context).add(PatientHistoryEventRefresh()),
                    )
                  ],
                ),
              ),
              AppointmentHistory(),
              const SizedBox(height: 15.0),
            ],
          ),
        ),
      ),
    );
  }

  Widget shortcutGrid() {
    return SizedBox(
      height: 270.0,
      width: double.maxFinite,
      child: GridView(
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 3,
          mainAxisSpacing: 15.0,
          crossAxisSpacing: 15.0,
        ),
        physics: const NeverScrollableScrollPhysics(),
        padding: const EdgeInsets.symmetric(vertical: 15.0, horizontal: 25.0),
        children: [
          ShortcutItem(
            title: "Schedules",
            tooltip: "Weekly Schedule of our Medical Staffs",
            icon: LineIcons.calendarCheck,
            builder: BlocProvider(
              create: (_) => ScheduleListBloc(),
              child: PatientPageSchedules(),
            ),
          ),
          ShortcutItem(
            title: "Services",
            tooltip: "List of Available Services",
            icon: LineIcons.firstAid,
            builder: PatientPageServices(),
          ),
          ShortcutItem(
            title: "My QR-Code",
            tooltip: "Show Auto-generated QR-Code",
            icon: LineIcons.qrcode,
            builder: PageQRCode(
              qrData: {
                "id": AppFirebase.uid(),
                "name": AppFirebase.patientData?.fullName ?? "No Name",
              },
            ),
            isCupertino: false,
          ),
          BlocBuilder<CovidTrackerBloc, CovidTrackerState>(
            builder: (_, state) {
              bool _show = false;
              if (state is CovidTrackerStateSuccess) {
                _show = state.puiTracker != null;
              }

              return ShortcutItem(
                title: "Contact Tracing",
                tooltip: "Contact Tracing",
                icon: LineIcons.mapMarker,
                isAccent: _show,
                builder: BlocProvider.value(
                  value: BlocProvider.of<CovidTrackerBloc>(context),
                  child: PatientPageCovidTracker(),
                ),
              );
            },
          ),
          ShortcutItem(
            title: "Medication",
            tooltip: "Track your Medications",
            icon: LineIcons.prescriptionBottle,
            builder: BlocProvider.value(
              value: BlocProvider.of<PatientTrackerBloc>(context),
              child: PatientPageMedicationTracker(),
            ),
          ),
          ShortcutItem(
            title: "About Us",
            tooltip: "Learn more About Us",
            icon: LineIcons.medicalClinic,
            builder: PageAboutUs(),
          ),
        ],
      ),
    );
  }

  Widget newsList() {
    return BlocBuilder<NewsBloc, ViewState>(
      builder: (context, state) {
        if (state is NewsStateSuccess) {
          if (state.isFailure) {
            return NewsListFailure(
              tryAgain: () {
                BlocProvider.of<NewsBloc>(context).add(NewsEventRequest());
              },
            );
          }
        }

        return SizedBox(
          height: 460,
          child: ListView.builder(
            itemCount: 4,
            physics: const NeverScrollableScrollPhysics(),
            padding: const EdgeInsets.symmetric(horizontal: 15.0, vertical: 10.0),
            itemBuilder: (context, index) {
              if (state is NewsStateSuccess) {
                return NewsListItem(model: state.list![index]);
              }
              return const NewsListItemShimmer();
            },
          ),
        );
      },
    );
  }

  Widget newsListFooter() {
    return SizedBox(
      height: 20.0,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Text(
            'Powered by ',
            style: const TextStyle(
              fontSize: 12.5,
              color: ThemeColor.secondary2,
            ),
          ),
          const SizedBox(width: 10.0),
          Image.asset(
            'assets/images/logo_mnt.png',
            fit: BoxFit.fill,
            cacheWidth: 100,
            width: 50.0,
          ),
        ],
      ),
    );
  }

  Widget notifBanner() {
    return BlocBuilder<PatientAppointmentBloc, PatientAppointmentState>(
      builder: (context, state) {
        AppointmentModel? _model;
        if (state is PatientAppointmentStateFailed || state is PatientAppointmentStateInProgress) {
          return const SizedBox(height: 60.0);
        } else if (state is PatientAppointmentStateSuccess) {
          if (state.appointments.isNotEmpty) {
            _model = state.appointments.first;
          }
        }

        String _title = "You have no appointment for today!";
        String _msg = "Your nearest appointment schedule will show here.";

        if (_model != null) {
          _title = "Appointment on ${_model.dateString}";
          _msg = "The specialist in charge for your ${AppConfig.appointment_type[_model.type]} is ${_model.staffName}.";
        }

        return Padding(
          padding: const EdgeInsets.fromLTRB(15.0, 40.0, 15.0, 40.0),
          child: Material(
            elevation: 5.0,
            borderRadius: BorderRadius.circular(15.0),
            color: ThemeColor.background,
            shadowColor: ThemeColor.shadow.withOpacity(0.85),
            child: Container(
              width: double.maxFinite,
              height: 135.0,
              decoration: BoxDecoration(
                color: ThemeColor.accent,
                borderRadius: BorderRadius.circular(15.0),
                gradient: const LinearGradient(
                  colors: [
                    Color.fromARGB(255, 186, 48, 48),
                    ThemeColor.accent,
                  ],
                  begin: Alignment.bottomRight,
                  end: Alignment.topLeft,
                ),
              ),
              padding: const EdgeInsets.all(15.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    _title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: ThemeColor.buttonTextColor,
                      fontSize: 16.0,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 5.0),
                  Expanded(
                    child: Row(
                      children: [
                        const SizedBox(width: 10.0),
                        const Icon(
                          CupertinoIcons.bell_fill,
                          color: Colors.white,
                          size: 55.0,
                        ),
                        const SizedBox(width: 20.0),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const SizedBox(height: 5.0),
                              Text(
                                _msg,
                                maxLines: 3,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                  color: Colors.white.withAlpha(200),
                                  fontSize: 14.0,
                                ),
                              ),
                              const Spacer(),
                              const Align(
                                alignment: Alignment.bottomRight,
                                child: const Icon(
                                  LineIcons.arrowRight,
                                  size: 24.0,
                                  color: Colors.white,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
