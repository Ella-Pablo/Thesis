import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';

abstract class PatientAppointmentEvent extends Equatable {
  const PatientAppointmentEvent();

  @override
  List<Object> get props => [];
}

class PatientAppointmentEventRequest extends PatientAppointmentEvent {
  final BuildContext context;
  const PatientAppointmentEventRequest({required this.context});
}
