import 'package:clinick/config/app_config.dart';
import 'package:clinick/config/color.dart';
import 'package:clinick/config/labels.dart';
import 'package:clinick/models/appointment_model.dart';
import 'package:flutter/material.dart';
import 'package:line_icons/line_icons.dart';

class PatientEventItemTemplate extends StatelessWidget {
  const PatientEventItemTemplate({
    required this.model,
    required this.margin,
    this.onClick,
    this.showPrice = false,
  });
  final AppointmentModel model;
  final EdgeInsetsGeometry margin;
  final Function? onClick;
  final bool showPrice;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: margin,
      child: Material(
        elevation: 5.0,
        borderRadius: BorderRadius.circular(8.0),
        color: ThemeColor.background,
        shadowColor: ThemeColor.shadow.withOpacity(0.35),
        child: onClick == null
            ? body(context)
            : InkWell(
                onTap: () => onClick!(),
                borderRadius: BorderRadius.circular(8.0),
                child: body(context),
              ),
      ),
    );
  }

  Widget body(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(15.0, 10.0, 15.0, 10.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          showPrice
              ? Row(
                  children: [
                    Expanded(
                      child: Tooltip(
                        message: AppConfig.appointment_type[model.type ?? 0]!,
                        child: Text(
                          AppConfig.appointment_type[model.type ?? 0]!,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            fontSize: 16.0,
                            fontWeight: FontWeight.bold,
                            color: ThemeColor.accent,
                          ),
                        ),
                      ),
                    ),
                    Text(
                      AppConfig.appointment_price[model.type ?? 0]!,
                      style: const TextStyle(
                        fontSize: 11.0,
                        color: ThemeColor.accent,
                      ),
                    ),
                  ],
                )
              : status(model.status ?? AppointmentStatus.unknown),
          Row(
            children: [
              Icon(
                LineIcons.alternateUser,
                color: ThemeColor.accent,
                size: 16.0,
              ),
              const SizedBox(width: 5.0),
              Text(
                model.staffName ?? Labels.default_no_name_staff,
                style: const TextStyle(
                  fontSize: 14.0,
                  color: ThemeColor.secondary2,
                ),
              ),
            ],
          ),
          const SizedBox(height: 5.0),
          Row(
            children: [
              Icon(
                LineIcons.businessTime,
                color: ThemeColor.accent,
                size: 16.0,
              ),
              const SizedBox(width: 5.0),
              Text(
                "${model.dateString}  -  ${model.start!.format(context)} to ${model.end!.format(context)}",
                style: const TextStyle(
                  fontSize: 12.0,
                  color: ThemeColor.secondary,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget status(AppointmentStatus status) {
    if (status == AppointmentStatus.pending) {
      return Row(
        children: [
          Expanded(
            child: Text(
              AppConfig.appointment_type[model.type ?? 0]!,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                fontSize: 16.0,
                fontWeight: FontWeight.bold,
                color: ThemeColor.accent,
              ),
            ),
          ),
          Text(
            "pending",
            style: const TextStyle(
              fontSize: 11.0,
              color: ThemeColor.accent,
              fontStyle: FontStyle.italic,
            ),
          ),
        ],
      );
    } else if (status == AppointmentStatus.paid) {
      return Row(
        children: [
          Text(
            AppConfig.appointment_type[model.type ?? 0]!,
            style: const TextStyle(
              fontSize: 16.0,
              fontWeight: FontWeight.bold,
              color: ThemeColor.accent,
            ),
          ),
          const Spacer(),
          Text(
            "waiting for schedule",
            style: const TextStyle(
              fontSize: 11.0,
              color: ThemeColor.secondary,
              fontStyle: FontStyle.italic,
            ),
          ),
        ],
      );
    } else {
      return Text(
        AppConfig.appointment_type[model.type ?? 0]!,
        style: const TextStyle(
          fontSize: 16.0,
          fontWeight: FontWeight.bold,
          color: ThemeColor.accent,
        ),
      );
    }
  }
}
