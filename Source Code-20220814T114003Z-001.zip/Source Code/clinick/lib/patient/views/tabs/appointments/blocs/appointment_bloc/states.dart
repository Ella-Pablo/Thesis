import 'package:clinick/models/appointment_model.dart';
import 'package:equatable/equatable.dart';

abstract class PatientAppointmentState extends Equatable {
  const PatientAppointmentState();

  @override
  List<Object> get props => [];
}

class PatientAppointmentStateEmpty extends PatientAppointmentState {}

class PatientAppointmentStateInProgress extends PatientAppointmentState {}

class PatientAppointmentStateSuccess extends PatientAppointmentState {
  final List<AppointmentModel> appointments;
  final bool refresher;
  const PatientAppointmentStateSuccess({required this.appointments, required this.refresher});

  @override
  List<Object> get props => [appointments, refresher];
}

class PatientAppointmentStateFailed extends PatientAppointmentState {}
