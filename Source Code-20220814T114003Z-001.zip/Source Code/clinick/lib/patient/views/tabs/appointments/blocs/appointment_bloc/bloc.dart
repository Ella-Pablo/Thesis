import 'dart:async';

import 'package:clinick/database/app_firebase.dart';
import 'package:clinick/models/appointment_model.dart';
import 'package:clinick/repository/notifications.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../appointment_bloc/events.dart';
import '../appointment_bloc/states.dart';

class PatientAppointmentBloc extends Bloc<PatientAppointmentEvent, PatientAppointmentState> {
  PatientAppointmentBloc() : super(PatientAppointmentStateInProgress());

  StreamSubscription? subscription;
  List<AppointmentModel> appointments = [];
  bool refresher = true;

  @override
  Stream<PatientAppointmentState> mapEventToState(PatientAppointmentEvent event) async* {
    if (event is PatientAppointmentEventRequest) {
      yield PatientAppointmentStateInProgress();
      await Future.delayed(Duration(seconds: 1));

      subscription?.cancel();
      subscription = AppFirebase.firestore
          .collection('appointments')
          .where("userid", isEqualTo: AppFirebase.uid())
          .snapshots()
          .listen(
        (dataEvent) async {
          try {
            appointments.clear();
            for (var item in dataEvent.docs) {
              final AppointmentModel _model = AppointmentModel.fromSnapshot(item.id, item.data());
              await LocalNotifs.checkAddAppointment(event.context, _model);
              appointments.add(_model);
            }

            if (appointments.isEmpty) {
              emit(
                PatientAppointmentStateEmpty(),
              );
              return;
            }

            appointments.sort((a, b) => a.date!.millisecondsSinceEpoch.compareTo(b.date!.millisecondsSinceEpoch));

            refresher = !refresher;

            emit(PatientAppointmentStateSuccess(
              appointments: appointments,
              refresher: refresher,
            ));
          } catch (ex) {
            //print(ex);
            emit(
              PatientAppointmentStateFailed(),
            );
          }
        },
      );
    }
  }

  @override
  Future<void> close() {
    subscription?.cancel();
    return super.close();
  }
}
