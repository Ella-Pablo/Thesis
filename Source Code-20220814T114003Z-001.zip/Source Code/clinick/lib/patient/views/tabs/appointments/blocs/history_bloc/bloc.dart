import 'dart:async';

import 'package:clinick/database/app_firebase.dart';
import 'package:clinick/models/appointment_model.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'events.dart';
import 'states.dart';

class PatientHistoryBloc extends Bloc<PatientHistoryEvent, PatientHistoryState> {
  PatientHistoryBloc() : super(PatientHistoryStateInProgress());

  List<AppointmentModel> history = [];
  bool refresher = true;

  @override
  Stream<PatientHistoryState> mapEventToState(PatientHistoryEvent event) async* {
    if (event is PatientHistoryEventRequest) {
      yield PatientHistoryStateInProgress();
    }

    try {
      QuerySnapshot _data = await AppFirebase.firestore
          .collection('history')
          .where("userid", isEqualTo: AppFirebase.uid())
          .limit(4)
          .get();

      history.clear();

      for (var item in _data.docs) {
        history.add(AppointmentModel.fromSnapshot(item.id, item.data()));
      }

      if (history.isEmpty) {
        yield PatientHistoryStateEmpty();
        return;
      }

      history.sort((a, b) => b.date!.millisecondsSinceEpoch.compareTo(a.date!.millisecondsSinceEpoch));

      refresher = !refresher;

      yield PatientHistoryStateSuccess(
        history: history,
        refresher: refresher,
      );
    } catch (ex) {
      //print(ex);
      yield PatientHistoryStateFailed();
    }
  }
}
