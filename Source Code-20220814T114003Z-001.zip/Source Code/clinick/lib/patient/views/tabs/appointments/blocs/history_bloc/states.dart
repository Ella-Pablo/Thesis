import 'package:clinick/models/appointment_model.dart';
import 'package:equatable/equatable.dart';

abstract class PatientHistoryState extends Equatable {
  const PatientHistoryState();

  @override
  List<Object> get props => [];
}

class PatientHistoryStateEmpty extends PatientHistoryState {}

class PatientHistoryStateInProgress extends PatientHistoryState {}

class PatientHistoryStateSuccess extends PatientHistoryState {
  final List<AppointmentModel> history;
  final bool refresher;
  const PatientHistoryStateSuccess({required this.history, required this.refresher});

  @override
  List<Object> get props => [history, refresher];
}

class PatientHistoryStateFailed extends PatientHistoryState {}
