import 'package:clinick/config/app_config.dart';
import 'package:clinick/config/color.dart';
import 'package:clinick/models/appointment_model.dart';
import 'package:clinick/patient/views/tabs/appointments/event_item_template.dart';
import 'package:clinick/widgets/state_view_template.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:intl/intl.dart';
import 'package:line_icons/line_icons.dart';
import 'package:sliver_tools/sliver_tools.dart';
import 'package:table_calendar/table_calendar.dart';

import 'blocs/appointment_bloc/bloc.dart';
import 'blocs/appointment_bloc/events.dart';
import 'blocs/appointment_bloc/states.dart';

class PatientTabAppointments extends StatefulWidget {
  const PatientTabAppointments();
  _PatientTabAppointmentsState createState() => _PatientTabAppointmentsState();
}

class _PatientTabAppointmentsState extends State<PatientTabAppointments> {
  ValueNotifier<DateTime?> selectedDay = ValueNotifier(null);

  @override
  void initState() {
    BlocProvider.of<PatientAppointmentBloc>(context).add(PatientAppointmentEventRequest(context: context));
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: CustomScrollView(
          physics: const BouncingScrollPhysics(parent: const AlwaysScrollableScrollPhysics()),
          slivers: [
            const SliverToBoxAdapter(
              child: const SizedBox(height: 15.0),
            ),
            SliverPadding(
              padding: const EdgeInsets.symmetric(horizontal: 15.0),
              sliver: SliverToBoxAdapter(
                child: Material(
                  elevation: 5.0,
                  borderRadius: BorderRadius.circular(15.0),
                  color: ThemeColor.background,
                  shadowColor: ThemeColor.shadow.withOpacity(0.35),
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: ValueListenableBuilder<DateTime?>(
                      valueListenable: selectedDay,
                      builder: (_, value, __) {
                        return BlocBuilder<PatientAppointmentBloc, PatientAppointmentState>(
                          builder: (_, state) {
                            List<AppointmentModel> _list = [];
                            if (state is PatientAppointmentStateSuccess) {
                              _list.clear();
                              _list = state.appointments;
                            }
                            return TableCalendar(
                              focusedDay: value ?? DateTime.now(),
                              firstDay: DateTime(DateTime.now().year - 1),
                              lastDay: DateTime(DateTime.now().year + 1),
                              availableGestures: AvailableGestures.horizontalSwipe,
                              headerStyle: HeaderStyle(
                                titleCentered: true,
                                formatButtonVisible: false,
                              ),
                              calendarStyle: CalendarStyle(
                                todayDecoration: BoxDecoration(
                                  color: ThemeColor.accent.withOpacity(0.5),
                                  shape: BoxShape.circle,
                                ),
                                selectedDecoration: BoxDecoration(
                                  color: ThemeColor.accent,
                                  shape: BoxShape.circle,
                                ),
                                selectedTextStyle: const TextStyle(color: ThemeColor.buttonTextColor),
                              ),
                              calendarBuilders: CalendarBuilders(
                                markerBuilder: (context, day, events) {
                                  if (_list.isNotEmpty) {
                                    int _count = _list
                                        .where((e) => e.dateString == DateFormat('MMMM dd, yyyy').format(day))
                                        .length;
                                    if (_count > 0) {
                                      if (_count == 1) {
                                        return Container(
                                          width: 5.0,
                                          height: 5.0,
                                          decoration: BoxDecoration(
                                            shape: BoxShape.circle,
                                            color: ThemeColor.accent,
                                          ),
                                        );
                                      } else if (_count > 1) {
                                        final int _finalCount = _count > 3 ? 3 : _count;
                                        return Row(
                                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                            children: List.generate(_finalCount, (index) => index).map((e) {
                                              return Container(
                                                width: 5.0,
                                                height: 5.0,
                                                decoration: BoxDecoration(
                                                  shape: BoxShape.circle,
                                                  color: ThemeColor.accent,
                                                ),
                                              );
                                            }).toList());
                                      }
                                    }
                                  }
                                },
                              ),
                              selectedDayPredicate: (day) {
                                return isSameDay(value, day);
                              },
                              onDaySelected: (iSelectedDay, _) {
                                selectedDay.value = iSelectedDay;
                              },
                            );
                          },
                        );
                      },
                    ),
                  ),
                ),
              ),
            ),
            const SliverToBoxAdapter(
              child: const SizedBox(height: 20.0),
            ),
            SliverPadding(
              padding: const EdgeInsets.symmetric(horizontal: 15.0),
              sliver: SliverToBoxAdapter(
                child: Material(
                  elevation: 5.0,
                  borderRadius: BorderRadius.circular(15.0),
                  color: ThemeColor.background,
                  shadowColor: ThemeColor.shadow.withOpacity(0.35),
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(10.0, 15.0, 15.0, 15.0),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Icon(
                          LineIcons.infoCircle,
                          size: 20.0,
                          color: ThemeColor.accent,
                        ),
                        const SizedBox(width: 5.0),
                        const Expanded(
                          child: const Text(
                            'Please take note that appointments with pending status will automatically be removed if not settled within 24 hours.',
                            textAlign: TextAlign.justify,
                            style: const TextStyle(
                              fontSize: 12.0,
                              color: ThemeColor.secondary,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            const SliverToBoxAdapter(
              child: const SizedBox(height: 20.0),
            ),
            SliverPinnedHeader(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 15.0),
                child: Material(
                  elevation: 5.0,
                  borderRadius: BorderRadius.circular(8.0),
                  color: ThemeColor.accent,
                  shadowColor: ThemeColor.shadow.withOpacity(0.35),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 15.0, vertical: 3.0),
                    child: Row(
                      children: [
                        const Text(
                          'All Appointments',
                          style: const TextStyle(
                            color: ThemeColor.background,
                            fontSize: 16.0,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        const Spacer(),
                        IconButton(
                          tooltip: "Refresh Data",
                          icon: const Icon(
                            LineIcons.syncIcon,
                            color: ThemeColor.background,
                          ),
                          splashRadius: 24.0,
                          color: ThemeColor.background,
                          onPressed: () => BlocProvider.of<PatientAppointmentBloc>(context)
                              .add(PatientAppointmentEventRequest(context: context)),
                        ),
                        IconButton(
                          tooltip: "View All Appointments",
                          icon: const Icon(
                            LineIcons.borderAll,
                            color: ThemeColor.background,
                          ),
                          splashRadius: 24.0,
                          color: ThemeColor.background,
                          onPressed: () => selectedDay.value = null,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            const SliverToBoxAdapter(
              child: const SizedBox(height: 15.0),
            ),
            BlocBuilder<PatientAppointmentBloc, PatientAppointmentState>(
              builder: (context, state) {
                if (state is PatientAppointmentStateInProgress) {
                  return SliverToBoxAdapter(
                    child: const SizedBox(
                      height: 100.0,
                      child: Center(
                        child: const CircularProgressIndicator(
                          valueColor: AlwaysStoppedAnimation(ThemeColor.accent),
                        ),
                      ),
                    ),
                  );
                } else if (state is PatientAppointmentStateFailed) {
                  return failedView(context);
                } else if (state is PatientAppointmentStateSuccess) {
                  if (state.appointments.isNotEmpty) {
                    return ValueListenableBuilder<DateTime?>(
                      valueListenable: selectedDay,
                      builder: (_, value, __) {
                        final List<AppointmentModel> _finalList =
                            value != null ? getFilteredList(state.appointments) : state.appointments;

                        if (_finalList.isEmpty) return emptyView(context);

                        return SliverList(
                          delegate: SliverChildBuilderDelegate(
                            (_, index) {
                              final AppointmentModel _model = _finalList[index];
                              return PatientEventItemTemplate(
                                model: _model,
                                margin: const EdgeInsets.symmetric(vertical: 5.0, horizontal: 15.0),
                              );
                            },
                            childCount: _finalList.length,
                          ),
                        );
                      },
                    );
                  }
                }
                return emptyView(context);
              },
            ),
            const SliverToBoxAdapter(
              child: const SizedBox(height: 15.0),
            ),
          ],
        ),
      ),
    );
  }

  Widget failedView(BuildContext context) {
    final double w = MediaQuery.of(context).size.width;
    return SliverToBoxAdapter(
      child: SizedBox(
        height: 250.0,
        child: StateView(
          title: 'Sorry for the inconvenience!',
          message: 'We encountered an error while trying to fetch your appointments. Try to restart the app.',
          assetPath: AppConfig.asset_failedImage,
          imageSize: Size(w * 0.55, w * 0.45),
        ),
      ),
    );
  }

  Widget emptyView(BuildContext context) {
    final double w = MediaQuery.of(context).size.width;
    return SliverToBoxAdapter(
      child: SizedBox(
        height: 250.0,
        child: StateView(
          title: 'Nothing to see here!',
          message: 'Schedule an appointment today. Start by searching a specialist using the search bar above.',
          assetPath: AppConfig.asset_emptyImage,
          imageSize: Size(w * 0.55, w * 0.45),
        ),
      ),
    );
  }

  List<AppointmentModel> getFilteredList(List<AppointmentModel> appointments) {
    if (selectedDay.value == null) return appointments;
    return appointments
        .where((e) =>
            e.dateString ==
            DateFormat('MMMM dd, yyyy').format(
              selectedDay.value!,
            ))
        .toList();
  }
}
