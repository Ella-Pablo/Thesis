import 'package:clinick/blocs/messaging/list/bloc.dart';
import 'package:clinick/blocs/news_bloc/bloc.dart';
import 'package:clinick/config/color.dart';
import 'package:clinick/database/app_firebase.dart';
import 'package:clinick/patient/views/pages/covidtrackers/blocs/bloc.dart';
import 'package:clinick/patient/views/tabs/payments/view.dart';
import 'package:clinick/views/splash_screen.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'views/pages/auth/new_user_config.dart';
import 'views/pages/tracker/blocs/bloc.dart';
import 'views/tabs/appointments/blocs/appointment_bloc/bloc.dart';
import 'views/tabs/appointments/blocs/history_bloc/bloc.dart';
import 'views/tabs/appointments/view.dart';
import 'views/tabs/home/view.dart';
import 'views/tabs/records/view.dart';

class PatientView extends StatefulWidget {
  @override
  _PatientViewState createState() => _PatientViewState();
}

class _PatientViewState extends State<PatientView> {
  final Map<String, MapEntry<IconData, IconData>> navigationBarItems = {
    "Home": MapEntry(Icons.home_outlined, Icons.home),
    "Appointments": MapEntry(Icons.event_note_outlined, Icons.event_note),
    "Records": MapEntry(Icons.cloud_done_outlined, Icons.cloud_done),
    "Payments": MapEntry(Icons.payments_outlined, Icons.payments),
  };
  final ValueNotifier<int> selectedIndex = ValueNotifier(0);
  final PatientAppointmentBloc appointmentsBloc = PatientAppointmentBloc();
  bool forceSource = true;

  @override
  void initState() {
    forceSource = true;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<bool?>(
      initialData: null,
      future: AppFirebase.getPatientData(forceSource),
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return PageSplashScreen();
        } else if (snapshot.data == false) {
          return PatientPageNewUser();
        }

        forceSource = false;
        return ValueListenableBuilder<int>(
          valueListenable: selectedIndex,
          builder: (_, value, __) {
            return Scaffold(
              bottomNavigationBar: _navigationBar(value),
              body: IndexedStack(
                index: selectedIndex.value,
                children: [
                  MultiBlocProvider(
                    providers: [
                      BlocProvider(create: (_) => NewsBloc()),
                      BlocProvider(create: (_) => appointmentsBloc),
                      BlocProvider(create: (_) => PatientHistoryBloc()),
                      BlocProvider(create: (_) => MessageInfoBloc()),
                      BlocProvider(create: (_) => PatientTrackerBloc()),
                      BlocProvider(create: (_) => CovidTrackerBloc()),
                    ],
                    child: PatientTabHome(),
                  ),
                  BlocProvider(
                    create: (_) => appointmentsBloc,
                    child: PatientTabAppointments(),
                  ),
                  PatientTabRecords(),
                  BlocProvider(
                    create: (_) => appointmentsBloc,
                    child: PatientTabPayments(),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  Widget _navigationBar(int index) {
    return Container(
      decoration: BoxDecoration(
        border: Border(
          top: BorderSide(
            width: 0.5,
            color: ThemeColor.inputBorder,
          ),
        ),
      ),
      child: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        elevation: 0.0,
        unselectedFontSize: 10.0,
        selectedFontSize: 10.0,
        currentIndex: index,
        onTap: (index) => selectedIndex.value = index,
        items: navigationBarItems.entries.map((item) {
          return BottomNavigationBarItem(
            icon: Padding(
              padding: const EdgeInsets.all(5.0),
              child: Icon(item.value.key),
            ),
            activeIcon: Padding(
              padding: const EdgeInsets.all(5.0),
              child: Icon(item.value.value),
            ),
            label: item.key,
            tooltip: item.key,
          );
        }).toList(),
      ),
    );
  }
}
