import 'package:flutter/material.dart';

class ThemeColor {
  // * Primary Colors
  static const Color accent =
      Color.fromARGB(255, 233, 57, 57); //Color.fromARGB(255, 252, 74, 88); //Color.fromARGB(255, 221, 36, 44);
  static const Color background = Colors.white;
  static const Color background2 = Color.fromARGB(255, 250, 250, 255); //Color.fromARGB(255, 244, 242, 247);
  static const Color foreground = Color.fromARGB(255, 233, 233, 233);
  static const Color foreground2 = Color.fromARGB(255, 224, 224, 224);
  static const Color primary = Color.fromARGB(255, 70, 70, 70);
  static const Color secondary = Color.fromARGB(255, 160, 160, 160);
  static const Color secondary2 = Color.fromARGB(255, 117, 117, 117);
  static const Color buttonTextColor = Color.fromARGB(255, 255, 255, 255);

  // * Text Input
  static const Color inputBorder = Color.fromARGB(255, 215, 215, 215);
  static const Color inputHint = secondary;

  // * Others
  static const Color divider = secondary;
  static const Color shadow = Colors.grey;

  static ThemeData themeData = ThemeData.light().copyWith(
    accentColor: ThemeColor.accent,
    backgroundColor: ThemeColor.background,
    scaffoldBackgroundColor: ThemeColor.background,
    dividerColor: ThemeColor.divider,
    primaryColor: ThemeColor.primary,
    tooltipTheme: TooltipThemeData(
      padding: const EdgeInsets.symmetric(horizontal: 10.0),
      textStyle: const TextStyle(
        fontSize: 12.0,
        color: Colors.white,
      ),
    ),
    appBarTheme: AppBarTheme(
      backgroundColor: ThemeColor.background,
      iconTheme: IconThemeData(
        color: ThemeColor.primary,
      ),
    ),
    bottomNavigationBarTheme: BottomNavigationBarThemeData(
      selectedItemColor: ThemeColor.accent,
      unselectedItemColor: ThemeColor.secondary,
      backgroundColor: ThemeColor.background,
    ),
  );
}
