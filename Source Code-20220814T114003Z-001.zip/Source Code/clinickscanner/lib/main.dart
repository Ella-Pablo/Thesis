import 'dart:convert';

import 'package:clinickscanner/color_config.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:qr_code_scanner/qr_code_scanner.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();

  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  SystemChrome.setSystemUIOverlayStyle(
    SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarBrightness: Brightness.light,
      statusBarIconBrightness: Brightness.light,
    ),
  );

  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'CLinicK QR Scanner',
      theme: ThemeColor.themeData,
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage();

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  final GlobalKey qrKey = GlobalKey(debugLabel: 'QR');
  QRViewController? qrController;
  ValueNotifier<bool> isBusy = ValueNotifier(false);
  String name = "";
  String status = "Waiting for QR-Code...";
  bool _savingBusy = false;

  void _onQRViewCreated(QRViewController controller) {
    qrController = controller;
    controller.scannedDataStream.listen((scanData) async {
      if (_savingBusy == false) {
        _savingBusy = true;
        Fluttertoast.showToast(msg: "Please remove the QR-Code from the camera.", gravity: ToastGravity.CENTER);
        Map<String, dynamic> _mappedCode = jsonDecode(scanData.code);

        if (_mappedCode.containsKey('id') && _mappedCode.containsKey('name')) {
          name = _mappedCode['name'] ?? "Unnamed";
          status = "CLinicK QR-Code Found.";
          isBusy.value = !isBusy.value;

          await Future.delayed(const Duration(seconds: 1));

          var firestore = FirebaseFirestore.instance;
          QuerySnapshot _data = await firestore
              .collection('covidtrackersinit')
              .where('date', isEqualTo: "${DateTime.now().month}_${DateTime.now().day}_${DateTime.now().year}")
              .where('userid', isEqualTo: _mappedCode['id'])
              .get();
          if (_data.size > 0) {
            status = "Saving User Data As Going Out...";
            isBusy.value = !isBusy.value;

            await firestore.collection('covidtrackersinit').doc(_data.docs.first.id).delete();
            await firestore.collection('covidtrackers').add(
              {
                "userid": _mappedCode['id'],
                "username": _mappedCode['name'],
                "start": _data.docs.first.data()['start'] ?? DateTime.now().millisecondsSinceEpoch,
                "end": DateTime.now().millisecondsSinceEpoch,
              },
            );
          } else {
            status = "Saving User Data As Going In...";
            isBusy.value = !isBusy.value;

            await firestore.collection('covidtrackersinit').add(
              {
                "userid": _mappedCode['id'],
                "start": DateTime.now().millisecondsSinceEpoch,
                "date": "${DateTime.now().month}_${DateTime.now().day}_${DateTime.now().year}",
              },
            );
          }

          await Future.delayed(const Duration(seconds: 3));

          name = "";
          status = "Waiting for QR-Code...";
          isBusy.value = !isBusy.value;
        } else {
          Fluttertoast.showToast(msg: "Invalid CLinicK QR-Code");
        }
        _savingBusy = false;
      }
    });
  }

  @override
  void dispose() {
    qrController?.stopCamera();
    qrController?.dispose();
    super.dispose();
  }

  /*@override
  void reassemble() {
    super.reassemble();
    if (Platform.isAndroid) {
      qrController?.pauseCamera();
    } else if (Platform.isIOS) {
      qrController?.resumeCamera();
    }
  }*/

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'CLinicK QR Scanner',
          style: TextStyle(
            color: ThemeColor.accent,
          ),
        ),
        iconTheme: IconThemeData(
          color: ThemeColor.accent,
        ),
        elevation: 8.0,
        actions: [
          IconButton(
            icon: Icon(Icons.refresh),
            color: ThemeColor.accent,
            tooltip: 'Refresh Scanner',
            onPressed: () {
              qrController?.resumeCamera();
            },
          ),
        ],
      ),
      body: Stack(
        children: [
          Positioned.fill(
            bottom: 100.0,
            child: QRView(
              key: qrKey,
              overlay: QrScannerOverlayShape(
                borderWidth: 5.0,
                borderColor: ThemeColor.accent,
                borderRadius: 8.0,
                cutOutSize: 200,
              ),
              onQRViewCreated: _onQRViewCreated,
            ),
          ),
          Positioned(
            left: 0,
            bottom: 0,
            right: 0,
            height: 115.0,
            child: Material(
              color: ThemeColor.background,
              borderRadius: BorderRadius.only(topLeft: Radius.circular(15.0), topRight: Radius.circular(15.0)),
              elevation: 12.0,
              child: ValueListenableBuilder<bool>(
                valueListenable: isBusy,
                builder: (_, value, __) {
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        margin: const EdgeInsets.fromLTRB(15.0, 30.0, 15.0, 5.0),
                        decoration: BoxDecoration(
                          color: ThemeColor.background,
                          border: Border.all(width: 1.0, color: ThemeColor.accent),
                        ),
                        height: 45.0,
                        width: double.maxFinite,
                        child: Row(
                          children: [
                            const SizedBox(width: 8.0),
                            Icon(
                              Icons.account_circle,
                              color: ThemeColor.accent,
                              size: 27.0,
                            ),
                            Expanded(
                              child: Center(
                                child: Text(
                                  name,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                    color: ThemeColor.primary,
                                    fontSize: 16.0,
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(width: 8.0),
                          ],
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 15.0, right: 15.0),
                        child: Text(
                          "Status: $status",
                          style: const TextStyle(
                            color: ThemeColor.secondary,
                            fontSize: 11.0,
                          ),
                        ),
                      ),
                    ],
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
}
